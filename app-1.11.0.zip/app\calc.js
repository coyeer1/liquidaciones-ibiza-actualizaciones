// Motor de cálculo de prestaciones sociales — Colombia, contrato a término indefinido.
// Todo es puro (sin base de datos): recibe un "contexto" con los datos del trabajador y devuelve
// los conceptos con su explicación, para que el comprobante muestre de dónde sale cada peso.
//
// Normas que se aplican:
//  - Cesantías: Art. 249 y 253 CST (un mes de salario por año; si el salario cambió en los últimos
//    3 meses se promedia el último año). Auxilio de transporte entra en la base (Ley 1/1963 art. 7).
//    Corte anual al fondo antes del 14-feb (Art. 99 Ley 50/1990).
//  - Intereses sobre cesantías: Ley 52/1975 (12 % anual sobre el saldo, proporcional al tiempo del
//    periodo; las licencias no remuneradas NO los rebajan otra vez). Se pagan antes del 31-ene.
//  - Prima de servicios: Art. 306 CST (30 días por año, por semestres: 30-jun y 20-dic).
//  - Vacaciones: Art. 186, 189 y 192 CST (15 días hábiles por año; base = salario ordinario, sin
//    auxilio de transporte, horas extra ni dominicales; el recargo nocturno sí cuenta). Con el contrato
//    vigente solo se paga en dinero hasta la mitad de los periodos cumplidos (Ley 1429/2010 art. 20).
//  - Indemnización por despido sin justa causa: Art. 64 CST (Ley 789/2002; no la cambió la Ley 2466/2025).
//  - Días no remunerados (licencias no remuneradas, suspensiones): Art. 51 y 53 CST, se descuentan de
//    cesantías y vacaciones; de la prima solo si se pide (el Ministerio dice que no).
'use strict';
const F = require('./fechas');

const r0 = (n) => Math.round(n);
const r2 = (n) => Math.round(n * 100) / 100;

function pesos(n) {
  const neg = n < 0;
  const s = String(Math.round(Math.abs(n))).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return (neg ? '-$' : '$') + s;
}
function numTxt(n) {
  return String(r2(n)).replace('.', ',');
}

const CONCEPTOS = {
  cesantias: 'Cesantías',
  intereses: 'Intereses sobre cesantías',
  prima: 'Prima de servicios',
  vacaciones: 'Vacaciones compensadas en dinero',
  vacaciones_disfrutadas: 'Vacaciones disfrutadas',
  indemnizacion: 'Indemnización por despido sin justa causa',
  salario: 'Salario pendiente',
  auxilio_salario: 'Auxilio de transporte pendiente',
  otro_devengo: 'Otro pago',
  deduccion: 'Descuento',
  informativo: 'Nota',
};

const TIPOS = {
  cesantias: 'Cesantías e intereses',
  prima: 'Prima de servicios',
  disfrute: 'Vacaciones disfrutadas',
  vacaciones: 'Vacaciones en dinero',
  definitiva: 'Liquidación definitiva (retiro)',
};

const MOTIVOS_RETIRO = {
  renuncia: 'Renuncia voluntaria',
  sin_justa_causa: 'Despido sin justa causa',
  justa_causa: 'Despido con justa causa',
  despido_indirecto: 'Renuncia por culpa del empleador (despido indirecto)',
  periodo_prueba: 'Terminación en periodo de prueba',
  mutuo_acuerdo: 'Mutuo acuerdo',
  pension: 'Reconocimiento de pensión',
  fallecimiento: 'Fallecimiento del trabajador',
  otro: 'Otro motivo',
};
const CON_INDEMNIZACION = ['sin_justa_causa', 'despido_indirecto'];
// Solo estas novedades suspenden el contrato (Art. 51); una ausencia suelta se descuenta por nómina.
const NOVEDADES_QUE_DESCUENTAN = ['licencia_no_remunerada', 'suspension'];

// ---------- lectura del contexto ----------

function paramsDe(ctx, fecha) {
  const y = F.anio(fecha);
  if (ctx.params[y]) return { ...ctx.params[y], anio: y, exacto: true };
  const anios = Object.keys(ctx.params).map(Number).sort((a, b) => a - b);
  const previo = anios.filter((a) => a <= y).pop() ?? anios[0];
  return { ...ctx.params[previo], anio: previo, exacto: false, pedido: y };
}

function salariosOrdenados(ctx) {
  return [...(ctx.salarios || [])].sort((a, b) => (a.vigente_desde < b.vigente_desde ? -1 : 1));
}

// Quien "gana el mínimo" sigue al salario mínimo de cada año sin tener que registrar el aumento.
function ganaMinimo(ctx) {
  return !!(ctx.trab && Number(ctx.trab.salario_minimo)) && ctx.trab.tipo_salario !== 'integral';
}

function salarioEn(ctx, fecha) {
  if (ganaMinimo(ctx) && ctx.params) {
    const p = paramsDe(ctx, fecha);
    if (p && p.smmlv) return Number(p.smmlv);
  }
  const lista = salariosOrdenados(ctx);
  if (!lista.length) return 0;
  let s = lista[0].salario;
  for (const x of lista) if (x.vigente_desde <= fecha) s = x.salario;
  return Number(s) || 0;
}

// ¿Hubo un cambio real de salario en los 3 meses anteriores a "hasta"? (Art. 253 CST)
function cambioUltimos3Meses(ctx, hasta) {
  if (ganaMinimo(ctx)) return false;
  const limite = F.sumarMeses(hasta, -3);
  const lista = salariosOrdenados(ctx);
  for (let i = 1; i < lista.length; i++) {
    const x = lista[i];
    if (x.vigente_desde > limite && x.vigente_desde <= hasta && Number(x.salario) !== Number(lista[i - 1].salario)) return true;
  }
  return false;
}

function promedioBasico(ctx, desde, hasta) {
  if (ganaMinimo(ctx)) return salarioEn(ctx, hasta);
  const lista = salariosOrdenados(ctx);
  const total = F.dias360(desde, hasta);
  if (!lista.length || total <= 0) return salarioEn(ctx, hasta);
  let acum = 0;
  for (let i = 0; i < lista.length; i++) {
    const ini = i === 0 ? '0000-01-01' : lista[i].vigente_desde;
    const fin = i + 1 < lista.length ? F.sumarDias(lista[i + 1].vigente_desde, -1) : '9999-12-31';
    const d = F.cruce360(ini, fin, desde, hasta);
    acum += d * Number(lista[i].salario);
  }
  return acum / total;
}

function mesesEntre(desde, hasta) {
  const [y1, m1] = F.partes(desde);
  const [y2, m2] = F.partes(hasta);
  return (y2 - y1) * 12 + (m2 - m1) + 1;
}

// Promedio mensual de lo variable que viene de la nómina mensual.
//  conExtras = true  → horas extra, dominicales/festivos, recargo nocturno, comisiones y otros (cesantías, prima, indemnización)
//  conExtras = false → sin horas extra ni dominicales/festivos (vacaciones, Art. 192)
function promedioVariable(ctx, desde, hasta, { conExtras = true } = {}) {
  const pDesde = desde.slice(0, 7);
  const pHasta = hasta.slice(0, 7);
  let total = 0;
  let meses = 0;
  let algunVariable = false;
  for (const n of ctx.nomina || []) {
    if (n.periodo < pDesde || n.periodo > pHasta) continue;
    meses++;
    const fijoVar = Number(n.comisiones || 0) + Number(n.otros_salariales || 0) + Number(n.recargo_nocturno || 0);
    const extras = Number(n.extras_recargos || 0);
    if (fijoVar || extras) algunVariable = true;
    total += fijoVar + (conExtras ? extras : 0);
  }
  const mesesPeriodo = Math.max(1, F.dias360(desde, hasta) / 30);
  const esperados = mesesEntre(desde, hasta);
  return { promedio: meses ? total / mesesPeriodo : 0, total, meses, esperados, mesesPeriodo, hayDatos: meses > 0, incompleta: algunVariable && meses < esperados };
}

// La nómina trae los días trabajados de cada quincena (o mes). El programa cuenta por fechas, así que si la nómina
// trae menos días de los que tocaban y en la ficha no hay licencia ni suspensión anotada, se avisa para que alguien mire.
// (Vacaciones e incapacidades también bajan esos días en la nómina, y esas NO descuentan: por eso es aviso y no descuento.)
function diasNominaSinExplicar(ctx, desde, hasta) {
  const t = ctx.trab;
  const out = [];
  const fin = t.fecha_retiro && t.fecha_retiro < hasta ? t.fecha_retiro : hasta;
  for (const p of ctx.planillas || []) {
    if (p.dias == null || p.dias === '' || !/^\d{4}-\d{2}$/.test(p.periodo || '')) continue;
    const [y, m] = p.periodo.split('-').map(Number);
    let a = `${p.periodo}-01`, b = F.texto(y, m, F.diasDelMes(y, m));
    if (p.corte) { if (Number(p.corte.slice(8, 10)) <= 15) b = `${p.periodo}-15`; else a = `${p.periodo}-16`; }
    if (b < desde || a > fin || b > fin) continue; // fuera del periodo, o la planilla pasa del corte
    if (a < desde && desde > t.fecha_ingreso) continue; // el periodo arranca a mitad de la planilla
    if (a < t.fecha_ingreso) a = t.fecha_ingreso; // entró en esa quincena
    if (a > b) continue;
    const tocaban = F.dias360(a, b);
    const faltan = tocaban - Number(p.dias);
    if (faltan <= 0 || diasNoRemunerados(ctx, a, b) >= faltan) continue;
    out.push({ planilla: p.corte ? `la quincena del ${F.larga(p.corte)}` : `el mes ${p.periodo}`, dias: Number(p.dias), tocaban, desde: a, hasta: b });
  }
  return out;
}

function diasNoRemunerados(ctx, desde, hasta) {
  let d = 0;
  for (const n of ctx.novedades || []) {
    if (n.tipo && !NOVEDADES_QUE_DESCUENTAN.includes(n.tipo)) continue;
    const a = n.desde > desde ? n.desde : desde;
    const b = n.hasta < hasta ? n.hasta : hasta;
    if (b < a) continue;
    // Meses de 30: todo febrero = 30; 27-28 de febrero = 2 (no 4); el 31 no se rebaja.
    d += F.diasAusencia(a, b);
  }
  return d;
}

function ventanaUltimoAnio(ctx, hasta) {
  const v = F.sumarDias(F.sumarMeses(hasta, -12), 1);
  return v > ctx.trab.fecha_ingreso ? v : ctx.trab.fecha_ingreso;
}

// Base mensual. clase: 'prestaciones' (cesantías/prima), 'vacaciones', 'indemnizacion'.
// ventanaHasta: fin de la ventana para promediar (por defecto `hasta`); el salario vigente siempre es el de `hasta`.
function calcularBase(ctx, { hasta, ventanaDesde, ventanaHasta, clase, variableManual }) {
  const t = ctx.trab;
  const vHasta = ventanaHasta || hasta;
  const p = paramsDe(ctx, hasta);
  const notas = [];
  const bloqueos = [];
  // Sin el salario mínimo y el auxilio del año no se puede liquidar bien (quien gana el mínimo quedaría con el del año anterior).
  if (!p.exacto) bloqueos.push(`Falta cargar el salario mínimo y el auxilio de transporte de ${p.pedido}. Póngalos en Ajustes y copias → Valores de cada año (salen en el decreto de fin de año).`);

  const actual = salarioEn(ctx, hasta);
  let salario = actual;
  let metodo = ganaMinimo(ctx) ? `Salario mínimo de ${F.anio(hasta)}` : 'Salario vigente al ' + F.larga(hasta);

  if (t.tipo_salario === 'integral') {
    metodo = 'Salario integral vigente';
  } else {
    // Art. 253: el promedio por cambio de salario aplica a cesantías y prima; vacaciones e
    // indemnización usan el salario vigente salvo que sea variable.
    const cambio = clase === 'prestaciones' && cambioUltimos3Meses(ctx, hasta);
    if (cambio || t.tipo_salario === 'variable') {
      const prom = promedioBasico(ctx, ventanaDesde, vHasta);
      if (actual === p.smmlv && prom < actual) {
        salario = actual;
        metodo = 'Gana el mínimo: se toma el mínimo vigente (no puede quedar por debajo)';
      } else {
        salario = prom;
        metodo = cambio
          ? `Promedio del ${F.larga(ventanaDesde)} al ${F.larga(vHasta)}, porque el salario cambió en los últimos 3 meses (Art. 253 CST)`
          : `Promedio del ${F.larga(ventanaDesde)} al ${F.larga(vHasta)} (salario variable)`;
      }
    }
  }

  // Parte variable
  let variable = 0;
  let metodoVariable = '';
  if (t.tipo_salario !== 'integral') {
    if (variableManual != null && variableManual !== '' && !isNaN(Number(variableManual))) {
      variable = Number(variableManual);
      metodoVariable = variable ? 'Promedio variable digitado a mano' : '';
    } else {
      const pv = promedioVariable(ctx, ventanaDesde, vHasta, { conExtras: clase !== 'vacaciones' });
      variable = pv.promedio;
      if (pv.hayDatos && variable) {
        metodoVariable = `Variable: suma de ${pv.meses} mes(es) de nómina cargados ÷ ${numTxt(pv.mesesPeriodo)} meses del periodo (${clase === 'vacaciones' ? 'comisiones, recargo nocturno y otros; sin horas extra ni dominicales' : 'horas extra, recargos, comisiones y otros'})`;
      }
      if (pv.incompleta) {
        bloqueos.push(`Solo hay ${pv.meses} de ${pv.esperados} meses de nómina cargados entre ${F.larga(ventanaDesde)} y ${F.larga(vHasta)}: lo variable (horas extra, comisiones) quedaría más bajo de lo real. Cargue la nómina que falta o escriba el promedio a mano.`);
      } else if (t.tipo_salario === 'variable' && !pv.hayDatos) {
        bloqueos.push('Tiene salario variable y no hay nómina cargada para este periodo: escriba el promedio mensual de lo variable o cargue la nómina.');
      }
    }
  }

  // Auxilio de transporte: solo para cesantías y prima, si gana hasta 2 mínimos.
  let aux = 0;
  if (clase === 'prestaciones' && t.tipo_salario !== 'integral' && t.auxilio_transporte !== 'no') {
    if (actual + variable <= 2 * p.smmlv) aux = Number(p.auxilio_transporte) || 0;
  }

  const total = r0(salario + variable + aux);
  return { total, salario: r0(salario), metodo, variable: r0(variable), metodoVariable, aux, notas, bloqueos, smmlv: p.smmlv };
}

// ---------- tramos ----------

function partirPorAnio(desde, hasta) {
  const out = [];
  let a = desde;
  while (a <= hasta) {
    const finAnio = `${F.anio(a)}-12-31`;
    const b = finAnio < hasta ? finAnio : hasta;
    out.push([a, b]);
    a = F.sumarDias(b, 1);
  }
  return out;
}
function partirPorSemestre(desde, hasta) {
  const out = [];
  let a = desde;
  while (a <= hasta) {
    const y = F.anio(a);
    const finSem = a <= `${y}-06-30` ? `${y}-06-30` : `${y}-12-31`;
    const b = finSem < hasta ? finSem : hasta;
    out.push([a, b]);
    a = F.sumarDias(b, 1);
  }
  return out;
}

// ---------- conceptos ----------

function cesantiasEIntereses(ctx, desde, hasta, { destino = 'fondo', variableManual } = {}) {
  const out = [];
  if (ctx.trab.tipo_salario === 'integral') return out;
  for (const [a, b] of partirPorAnio(desde, hasta)) {
    const dTot = F.dias360(a, b);
    const dNo = Math.min(dTot, diasNoRemunerados(ctx, a, b));
    const dias = dTot - dNo;
    const base = calcularBase(ctx, { hasta: b, ventanaDesde: ventanaUltimoAnio(ctx, b), clase: 'prestaciones', variableManual });
    const valor = r0((base.total * dias) / 360);
    out.push({
      concepto: 'cesantias', desde: a, hasta: b, dias, dias_descontados: dNo, base: base.total, valor,
      destino, base_detalle: base,
      formula: `${pesos(base.total)} × ${dias} días ÷ 360`,
      norma: 'Art. 249 y 253 CST',
    });
    // Los intereses son el 12 % anual del saldo, proporcional al tiempo del periodo (no se vuelven a rebajar las licencias).
    const intereses = r0((valor * dTot * 0.12) / 360);
    out.push({
      concepto: 'intereses', desde: a, hasta: b, dias: dTot, dias_descontados: 0, base: valor, valor: intereses,
      destino: 'trabajador',
      formula: `${pesos(valor)} × ${dTot} días × 12 % ÷ 360`,
      norma: 'Ley 52 de 1975',
    });
  }
  return out;
}

function prima(ctx, desde, hasta, { variableManual, descontarNoRemunerados = false } = {}) {
  const out = [];
  if (ctx.trab.tipo_salario === 'integral') return out;
  for (const [a, b] of partirPorSemestre(desde, hasta)) {
    const dTot = F.dias360(a, b);
    const dNo = descontarNoRemunerados ? Math.min(dTot, diasNoRemunerados(ctx, a, b)) : 0;
    const dias = dTot - dNo;
    const base = calcularBase(ctx, { hasta: b, ventanaDesde: a, clase: 'prestaciones', variableManual });
    const valor = r0((base.total * dias) / 360);
    out.push({
      concepto: 'prima', desde: a, hasta: b, dias, dias_descontados: dNo, base: base.total, valor,
      destino: 'trabajador', base_detalle: base,
      formula: `${pesos(base.total)} × ${dias} días ÷ 360`,
      norma: 'Art. 306 CST',
    });
  }
  return out;
}

// ¿El programa sabe algo de las vacaciones que ya tomó? (saldo inicial, vacaciones anotadas o pagadas en el programa)
function sinHistoriaVacaciones(ctx) {
  const t = ctx.trab;
  return !t.vac_saldo_fecha && !(ctx.vacaciones || []).length
    && !(ctx.previos || []).some((c) => c.concepto === 'vacaciones_disfrutadas' || c.concepto === 'vacaciones');
}

// Saldo de vacaciones a una fecha.
function saldoVacaciones(ctx, corte) {
  const t = ctx.trab;
  const conSaldo = t.vac_saldo_fecha && F.valida(t.vac_saldo_fecha) && t.vac_saldo_fecha >= t.fecha_ingreso;
  const desde = conSaldo ? F.sumarDias(F.finComercial(t.vac_saldo_fecha), 1) : t.fecha_ingreso;
  const inicial = conSaldo ? Number(t.vac_saldo_dias || 0) : 0;
  const diasServ = Math.max(0, F.dias360(desde, corte) - diasNoRemunerados(ctx, desde, corte));
  const causados = (diasServ * 15) / 360;
  let disfrutados = 0;
  for (const v of ctx.vacaciones || []) if (!conSaldo || v.desde > t.vac_saldo_fecha) disfrutados += Number(v.dias_habiles || 0);
  // Las que se pagaron con comprobante de "vacaciones disfrutadas" también son días tomados.
  for (const c of ctx.previos || []) if (c.concepto === 'vacaciones_disfrutadas' && (!conSaldo || c.desde > t.vac_saldo_fecha)) disfrutados += Number(c.dias || 0);
  let compensados = 0;
  for (const c of ctx.previos || []) if (c.concepto === 'vacaciones' && (!conSaldo || c.hasta > t.vac_saldo_fecha)) compensados += Number(c.dias || 0);
  const pendientes = inicial + causados - disfrutados - compensados;
  // Periodos de 15 días YA cumplidos (año completo de servicio): solo de esos se puede pagar la mitad en dinero.
  const completos = inicial + 15 * Math.floor(diasServ / 360);
  const topeDinero = Math.max(0, Math.min(completos / 2 - compensados, completos - disfrutados - compensados));
  return {
    desde, corte, saldo_inicial: r2(inicial), saldo_fecha: conSaldo ? t.vac_saldo_fecha : null,
    dias_servicio: diasServ, causados: r2(causados), disfrutados: r2(disfrutados), compensados: r2(compensados), pendientes: r2(pendientes),
    completos: r2(completos), tope_dinero: Math.floor(topeDinero * 100) / 100,
  };
}

function vacacionesEnDinero(ctx, corte, { dias, variableManual, forzar = false } = {}) {
  const s = saldoVacaciones(ctx, corte);
  // forzar: quien liquida sabe cuántos días se le deben de verdad (p. ej. el programa no sabe las que ya tomó)
  const aPagar = forzar ? Number(dias) : dias != null && dias !== '' ? Math.min(Number(dias), s.pendientes) : s.pendientes;
  if (aPagar <= 0) return { concepto: null, saldo: s, bloqueos: [] };
  const base = calcularBase(ctx, { hasta: corte, ventanaDesde: ventanaUltimoAnio(ctx, corte), clase: 'vacaciones', variableManual });
  const valor = r0((base.total / 30) * aPagar);
  return {
    saldo: s,
    concepto: {
      concepto: 'vacaciones', desde: s.desde, hasta: corte, dias: r2(aPagar), dias_descontados: 0, base: base.total, valor,
      destino: 'trabajador', base_detalle: base,
      formula: `${pesos(base.total)} ÷ 30 × ${numTxt(aPagar)} días`,
      norma: 'Art. 186, 189 y 192 CST',
    },
  };
}

// UVT de cada año (resoluciones DIAN): para los avisos de retención en la fuente.
const UVT = { 2024: 47065, 2025: 49799, 2026: 52374 };
function uvtDe(fecha) {
  const y = F.anio(fecha);
  const anios = Object.keys(UVT).map(Number).sort((a, b) => a - b);
  return UVT[y] || UVT[anios.filter((a) => a <= y).pop() ?? anios[0]];
}

// Fondo de solidaridad pensional (Ley 797 de 2003, art. 8): quien gana 4 mínimos o más pone 1 % (hasta 2 % desde 16 mínimos).
function porcentajeSolidaridad(ibcMensual, smmlv) {
  const n = ibcMensual / smmlv;
  if (n < 4) return 0;
  if (n < 16) return 1;
  if (n <= 17) return 1.2;
  if (n <= 18) return 1.4;
  if (n <= 19) return 1.6;
  if (n <= 20) return 1.8;
  return 2;
}

// Lo que le toca poner al trabajador de un pago que es salario: 4 % salud y 4 % pensión (integral: sobre el 70 %),
// y el fondo de solidaridad pensional si gana 4 mínimos o más.
function aportesTrabajador(ctx, valor, que, fecha) {
  const integral = ctx.trab.tipo_salario === 'integral';
  const ibc = r0(integral ? valor * 0.7 : valor);
  const out = [
    { concepto: 'deduccion', detalle: `Aporte a salud del trabajador (4 % ${que})`, desde: null, hasta: null, dias: null, base: ibc, valor: r0(ibc * 0.04), destino: 'trabajador', formula: '', norma: 'Ley 100 de 1993' },
    { concepto: 'deduccion', detalle: `Aporte a pensión del trabajador (4 % ${que})`, desde: null, hasta: null, dias: null, base: ibc, valor: r0(ibc * 0.04), destino: 'trabajador', formula: '', norma: 'Ley 100 de 1993' },
  ];
  if (fecha) {
    const p = paramsDe(ctx, fecha);
    const sal = salarioEn(ctx, fecha);
    const pct = porcentajeSolidaridad(integral ? sal * 0.7 : sal, p.smmlv);
    if (pct) out.push({ concepto: 'deduccion', detalle: `Fondo de solidaridad pensional (${String(pct).replace('.', ',')} % ${que}, porque gana 4 mínimos o más)`, desde: null, hasta: null, dias: null, base: ibc, valor: r0((ibc * pct) / 100), destino: 'trabajador', formula: '', norma: 'Ley 797 de 2003, art. 8' });
  }
  return out;
}

// Vacaciones que el trabajador sale a disfrutar: se pagan los días hábiles con el salario del día en
// que empieza (Art. 192); lo variable, promedio de los 12 meses completos anteriores.
function vacacionesDisfrutadas(ctx, desde, dias, { trabajaSabados = true, variableManual, descontarAportes = true } = {}) {
  const fin = F.finVacaciones(desde, dias, trabajaSabados);
  const finMesAnterior = F.sumarDias(`${desde.slice(0, 7)}-01`, -1);
  const vHasta = finMesAnterior >= ctx.trab.fecha_ingreso ? finMesAnterior : desde;
  const base = calcularBase(ctx, { hasta: desde, ventanaDesde: ventanaUltimoAnio(ctx, vHasta), ventanaHasta: vHasta, clase: 'vacaciones', variableManual });
  const valor = r0((base.total / 30) * dias);
  const conceptos = [{
    concepto: 'vacaciones_disfrutadas', desde, hasta: fin.hasta, dias, dias_descontados: 0, base: base.total, valor,
    destino: 'trabajador', base_detalle: base,
    detalle: `Descansa del ${F.conDia(desde)} al ${F.conDia(fin.hasta)} y vuelve a trabajar el ${F.conDia(fin.regreso)}`,
    formula: `${pesos(base.total)} ÷ 30 × ${numTxt(dias)} días hábiles`,
    norma: 'Art. 186 y 192 CST',
  }];
  if (descontarAportes) conceptos.push(...aportesTrabajador(ctx, valor, 'de las vacaciones', desde));
  return { conceptos, fin };
}

function indemnizacion(ctx, retiro, { variableManual } = {}) {
  const t = ctx.trab;
  const diasServ = F.dias360(t.fecha_ingreso, retiro);
  const anios = diasServ / 360;
  const base = calcularBase(ctx, { hasta: retiro, ventanaDesde: ventanaUltimoAnio(ctx, retiro), clase: 'indemnizacion', variableManual });
  const smmlv = base.smmlv;
  let diasInd;
  let regla;
  if (t.fecha_ingreso <= '1992-12-28') {
    // Régimen de transición de la Ley 789 de 2002: tenía 10 años o más al entrar en vigencia (27-dic-2002).
    diasInd = 45 + 40 * Math.max(0, anios - 1);
    regla = '45 días por el primer año y 40 por cada año siguiente (transición Ley 789/2002, tabla de la Ley 50/1990)';
  } else if (base.total < 10 * smmlv) {
    diasInd = anios <= 1 ? 30 : 30 + 20 * (anios - 1);
    regla = 'Menos de 10 mínimos: 30 días el primer año y 20 por cada año siguiente, proporcional';
  } else {
    diasInd = anios <= 1 ? 20 : 20 + 15 * (anios - 1);
    regla = '10 mínimos o más: 20 días el primer año y 15 por cada año siguiente, proporcional';
  }
  diasInd = r2(diasInd);
  const valor = r0((base.total / 30) * diasInd);
  return {
    concepto: 'indemnizacion', desde: t.fecha_ingreso, hasta: retiro, dias: diasInd, dias_descontados: 0, base: base.total, valor,
    destino: 'trabajador', base_detalle: { ...base, regla, anios_servicio: r2(anios) },
    formula: `${pesos(base.total)} ÷ 30 × ${numTxt(diasInd)} días`,
    norma: 'Art. 64 CST',
  };
}

function salarioPendiente(ctx, retiro, dias, { descontarAportes = true } = {}) {
  const out = [];
  dias = Number(dias || 0);
  if (dias <= 0) return out;
  const desde = F.inicio360(retiro, dias); // meses de 30: 15 días hasta el 28 de febrero van desde el 16
  const sal = salarioEn(ctx, retiro);
  const p = paramsDe(ctx, retiro);
  const valorSal = r0((sal / 30) * dias);
  out.push({
    concepto: 'salario', desde, hasta: retiro, dias, dias_descontados: 0, base: sal, valor: valorSal,
    destino: 'trabajador', formula: `${pesos(sal)} ÷ 30 × ${dias} días`, norma: 'Art. 127 CST',
  });
  if (ctx.trab.tipo_salario !== 'integral' && ctx.trab.auxilio_transporte !== 'no' && sal <= 2 * p.smmlv) {
    out.push({
      concepto: 'auxilio_salario', desde, hasta: retiro, dias, dias_descontados: 0, base: p.auxilio_transporte, valor: r0((p.auxilio_transporte / 30) * dias),
      destino: 'trabajador', formula: `${pesos(p.auxilio_transporte)} ÷ 30 × ${dias} días`, norma: 'Ley 15 de 1959',
    });
  }
  if (descontarAportes) out.push(...aportesTrabajador(ctx, valorSal, 'del salario pendiente', retiro));
  return out;
}

// ---------- días que no se cuentan (decisión de la empresa, con su motivo y su soporte) ----------
// Ej.: faltas sin justificar o una sanción. Se quitan del último tramo hacia atrás y la plata se recalcula.
// En las cesantías, los intereses salen del valor nuevo.
function numeroDias(v) {
  const n = Number(String(v ?? '').replace(',', '.'));
  return Number.isFinite(n) ? n : NaN;
}
function descontarDias(conceptos, conc, dias, motivo) {
  const n = numeroDias(dias);
  if (dias == null || dias === '' || n === 0) return 0;
  const nombre = conc === 'cesantias' ? 'las cesantías' : 'la prima';
  if (!(n > 0) || !Number.isInteger(n)) throw new Error(`Los días a descontar de ${nombre} tienen que ser un número entero.`);
  const lista = conceptos.filter((c) => c.concepto === conc);
  if (!lista.length) return 0;
  const total = lista.reduce((s, c) => s + c.dias, 0);
  if (n > total) throw new Error(`No se pueden descontar ${n} días de ${nombre}: el periodo solo tiene ${total}.`);
  let resta = n;
  for (const c of [...lista].reverse()) {
    if (!resta) break;
    const d = Math.min(resta, c.dias);
    if (!d) continue;
    resta -= d;
    c.dias -= d;
    c.dias_descontados = (c.dias_descontados || 0) + d;
    c.dias_descuento_manual = d;
    c.motivo_descuento = motivo ? String(motivo).trim().slice(0, 300) : null;
    c.valor = r0((c.base * c.dias) / 360);
    c.formula = `${pesos(c.base)} × ${c.dias} días ÷ 360`;
    if (conc === 'cesantias') {
      const i = conceptos.find((x) => x.concepto === 'intereses' && x.desde === c.desde && x.hasta === c.hasta);
      if (i) { i.base = c.valor; i.valor = r0((c.valor * i.dias * 0.12) / 360); i.formula = `${pesos(c.valor)} × ${i.dias} días × 12 % ÷ 360`; }
    }
  }
  return n;
}
// Lo pide el formulario: { prima: { dias, motivo }, cesantias: { dias, motivo } }
function aplicarDescuentos(conceptos, o, tipos, bloqueos) {
  for (const conc of tipos) {
    const x = (o.descontar || {})[conc];
    if (!x) continue;
    const n = descontarDias(conceptos, conc, x.dias, x.motivo);
    if (n > 0 && !(x.motivo && String(x.motivo).trim().length >= 5)) bloqueos.push(`Escriba por qué se le descuentan esos ${n} días de ${conc === 'cesantias' ? 'las cesantías' : 'la prima'} (queda en el comprobante).`);
  }
}

function informativo(titulo, detalle) {
  return { concepto: 'informativo', titulo, detalle, desde: null, hasta: null, dias: null, base: null, valor: 0, destino: 'trabajador', formula: '', norma: '' };
}

// ---------- estado del trabajador ----------

// Tramos ya liquidados de cesantías o prima (incluye el dato inicial de la ficha), en orden.
function tramosLiquidados(ctx, concepto) {
  const t = ctx.trab;
  const out = [];
  const inicial = concepto === 'cesantias' ? t.cesantias_hasta_inicial : t.prima_hasta_inicial;
  if (inicial && F.valida(inicial) && inicial >= t.fecha_ingreso) out.push({ desde: t.fecha_ingreso, hasta: F.finComercial(inicial), consecutivo: null, origen: 'saldo_inicial' });
  for (const c of ctx.previos || []) {
    if (c.concepto === concepto && c.desde && c.hasta) out.push({ desde: c.desde, hasta: F.finComercial(c.hasta), consecutivo: c.consecutivo ?? null, origen: 'programa' });
  }
  return out.sort((a, b) => (a.desde < b.desde ? -1 : a.desde > b.desde ? 1 : 0));
}

// Lo que está sin liquidar desde el ingreso hasta `hasta`, como lista de {desde, hasta}.
function sinLiquidar(ctx, concepto, hasta, extra = []) {
  const out = [];
  let cursor = ctx.trab.fecha_ingreso;
  const tramos = [...tramosLiquidados(ctx, concepto), ...extra].sort((a, b) => (a.desde < b.desde ? -1 : 1));
  for (const tr of tramos) {
    if (cursor > hasta) break;
    if (tr.hasta < cursor) continue;
    if (tr.desde > cursor) {
      const fin = F.sumarDias(tr.desde, -1) < hasta ? F.sumarDias(tr.desde, -1) : hasta;
      out.push({ desde: cursor, hasta: fin });
    }
    const sig = F.sumarDias(tr.hasta, 1);
    if (sig > cursor) cursor = sig;
  }
  if (cursor <= hasta) out.push({ desde: cursor, hasta });
  return out;
}

// Huecos: tiempo sin liquidar ANTES de lo último liquidado (quedó atrás y es fácil olvidarlo).
function huecos(ctx, concepto) {
  const h = hastaLiquidado(ctx, concepto);
  if (h.origen === 'ingreso') return [];
  return sinLiquidar(ctx, concepto, h.hasta);
}

function listaRangos(rs) {
  return rs.map((r) => (r.desde === r.hasta ? `el ${F.larga(r.desde)}` : `del ${F.larga(r.desde)} al ${F.larga(r.hasta)}`)).join('; ');
}

function hastaLiquidado(ctx, concepto) {
  let h = null;
  let consecutivo = null;
  for (const c of ctx.previos || []) if (c.concepto === concepto && (!h || c.hasta > h)) { h = c.hasta; consecutivo = c.consecutivo ?? null; }
  if (h) return { hasta: F.finComercial(h), origen: 'programa', consecutivo };
  const inicial = concepto === 'cesantias' ? ctx.trab.cesantias_hasta_inicial : ctx.trab.prima_hasta_inicial;
  if (inicial && F.valida(inicial)) return { hasta: F.finComercial(inicial), origen: 'saldo_inicial', consecutivo: null };
  return { hasta: F.sumarDias(ctx.trab.fecha_ingreso, -1), origen: 'ingreso', consecutivo: null };
}

function estado(ctx, corte) {
  const t = ctx.trab;
  const limite = t.fecha_retiro && t.fecha_retiro < corte ? t.fecha_retiro : corte;
  const ces = hastaLiquidado(ctx, 'cesantias');
  const pri = hastaLiquidado(ctx, 'prima');
  const vac = saldoVacaciones(ctx, limite);
  const dias = (rs) => rs.reduce((s, r) => s + F.dias360(r.desde, r.hasta), 0);
  const cesH = huecos(ctx, 'cesantias').filter((r) => r.desde <= limite);
  const priH = huecos(ctx, 'prima').filter((r) => r.desde <= limite);
  return {
    corte: limite,
    cesantias_hasta: ces.hasta, cesantias_origen: ces.origen,
    prima_hasta: pri.hasta, prima_origen: pri.origen,
    cesantias_huecos: cesH, prima_huecos: priH,
    cesantias_dias_pendientes: Math.max(0, F.dias360(F.sumarDias(ces.hasta, 1), limite)) + dias(cesH),
    prima_dias_pendientes: Math.max(0, F.dias360(F.sumarDias(pri.hasta, 1), limite)) + dias(priH),
    vacaciones: vac,
    vacaciones_sin_historia: sinHistoriaVacaciones(ctx),
    salario_actual: salarioEn(ctx, limite),
  };
}

// ---------- avisos de pago tarde ----------

function avisosDeTardanza(ctx, tipo, conceptos, fecha, avisos) {
  if (!fecha || !F.valida(fecha)) return;
  const diario = r0(salarioEn(ctx, fecha) / 30);
  // El plazo depende del año o semestre al que pertenece el tramo, aunque el tramo no llegue al cierre.
  for (const c of conceptos) {
    if (c.concepto === 'cesantias' && c.destino === 'fondo') {
      const limite = `${F.anio(c.hasta) + 1}-02-14`;
      if (fecha > limite) avisos.push(`Va tarde: las cesantías de ${F.anio(c.hasta)} se debían consignar a más tardar el ${F.larga(limite)}. La ley cobra un día de salario por cada día de retraso (Art. 99 Ley 50 de 1990): unos ${pesos(diario)} por día.`);
    }
    if (c.concepto === 'intereses' && tipo !== 'definitiva') {
      const limite = `${F.anio(c.hasta) + 1}-01-31`;
      if (fecha > limite) avisos.push(`Va tarde: los intereses de ${F.anio(c.hasta)} se debían pagar a más tardar el ${F.larga(limite)}. Si no se pagaron a tiempo, la ley obliga a pagar otro tanto igual como sanción (Ley 52 de 1975): ${pesos(c.valor)} más.`);
    }
    if (c.concepto === 'prima' && tipo === 'prima') {
      const y = F.anio(c.hasta);
      const limite = c.hasta <= `${y}-06-30` ? `${y}-06-30` : `${y}-12-20`;
      if (fecha > limite) avisos.push(`Va tarde: la prima del ${c.hasta <= `${y}-06-30` ? 'primer' : 'segundo'} semestre de ${y} se debía pagar a más tardar el ${F.larga(limite)}.`);
    }
  }
}

// ---------- armado de una liquidación completa ----------

function conceptosDigitados(o) {
  const out = [];
  for (const x of o.otros_devengos || []) {
    const v = Math.round(Number(x.valor || 0));
    if (v > 0) out.push({ concepto: 'otro_devengo', detalle: String(x.detalle || 'Otro pago').slice(0, 120), desde: null, hasta: null, dias: null, base: null, valor: v, destino: 'trabajador', formula: '', norma: '' });
  }
  for (const x of o.deducciones || []) {
    const v = Math.round(Number(x.valor || 0));
    if (v > 0) out.push({ concepto: 'deduccion', detalle: String(x.detalle || 'Descuento').slice(0, 120), desde: null, hasta: null, dias: null, base: null, valor: v, destino: 'trabajador', formula: '', norma: '' });
  }
  return out;
}

// ---------- varias cosas en un solo comprobante ----------
// Ej.: prima de diciembre + las vacaciones que sale a disfrutar. Cada parte se calcula exactamente igual que si fuera
// sola, en este orden, y lo que va saliendo cuenta como ya liquidado para la siguiente (así nada se paga dos veces).
// La definitiva no entra: ya incluye todo lo pendiente.
const ORDEN_PARTES = ['cesantias', 'prima', 'disfrute', 'vacaciones'];
function armarVarios(ctx, pedido) {
  const partes = (pedido.partes || []).filter((p) => p && p.tipo);
  if (partes.some((p) => p.tipo === 'definitiva')) throw new Error('La liquidación definitiva va sola: ya incluye todo lo pendiente.');
  if (partes.some((p) => !ORDEN_PARTES.includes(p.tipo))) throw new Error('Tipo de liquidación desconocido.');
  if (new Set(partes.map((p) => p.tipo)).size !== partes.length) throw new Error('Hay un concepto repetido.');
  partes.sort((a, b) => ORDEN_PARTES.indexOf(a.tipo) - ORDEN_PARTES.indexOf(b.tipo));
  const o = pedido.opciones || {};
  const sinDigitados = { ...o, otros_devengos: [], deducciones: [] };
  let previos = [...(ctx.previos || [])];
  const conceptos = [];
  const avisos = [];
  const bloqueos = [];
  const hechas = [];
  for (const p of partes) {
    let r;
    try {
      r = armar({ ...ctx, previos }, { ...pedido, tipo: p.tipo, desde: p.desde, hasta: p.hasta, opciones: sinDigitados });
    } catch (e) { throw new Error(`${TIPOS[p.tipo]}: ${e.message}`); }
    conceptos.push(...r.conceptos);
    for (const a of r.avisos) if (!avisos.includes(a)) avisos.push(a);
    for (const b of r.bloqueos) { const x = `${TIPOS[p.tipo]}: ${b}`; if (!bloqueos.includes(x)) bloqueos.push(x); }
    hechas.push({ tipo: p.tipo, desde: r.desde, hasta: r.hasta });
    previos = previos.concat(r.conceptos.filter((c) => c.desde && c.hasta).map((c) => ({ concepto: c.concepto, desde: c.desde, hasta: c.hasta, dias: c.dias, consecutivo: null })));
  }
  conceptos.push(...conceptosDigitados(o));
  const devengado = conceptos.filter((c) => c.concepto !== 'deduccion').reduce((s, c) => s + c.valor, 0);
  const deducciones = conceptos.filter((c) => c.concepto === 'deduccion').reduce((s, c) => s + c.valor, 0);
  const aFondo = conceptos.filter((c) => c.destino === 'fondo').reduce((s, c) => s + c.valor, 0);
  const neto = devengado - aFondo - deducciones;
  if (neto < 0) bloqueos.push('Los descuentos son mayores que lo que se le va a pagar.');
  const desdes = hechas.map((h) => h.desde).filter(Boolean).sort();
  const hastas = hechas.map((h) => h.hasta).filter(Boolean).sort();
  return {
    tipo: 'varios', partes: hechas, desde: desdes[0] || null, hasta: hastas[hastas.length - 1], conceptos, avisos, bloqueos,
    totales: { devengado, deducciones, a_fondo: aFondo, neto },
    opciones: o,
  };
}

function armar(ctx, pedido) {
  const t = ctx.trab;
  const { tipo } = pedido;
  const o = pedido.opciones || {};
  const avisos = [];
  const bloqueos = [];
  let conceptos = [];
  let desde = pedido.desde;
  let hasta = pedido.hasta;
  const fecha = pedido.fecha;

  if (!t.fecha_ingreso || !F.valida(t.fecha_ingreso)) throw new Error('El trabajador no tiene fecha de ingreso válida.');
  if (!(ctx.salarios || []).length) throw new Error('El trabajador no tiene salario registrado.');
  if (!F.valida(hasta)) throw new Error('La fecha de corte no es válida.');
  if (hasta < t.fecha_ingreso) throw new Error('La fecha de corte es anterior al ingreso del trabajador.');
  if (t.fecha_ingreso < '1991-01-01' && (tipo === 'cesantias' || tipo === 'definitiva')) {
    avisos.push('Ingresó antes de 1991: si nunca se pasó al régimen de la Ley 50 de 1990 (régimen retroactivo), sus cesantías se calculan con el último salario por todo el tiempo. Confírmelo con el contador antes de guardar.');
  }

  if (tipo === 'cesantias' || tipo === 'prima') {
    if (t.tipo_salario === 'integral') throw new Error('Este trabajador tiene salario integral: no se le liquidan cesantías, intereses ni prima (Art. 132 CST).');
    const h = hastaLiquidado(ctx, tipo);
    const sugerido = F.sumarDias(h.hasta, 1);
    const elegido = !!desde;
    if (!desde) desde = sugerido;
    if (desde < t.fecha_ingreso) desde = t.fecha_ingreso;
    if (!F.valida(desde)) throw new Error('La fecha inicial no es válida.');
    if (!elegido && desde > hasta) throw new Error(`Ya está liquidado hasta el ${F.larga(F.finLaboral(h.hasta))}. Escoja una fecha de corte posterior.`);
    if (desde > hasta) throw new Error('La fecha inicial es posterior a la fecha de corte.');
    if (t.fecha_retiro && hasta > t.fecha_retiro) throw new Error(`Se retiró el ${F.larga(t.fecha_retiro)}: no se puede liquidar tiempo después de esa fecha.`);
    // Se puede liquidar cualquier periodo que no esté ya pagado (también un hueco que quedó atrás).
    const cruce = tramosLiquidados(ctx, tipo).find((r) => r.desde <= hasta && r.hasta >= desde);
    if (cruce) {
      const donde = cruce.origen === 'saldo_inicial' ? ' (dato inicial de la ficha)' : cruce.consecutivo ? ` en el comprobante N.º ${cruce.consecutivo}` : '';
      throw new Error(`Del ${F.larga(cruce.desde > desde ? cruce.desde : desde)} al ${F.larga(F.finLaboral(cruce.hasta < hasta ? cruce.hasta : hasta))} ya está liquidado${donde}: se pagaría dos veces. Escoja otras fechas o, si hay que corregir algo, anule primero esa liquidación.`);
    }
    const nombreC = tipo === 'cesantias' ? 'cesantías' : 'prima';
    const inicioCorte = tipo === 'cesantias' ? `${F.anio(hasta)}-01-01` : (hasta.slice(5) <= '06-30' ? `${F.anio(hasta)}-01-01` : `${F.anio(hasta)}-07-01`);
    if (h.origen === 'ingreso' && !elegido && desde < inicioCorte) avisos.push(`Nunca se le ha liquidado ${nombreC} en el programa ni tiene dato inicial, así que se liquida desde su ingreso (${F.larga(desde)}). Si ya se le pagaron periodos anteriores, ponga en su ficha hasta qué fecha se le pagó.`);
    else if (!elegido && desde < inicioCorte) avisos.push(`Incluye también del ${F.larga(desde)} al ${F.larga(F.sumarDias(inicioCorte, -1))}, que figura sin pagar. Si ya se pagó por fuera del programa, corrija en su ficha hasta dónde se le liquidó.`);
    // Lo que seguiría sin liquidar antes de este corte, contando esta liquidación.
    const quedan = sinLiquidar(ctx, tipo, F.sumarDias(desde, -1) > h.hasta ? F.sumarDias(desde, -1) : h.hasta, [{ desde, hasta }]);
    if (quedan.length) avisos.push(`Queda sin liquidar ${listaRangos(quedan)}. No se pierde: sale en la ficha del trabajador y en Inicio para liquidarlo cuando toque.`);
    if (tipo === 'cesantias') {
      const destino = o.destino_cesantias === 'trabajador' ? 'trabajador' : 'fondo';
      if (destino === 'trabajador') {
        if (F.finComercial(hasta).slice(5) === '12-31') throw new Error('El corte anual de cesantías (30 o 31 de diciembre) se consigna en el fondo, no se le paga al trabajador (Art. 99 Ley 50 de 1990).');
        if (!o.motivo_pago_directo || String(o.motivo_pago_directo).trim().length < 5) bloqueos.push('Escriba por qué se le pagan las cesantías directo (por ejemplo: anticipo para vivienda o estudio, con el soporte). Pagarlas sin autorización hace que el empleador las pierda (Art. 254 CST).');
      }
      conceptos = cesantiasEIntereses(ctx, desde, hasta, { destino, variableManual: o.variable_manual });
    } else {
      conceptos = prima(ctx, desde, hasta, { variableManual: o.variable_manual, descontarNoRemunerados: o.prima_descuenta_no_remunerados === true });
    }
    aplicarDescuentos(conceptos, o, [tipo], bloqueos);
  } else if (tipo === 'disfrute') {
    // Aquí `desde` es el día en que sale a vacaciones; `hasta` lo calcula el programa.
    desde = pedido.desde || pedido.hasta;
    if (!desde || !F.valida(desde)) throw new Error('Escriba el día en que sale a vacaciones.');
    if (desde < t.fecha_ingreso) throw new Error('El día de salida es anterior al ingreso del trabajador.');
    if (t.fecha_retiro && desde > t.fecha_retiro) throw new Error(`Se retiró el ${F.larga(t.fecha_retiro)}.`);
    const dias = Number(String(o.dias_disfrute ?? '').replace(',', '.'));
    if (!(dias >= 1) || !Number.isInteger(dias) || dias > 90) throw new Error('Escriba cuántos días hábiles va a descansar (un número entero; un periodo completo son 15).');
    const trabajaSabados = o.trabaja_sabados !== false;
    if (!F.esHabil(desde, trabajaSabados)) avisos.push(`El ${F.conDia(desde)} no es día hábil para este trabajador: las vacaciones empiezan a contar desde el siguiente día hábil.`);
    const r = vacacionesDisfrutadas(ctx, desde, dias, { trabajaSabados, variableManual: o.variable_manual_vacaciones, descontarAportes: o.descontar_aportes !== false });
    hasta = r.fin.hasta;
    if (t.fecha_retiro && hasta > t.fecha_retiro) throw new Error(`Las vacaciones terminarían después del retiro (${F.larga(t.fecha_retiro)}).`);
    const tomadas = [
      ...(ctx.vacaciones || []).map((v) => ({ desde: v.desde, hasta: v.hasta, de: 'registradas en la ficha' })),
      ...(ctx.previos || []).filter((c) => c.concepto === 'vacaciones_disfrutadas').map((c) => ({ desde: c.desde, hasta: c.hasta, de: `del comprobante N.º ${c.consecutivo}` })),
    ];
    const choque = tomadas.find((v) => v.desde <= hasta && v.hasta >= desde);
    if (choque) throw new Error(`Se cruza con vacaciones ${choque.de} (del ${F.larga(choque.desde)} al ${F.larga(choque.hasta)}).`);
    const s = saldoVacaciones(ctx, desde);
    if (dias > s.pendientes + 1e-9) {
      avisos.push(s.pendientes > 0
        ? `Al ${F.larga(desde)} solo ha ganado ${numTxt(s.pendientes)} días: ${numTxt(dias - s.pendientes)} serían vacaciones anticipadas. Se pueden dar si las dos partes lo acuerdan por escrito; si se retira antes de ganarlas, no se le pueden descontar sin su autorización.`
        : `Al ${F.larga(desde)} no tiene días de vacaciones ganados: todas serían anticipadas. Se pueden dar si las dos partes lo acuerdan por escrito.`);
    }
    if (dias < 6) avisos.push('La ley pide que cada año descanse por lo menos 6 días hábiles seguidos (Art. 190 CST). Partirlas en pedazos más cortos solo vale si lo pide el trabajador.');
    if (fecha && F.valida(fecha) && fecha > desde) avisos.push('El comprobante tiene fecha posterior al día de salida: lo normal es pagarlas antes de que salga.');
    if (diasNoRemunerados(ctx, desde, hasta) > 0) avisos.push('Hay licencias o suspensiones registradas dentro de estas vacaciones: revíselo, no deberían cruzarse.');
    conceptos = r.conceptos;
  } else if (tipo === 'vacaciones') {
    const s = saldoVacaciones(ctx, hasta);
    const dias = Number(String(o.dias_vacaciones ?? '').replace(',', '.'));
    if (!(dias > 0)) throw new Error(`Escriba cuántos días se van a pagar en dinero. Con el contrato vigente, el máximo hoy es ${numTxt(s.tope_dinero)} días (la mitad de los periodos ya cumplidos).`);
    if (s.tope_dinero <= 0) throw new Error('Todavía no tiene un periodo de vacaciones cumplido (o ya se le pagó en dinero la mitad permitida). Con el contrato vigente no se pueden pagar en dinero.');
    if (dias > s.tope_dinero + 1e-9) throw new Error(`Con el contrato vigente solo se puede pagar en dinero hasta la mitad de las vacaciones ya cumplidas: máximo ${numTxt(s.tope_dinero)} días (Art. 189 CST, Ley 1429 de 2010).`);
    if (!o.solicitud_escrita) bloqueos.push('Falta marcar que el trabajador lo pidió por escrito y que hay un acuerdo firmado (Art. 189 CST).');
    const r = vacacionesEnDinero(ctx, hasta, { dias, variableManual: o.variable_manual_vacaciones });
    if (!r.concepto) throw new Error(`No tiene días de vacaciones pendientes al ${F.larga(hasta)}.`);
    desde = r.concepto.desde;
    conceptos = [r.concepto];
  } else if (tipo === 'definitiva') {
    const retiro = hasta;
    const motivo = o.motivo_retiro;
    if (!motivo || !MOTIVOS_RETIRO[motivo]) throw new Error('Falta el motivo del retiro.');
    desde = t.fecha_ingreso;
    // Ajustes de quien liquida: no incluir algo, liquidarlo desde una fecha posterior, otros días de vacaciones.
    const aj = o.def || {};
    const porQue = aj.nota && String(aj.nota).trim() ? ` Motivo: ${String(aj.nota).trim().slice(0, 300)}` : '';
    if (t.tipo_salario !== 'integral') {
      for (const [conc, nombre] of [['cesantias', 'Cesantías e intereses'], ['prima', 'Prima de servicios']]) {
        const h = hastaLiquidado(ctx, conc);
        const a = aj[conc] || {};
        if (a.no) { conceptos.push(informativo(nombre, `No se incluye en esta liquidación.${porQue}`)); continue; }
        // Todo lo que esté sin liquidar hasta el retiro, incluidos los huecos que quedaron atrás.
        let pendientes = sinLiquidar(ctx, conc, retiro);
        if (a.desde) {
          if (!F.valida(a.desde)) throw new Error(`${nombre}: la fecha "desde" no es válida.`);
          if (a.desde > retiro) throw new Error(`${nombre}: la fecha "desde" (${F.larga(a.desde)}) es después del último día de trabajo.`);
          const cruce = tramosLiquidados(ctx, conc).find((r) => r.desde <= a.desde && r.hasta >= a.desde);
          if (cruce) {
            const donde = cruce.origen === 'saldo_inicial' ? ' (dato inicial de la ficha)' : cruce.consecutivo ? ` en el comprobante N.º ${cruce.consecutivo}` : '';
            throw new Error(`${nombre}: el ${F.larga(a.desde)} ya está liquidado${donde}, hasta el ${F.larga(F.finLaboral(cruce.hasta))}. Escoja una fecha posterior.`);
          }
          const saltados = pendientes.filter((p) => p.desde < a.desde).map((p) => ({ desde: p.desde, hasta: p.hasta < a.desde ? p.hasta : F.sumarDias(a.desde, -1) }));
          pendientes = pendientes.filter((p) => p.hasta >= a.desde).map((p) => ({ desde: p.desde > a.desde ? p.desde : a.desde, hasta: p.hasta }));
          if (saltados.length) conceptos.push(informativo(`${nombre}: parte que no se incluye`, `No se incluye ${listaRangos(saltados)} (se tomó como ya pagado o que no corresponde).${porQue}`));
        }
        for (const p of pendientes) {
          if (conc === 'cesantias') conceptos.push(...cesantiasEIntereses(ctx, p.desde, p.hasta, { destino: 'trabajador', variableManual: o.variable_manual }));
          else conceptos.push(...prima(ctx, p.desde, p.hasta, { variableManual: o.variable_manual, descontarNoRemunerados: o.prima_descuenta_no_remunerados === true }));
        }
        aplicarDescuentos(conceptos, o, [conc], bloqueos);
        const atras = pendientes.filter((p) => h.origen !== 'ingreso' && p.hasta < h.hasta);
        if (atras.length) avisos.push(`${conc === 'cesantias' ? 'Las cesantías tenían' : 'La prima tenía'} tiempo sin liquidar ${listaRangos(atras)}: se incluye en esta liquidación.`);
        if (conc === 'cesantias' && pendientes.some((p) => p.desde < `${F.anio(retiro)}-01-01`)) avisos.push('Hay cesantías de años anteriores sin liquidar: se incluyen y se pagan directo al trabajador. Si ya se consignaron al fondo, registre ese dato inicial en la ficha antes de liquidar.');
        if (h.hasta >= retiro) {
          const donde = h.consecutivo ? ` en el comprobante N.º ${h.consecutivo}` : h.origen === 'saldo_inicial' ? ' (dato inicial de la ficha)' : '';
          conceptos.push({ concepto: 'informativo', titulo: nombre, detalle: `Ya liquidada hasta el ${F.larga(F.finLaboral(h.hasta))}${donde}.`, desde: null, hasta: null, dias: null, base: null, valor: 0, destino: 'trabajador', formula: '', norma: '' });
          if (h.hasta > F.finComercial(retiro)) {
            const sobran = F.dias360(F.sumarDias(F.finComercial(retiro), 1), h.hasta);
            const b = calcularBase(ctx, { hasta: retiro, ventanaDesde: ventanaUltimoAnio(ctx, retiro), clase: 'prestaciones' });
            const aprox = r0((b.total * sobran) / 360);
            avisos.push(`Ojo: ${conc === 'prima' ? 'la prima ya se le liquidó' : 'las cesantías ya se le liquidaron'} hasta el ${F.larga(F.finLaboral(h.hasta))}${donde}, pero su último día es el ${F.larga(retiro)}: se liquidaron ${sobran} días de más (unos ${pesos(aprox)}). Si esa liquidación todavía no se ha pagado, anúlela y haga esta de nuevo. Si ya se pagó, solo se puede descontar con autorización escrita del trabajador.`);
          }
        }
      }
    }
    const av = aj.vacaciones || {};
    if (av.no) conceptos.push(informativo('Vacaciones', `No se incluyen en esta liquidación.${porQue}`));
    else {
      const forzar = av.dias != null && av.dias !== '';
      if (forzar && !(numeroDias(av.dias) >= 0 && numeroDias(av.dias) <= 400)) throw new Error('Los días de vacaciones a pagar tienen que ser un número (por ejemplo 7,5).');
      const v = vacacionesEnDinero(ctx, retiro, { variableManual: o.variable_manual_vacaciones, dias: forzar ? numeroDias(av.dias) : undefined, forzar });
      if (v.concepto) conceptos.push(v.concepto);
      else if (forzar) conceptos.push(informativo('Vacaciones', `No se le deben días de vacaciones.${porQue}`));
      else if (v.saldo.pendientes < 0) avisos.push(`El trabajador disfrutó ${numTxt(-v.saldo.pendientes)} días de vacaciones más de los que había causado. La ley no permite descontarlos sin autorización escrita.`);
      if (forzar && Math.abs(numeroDias(av.dias) - Math.max(0, v.saldo.pendientes)) > 0.004) {
        avisos.push(`Vacaciones: se pagan ${numTxt(numeroDias(av.dias))} días, como se escribió; con lo que tiene anotado su ficha, el programa calculaba ${numTxt(Math.max(0, v.saldo.pendientes))}.`);
        if (v.concepto) v.concepto.detalle = `Días escritos por quien liquida (el programa calculaba ${numTxt(Math.max(0, v.saldo.pendientes))}).${porQue}`;
      }
    }
    if (CON_INDEMNIZACION.includes(motivo) && aj.indemnizacion?.no) {
      conceptos.push(informativo('Indemnización por despido', `No se incluye en esta liquidación.${porQue}`));
      avisos.push(`Ojo: con este motivo de retiro la ley obliga a pagar la indemnización (Art. 64 CST). Quítela solo si ya se pagó o hubo un acuerdo (conciliación) que lo diga.`);
    } else if (CON_INDEMNIZACION.includes(motivo)) {
      const ind = indemnizacion(ctx, retiro, { variableManual: o.variable_manual });
      conceptos.push(ind);
      const tope = 204 * uvtDe(retiro);
      if (salarioEn(ctx, retiro) > tope) avisos.push(`Gana más de 204 UVT al mes (${pesos(tope)}): a la indemnización se le aplica retención en la fuente del 20 % sobre lo que no es exento (Art. 401-3 Estatuto Tributario). Pídale el valor al contador y agréguelo como descuento.`);
    }
    if (motivo === 'sin_justa_causa' && !o.sin_fuero_verificado) {
      avisos.push('Antes de despedir sin justa causa, verifique que no esté en embarazo o lactancia, con incapacidad o restricciones de salud, a menos de 3 años de pensionarse, ni con fuero sindical. En esos casos el despido puede no valer o necesitar permiso del Ministerio del Trabajo o de un juez.');
    }
    if (motivo === 'justa_causa') avisos.push('Para un despido con justa causa hay que seguir el debido proceso: citar al trabajador, oír sus descargos y dejarlo por escrito (Art. 115 CST, Ley 2466 de 2025). Este programa solo hace la liquidación.');
    conceptos.push(...salarioPendiente(ctx, retiro, o.dias_salario_pendiente, { descontarAportes: o.descontar_aportes !== false }));
    if (motivo !== 'fallecimiento' && !o.constancia_seguridad_social) avisos.push('Falta marcar la constancia de pago de seguridad social de los últimos 3 meses (Ley 789 de 2002, art. 29). Sin ella el retiro puede no producir efecto.');
    if (motivo === 'fallecimiento') avisos.push('Por fallecimiento, se les paga a los beneficiarios después de publicar los avisos de ley y esperar 30 días (Art. 212 y 258 CST). En el comprobante firma el beneficiario.');
    if (fecha && F.valida(fecha) && fecha > retiro && motivo !== 'fallecimiento') {
      const tarde = F.dias360(F.sumarDias(retiro, 1), fecha);
      const minimo = salarioEn(ctx, retiro) <= paramsDe(ctx, retiro).smmlv;
      avisos.push(`El pago se está haciendo ${tarde} día(s) después del retiro. La ley pide pagar el mismo día en que termina el contrato; si no, puede tocar un día de salario por cada día de retraso (Art. 65 CST): unos ${pesos(r0(salarioEn(ctx, retiro) / 30))} por día, ${minimo ? 'y como gana el mínimo, sin tope: hasta el día en que se pague' : 'durante 24 meses y después intereses'}.`);
    }
  } else {
    throw new Error('Tipo de liquidación desconocido.');
  }

  // Otros pagos y descuentos digitados
  conceptos.push(...conceptosDigitados(o));

  avisosDeTardanza(ctx, tipo, conceptos, fecha, avisos);
  for (const c of conceptos) {
    if (!c.base_detalle) continue;
    for (const n of c.base_detalle.notas || []) if (!avisos.includes(n)) avisos.push(n);
    for (const n of c.base_detalle.bloqueos || []) if (!bloqueos.includes(n)) bloqueos.push(n);
  }
  if (t.tipo_salario !== 'integral' && (tipo === 'cesantias' || tipo === 'definitiva') && diasNoRemunerados(ctx, desde, hasta) > 0) {
    avisos.push('Se descontaron días de licencias no remuneradas o suspensiones registradas en la ficha (Art. 53 CST).');
  }

  // Retención en la fuente: con sueldos altos, la prima, las vacaciones y la indemnización pueden tenerla. El programa no la
  // calcula (depende de deducciones que solo conoce el contador): avisa para que se agregue como descuento.
  if (['prima', 'vacaciones', 'disfrute', 'definitiva'].includes(tipo)) {
    const fRef = hasta || fecha;
    const gravado = conceptos.filter((c) => ['prima', 'vacaciones', 'vacaciones_disfrutadas', 'salario', 'indemnizacion'].includes(c.concepto)).reduce((s, c) => s + c.valor, 0);
    const tope = 95 * uvtDe(fRef);
    if (gravado > 0 && salarioEn(ctx, fRef) + gravado > tope) avisos.push(`Con su salario, este pago puede tener retención en la fuente (cuando lo que recibe en el mes pasa de 95 UVT, ${pesos(tope)}). El programa no la calcula: pídale el valor al contador y agréguelo en "Descuentos".`);
  }

  // Vacaciones: si no hay saldo inicial ni vacaciones anotadas, el saldo cuenta todo desde el ingreso (como si nunca hubiera salido).
  // (En la definitiva, si quien liquida ya escribió los días de vacaciones o las quitó, no hace falta el aviso.)
  const vacEscritas = tipo === 'definitiva' && (o.def?.vacaciones?.no || (o.def?.vacaciones?.dias ?? '') !== '');
  if (['vacaciones', 'disfrute', 'definitiva'].includes(tipo) && !vacEscritas && sinHistoriaVacaciones(ctx) && F.dias360(t.fecha_ingreso, hasta || fecha) > 360) {
    avisos.push('Ojo con las vacaciones: en su ficha no hay anotadas vacaciones tomadas ni un saldo inicial, así que el programa cuenta todos los días desde su ingreso. Si ya salió a vacaciones antes, corrija su ficha (días pendientes y a qué fecha) antes de guardar, o se le pagarían de más.');
  }

  if (t.tipo_salario !== 'integral' && ['cesantias', 'prima', 'definitiva'].includes(tipo) && desde && hasta) {
    for (const x of diasNominaSinExplicar(ctx, desde, hasta)) {
      avisos.push(`En la nómina de ${x.planilla} tiene ${x.dias} días trabajados de ${x.tocaban}, y en su ficha no hay licencia ni suspensión anotada para esos días. Si fue licencia no remunerada o suspensión, anótela en "Días no pagados" (se descuenta). Si fueron vacaciones o incapacidad, no cambia nada.`);
    }
  }

  const devengado = conceptos.filter((c) => c.concepto !== 'deduccion').reduce((s, c) => s + c.valor, 0);
  const deducciones = conceptos.filter((c) => c.concepto === 'deduccion').reduce((s, c) => s + c.valor, 0);
  const aFondo = conceptos.filter((c) => c.destino === 'fondo').reduce((s, c) => s + c.valor, 0);
  const neto = devengado - aFondo - deducciones;
  if (neto < 0) bloqueos.push('Los descuentos son mayores que lo que se le va a pagar.');

  return {
    tipo, desde, hasta, conceptos, avisos, bloqueos,
    totales: { devengado, deducciones, a_fondo: aFondo, neto },
    opciones: o,
  };
}

module.exports = {
  diasNominaSinExplicar, armarVarios, ORDEN_PARTES, descontarDias, CON_INDEMNIZACION,
  CONCEPTOS, TIPOS, MOTIVOS_RETIRO, pesos,
  paramsDe, salarioEn, cambioUltimos3Meses, promedioBasico, promedioVariable, diasNoRemunerados,
  calcularBase, cesantiasEIntereses, prima, saldoVacaciones, vacacionesEnDinero, indemnizacion, salarioPendiente,
  hastaLiquidado, estado, armar, partirPorAnio, partirPorSemestre,
  tramosLiquidados, sinLiquidar, huecos, vacacionesDisfrutadas, sinHistoriaVacaciones,
};
