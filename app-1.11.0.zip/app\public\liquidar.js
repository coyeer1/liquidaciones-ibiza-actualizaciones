import { html, useState, useEffect, useRef } from './vendor/preact-htm.js';
import { api, pesos, num, fCorta, fLarga, hoy, ir, sumarDias, TIPOS, etiquetaPartes, CONCEPTOS, MOTIVOS, descargarExcel, textoDescuento } from './util.js';
import { Icono, Campo, InputPesos, Aviso, Cargando, BuscadorTrabajador, Modal, avisar, confirmar, useDatos } from './comp.js';
import { FormTrabajador, FormRango, EliminarTrabajador } from './trabajadores.js';
import { ElegirSoportes } from './adjuntos.js';

// Motivos de retiro que llevan indemnización (igual que en calc.js)
const CON_INDEMNIZACION = ['sin_justa_causa', 'despido_indirecto'];

const DESCRIPCION = {
  cesantias: 'Corte anual al 30 de diciembre (van al fondo) o a una fecha.',
  prima: 'Por semestre: junio y diciembre.',
  disfrute: 'Cuando sale a descansar: se le pagan los días y se calcula cuándo vuelve.',
  vacaciones: 'Pagar en dinero días de vacaciones pendientes.',
  definitiva: 'Cuando el trabajador se va: se le paga todo lo pendiente.',
};

// Fecha de corte que más sentido tiene según lo que ya está liquidado.
// Diciembre se corta el 30, como en las planillas de Ibiza: cada mes cuenta 30 días (el 31 no suma nada).
// Lo ya liquidado viene "hasta el 31" (fin comercial), por eso se compara contra el 31.
function corteSugerido(tipo, estado) {
  const h = hoy();
  const y = Number(h.slice(0, 4));
  if (!estado) return h;
  if (tipo === 'cesantias') {
    return estado.cesantias_hasta < `${y - 1}-12-31` ? `${y - 1}-12-30` : `${y}-12-30`;
  }
  if (tipo === 'prima') {
    const ph = estado.prima_hasta;
    for (const [fin, corte] of [[`${y - 1}-06-30`, `${y - 1}-06-30`], [`${y - 1}-12-31`, `${y - 1}-12-30`], [`${y}-06-30`, `${y}-06-30`], [`${y}-12-31`, `${y}-12-30`]]) if (ph < fin) return corte;
    return `${y}-12-30`;
  }
  return h;
}

function LineasExtra({ titulo, lineas, onCambio, placeholder }) {
  return html`<div class="lineas-extra">
    <div class="fila entre"><span class="etiqueta" style="font-weight:600;font-size:13.5px">${titulo}</span>
      <button type="button" class="btn chico" onClick=${() => onCambio([...lineas, { detalle: '', valor: null }])}><${Icono} n="mas" />Agregar</button></div>
    ${lineas.map((l, i) => html`<div class="fila-extra" key=${i}>
      <input placeholder=${placeholder} value=${l.detalle} aria-label="Detalle" onInput=${(e) => onCambio(lineas.map((x, j) => (j === i ? { ...x, detalle: e.target.value } : x)))} />
      <${InputPesos} valor=${l.valor} aria-label="Valor" onCambio=${(v) => onCambio(lineas.map((x, j) => (j === i ? { ...x, valor: v } : x)))} />
      <button type="button" class="cerrar" title="Quitar" aria-label="Quitar" onClick=${() => onCambio(lineas.filter((_, j) => j !== i))}><${Icono} n="x" /></button>
    </div>`)}
  </div>`;
}

export function ResumenCalculo({ r }) {
  const devengos = r.conceptos.filter((c) => c.concepto !== 'deduccion' && c.concepto !== 'informativo');
  const deducciones = r.conceptos.filter((c) => c.concepto === 'deduccion');
  const notas = r.conceptos.filter((c) => c.concepto === 'informativo');
  return html`<div class="calculo">
    ${devengos.map((c, i) => html`<div class="concepto" key=${i}>
      <div class="cab"><span>${c.concepto === 'otro_devengo' ? c.detalle : CONCEPTOS[c.concepto]}${c.desde && c.concepto !== 'indemnizacion' && c.concepto !== 'vacaciones' ? html` <span class="small muted" style="font-weight:400">${fCorta(c.desde)} → ${fCorta(c.hasta)}</span>` : ''}</span><span class="num">${pesos(c.valor)}</span></div>
      ${c.formula && html`<div class="formula">${c.formula}${textoDescuento(c) ? ` (${textoDescuento(c)})` : ''}${c.destino === 'fondo' ? ' · va al fondo de cesantías' : ''}</div>`}
      ${c.concepto === 'vacaciones_disfrutadas' && c.detalle && html`<div class="formula"><b>${c.detalle}.</b></div>`}
      ${c.concepto === 'vacaciones' && c.detalle && html`<div class="formula">${c.detalle}</div>`}
      ${c.base_detalle && c.concepto !== 'intereses' && html`<div class="formula">Base: salario ${pesos(c.base_detalle.salario)}${c.base_detalle.variable ? ` + variable ${pesos(c.base_detalle.variable)}` : ''}${c.base_detalle.aux ? ` + auxilio de transporte ${pesos(c.base_detalle.aux)}` : ''}. ${c.base_detalle.metodo}.${c.base_detalle.regla ? ' ' + c.base_detalle.regla + '.' : ''}</div>`}
    </div>`)}
    ${notas.map((c, i) => html`<div class="concepto" key=${'n' + i}><div class="cab"><span>${c.titulo}</span><span class="num muted">$0</span></div><div class="formula">${c.detalle}</div></div>`)}
    <div class="total" style="margin-top:6px"><span>Total liquidado</span><b class="num">${pesos(r.totales.devengado)}</b></div>
    ${r.totales.a_fondo > 0 && html`<div class="total menos"><span>Menos: se consigna en el fondo de cesantías</span><span class="num">-${pesos(r.totales.a_fondo)}</span></div>`}
    ${deducciones.map((c, i) => html`<div class="total menos" key=${'d' + i}><span>Menos: ${c.detalle}</span><span class="num">-${pesos(c.valor)}</span></div>`)}
    <div class="total grande"><span>Se le paga al trabajador</span><span class="num">${pesos(r.totales.neto)}</span></div>
  </div>`;
}

// Días que la empresa decide no contar (faltas sin justificar, una sanción…), con su motivo. Salen en el comprobante.
function DescontarDias({ k, o, setO }) {
  const x = (o.descontar || {})[k] || { dias: '', motivo: '' };
  const set = (v) => setO({ ...o, descontar: { ...(o.descontar || {}), [k]: { ...x, ...v } } });
  const id = 'liq-desc-' + k;
  return html`<details class="plegable ancho" open=${!!x.dias}>
    <summary>¿Hay días que no se le deben contar en ${k === 'cesantias' ? 'las cesantías' : 'la prima'}?</summary>
    <div class="campos">
      <${Campo} etiqueta="Días a descontar" id=${id}><input id=${id} inputmode="numeric" value=${x.dias} placeholder="0" onInput=${(ev) => set({ dias: ev.target.value.replace(/\D/g, '') })} /></${Campo}>
      <${Campo} etiqueta="¿Por qué?" requerido=${!!x.dias} id=${id + '-m'} ancho ayuda="Sale en el comprobante. Abajo puede adjuntar el documento que lo respalda (memorando, sanción, permiso…).">
        <input id=${id + '-m'} value=${x.motivo} placeholder="Ej.: faltó el 3 y el 4 de octubre sin justificación" onInput=${(ev) => set({ motivo: ev.target.value })} />
      </${Campo}>
    </div>
    <p class="small muted">Se restan del periodo y la plata se recalcula sola. Las licencias y suspensiones anotadas en la ficha van aparte: no las repita aquí. Descuente solo lo que pueda probar: si el trabajador reclama, la empresa tiene que mostrar el soporte.</p>
  </details>`;
}

// Liquidación definitiva: qué se incluye y desde cuándo. Para cuando algo ya se pagó por fuera, va desde una fecha
// posterior, o el programa no sabe las vacaciones que ya tomó.
function AjustesDefinitiva({ o, setO, r, e }) {
  const aj = o.def || {};
  const set = (k, v) => setO({ ...o, def: { ...aj, [k]: { ...(aj[k] || {}), ...v } } });
  const de = (k) => (r?.conceptos || []).filter((c) => c.concepto === k);
  const tramos = (k) => de(k).map((c) => `${fCorta(c.desde)} → ${fCorta(c.hasta)} (${num(c.dias)} días)`).join(' y ');
  const yaLiquidada = (nombre) => (r?.conceptos || []).find((c) => c.concepto === 'informativo' && c.titulo === nombre && /^Ya liquidad/.test(c.detalle));
  const conIndem = CON_INDEMNIZACION.includes(o.motivo_retiro);
  const cambiado = ['cesantias', 'prima', 'vacaciones', 'indemnizacion'].some((k) => aj[k]?.no || aj[k]?.desde || (aj[k]?.dias ?? '') !== '');
  const casilla = (k, nombre) => html`<label class="check"><input type="checkbox" id=${'def-' + k} checked=${!aj[k]?.no} onChange=${(ev) => set(k, { no: !ev.target.checked })} /><span><b>${nombre}</b>${aj[k]?.no ? html` <span class="small" style="color:var(--bad)">· no se incluye</span>` : ''}</span></label>`;
  const filaPeriodo = (k, nombre) => {
    const a = aj[k] || {};
    const ya = yaLiquidada(nombre);
    return html`<div class=${'ajuste' + (a.no ? ' quitado' : '')} key=${k}>
      ${casilla(k, nombre)}
      ${!a.no && html`<div class="ajuste-cuerpo">
        ${a.desde != null && a.desde !== ''
          ? html`<div class="fila" style="gap:8px"><label class="small" for=${'def-' + k + '-desde'}>Desde el</label><input type="date" id=${'def-' + k + '-desde'} style="width:auto" value=${a.desde} onInput=${(ev) => set(k, { desde: ev.target.value })} />
              <button type="button" class="btn link small" onClick=${() => set(k, { desde: '' })}>Volver a lo automático</button></div>
            <div class="small muted">Lo de antes de esa fecha no se paga aquí (por ejemplo, porque ya se le pagó por fuera).</div>`
          : html`<div class="small muted">${ya ? ya.detalle : de(k).length ? 'Se liquida ' + tramos(k) + '.' : r ? 'Nada pendiente.' : '…'}
              ${!ya && html` <button type="button" class="btn link small" id=${'def-' + k + '-cambiar'} onClick=${() => set(k, { desde: de(k).map((c) => c.desde).sort()[0] || '' })}>Cambiar desde cuándo</button>`}</div>`}
        ${!ya && html`<${DescontarDias} k=${k} o=${o} setO=${setO} />`}
      </div>`}
    </div>`;
  };
  const vac = de('vacaciones')[0];
  const av = aj.vacaciones || {};
  const diasEscritos = av.dias != null && av.dias !== '';
  return html`<div class="campo ancho pila" style="--g:8px">
    <span class="etiqueta">Qué se le paga</span>
    <p class="small muted" style="margin-top:-4px">Desmarque lo que no va o cambie las fechas si algo ya se le pagó por fuera. Todo cambio queda escrito en el comprobante.</p>
    <div class="ajustes-def">
      ${filaPeriodo('cesantias', 'Cesantías e intereses')}
      ${filaPeriodo('prima', 'Prima de servicios')}
      <div class=${'ajuste' + (av.no ? ' quitado' : '')}>
        ${casilla('vacaciones', 'Vacaciones pendientes')}
        ${!av.no && html`<div class="ajuste-cuerpo">
          ${diasEscritos
            ? html`<div class="fila" style="gap:8px"><label class="small" for="def-vacaciones-dias">Días que se le deben</label><input id="def-vacaciones-dias" inputmode="decimal" style="width:110px" value=${av.dias} onInput=${(ev) => set('vacaciones', { dias: ev.target.value.replace(/[^\d,.]/g, '') })} />
                <button type="button" class="btn link small" onClick=${() => set('vacaciones', { dias: '' })}>Volver a lo que calcula el programa</button></div>`
            : html`<div class="small muted">${vac ? `${num(vac.dias, 2)} días según la ficha.` : r ? 'Según la ficha no se le deben días.' : '…'}
                <button type="button" class="btn link small" id="def-vacaciones-cambiar" onClick=${() => set('vacaciones', { dias: vac ? String(vac.dias).replace('.', ',') : '0' })}>Cambiar los días</button></div>`}
          ${e?.vacaciones_sin_historia && !diasEscritos && html`<div class="small" style="color:var(--warn)">El programa no sabe qué vacaciones ya tomó: confirme los días con lo que dice su hoja de vida.</div>`}
        </div>`}
      </div>
      ${conIndem && html`<div class=${'ajuste' + (aj.indemnizacion?.no ? ' quitado' : '')}>${casilla('indemnizacion', 'Indemnización por despido')}
        ${aj.indemnizacion?.no && html`<div class="ajuste-cuerpo small" style="color:var(--bad)">Con este motivo la ley obliga a pagarla. Quítela solo si ya se pagó o hubo un acuerdo (conciliación).</div>`}</div>`}
    </div>
    ${cambiado && html`<${Campo} etiqueta="¿Por qué se cambia o se quita algo?" id="def-nota" ayuda="Sale en el comprobante, junto a lo que se cambió.">
      <input id="def-nota" value=${aj.nota || ''} placeholder="Ej.: las cesantías de enero y febrero se le pagaron por fuera el 2 de marzo" onInput=${(ev) => setO({ ...o, def: { ...aj, nota: ev.target.value } })} />
    </${Campo}>`}
  </div>`;
}

// Se pueden marcar varias cosas (menos la definitiva, que va sola): salen en UN solo comprobante.
const ORDEN = ['cesantias', 'prima', 'disfrute', 'vacaciones', 'definitiva'];
const SIN_FECHAS = { desde: '', hasta: '', cambiar: false };

export function Liquidar({ query }) {
  const [trab, setTrab] = useState(null);
  const [ficha, setFicha] = useState(null);
  const [tipos, setTipos] = useState(query.tipo && TIPOS[query.tipo] ? [query.tipo] : []);
  const [fx, setFx] = useState({}); // fechas de cada cosa marcada: { prima: { desde, hasta, cambiar }, … }
  const [fecha, setFecha] = useState(hoy());
  const [o, setO] = useState({
    destino_cesantias: 'fondo', motivo_pago_directo: '', motivo_retiro: '', otros_devengos: [], deducciones: [], dias_salario_pendiente: '', descontar_aportes: true,
    constancia_seguridad_social: false, examen_egreso: false, certificado_laboral: false, sin_fuero_verificado: false,
    variable_manual: null, variable_manual_vacaciones: null, dias_vacaciones: '', solicitud_escrita: false, prima_descuenta_no_remunerados: false,
    dias_disfrute: '15', trabaja_sabados: true, descontar: {}, def: {},
  });
  const [r, setR] = useState(null);
  const [error, setError] = useState('');
  const [calculando, setCalculando] = useState(false);
  const [guardando, setGuardando] = useState(false);
  // "Corregir" una liquidación ya guardada: se abre con sus mismos datos; al guardar, la vieja queda anulada.
  const [corrigiendo, setCorrigiendo] = useState(null);
  const [motivoCorr, setMotivoCorr] = useState('');
  const [soportes, setSoportes] = useState([]);

  const varios = tipos.length > 1;
  const tipo = tipos.length === 1 ? tipos[0] : varios ? 'varios' : '';
  const tiene = (k) => tipos.includes(k);
  const D = (k) => fx[k] || SIN_FECHAS;
  const setD = (k, v) => setFx((x) => ({ ...x, [k]: { ...(x[k] || SIN_FECHAS), ...v } }));
  const idDe = (base, k) => (varios ? `${base}-${k}` : base);
  const alternar = (k) => setTipos((ts) => (ts.includes(k) ? ts.filter((x) => x !== k) : k === 'definitiva' ? [k] : [...ts.filter((x) => x !== 'definitiva'), k]));

  // Carga el trabajador si viene en la dirección
  useEffect(() => {
    if (query.t && !query.corrige) api('/api/trabajadores/' + query.t).then((d) => { setTrab(d.trabajador); setFicha(d); }).catch((e) => avisar(e.message, 'error'));
    if (query.corrige) {
      (async () => {
        try {
          const l = await api('/api/liquidaciones/' + query.corrige);
          if (l.estado !== 'vigente') { avisar(`La liquidación N.º ${l.consecutivo} está anulada: no se puede corregir.`, 'error'); return; }
          const d = await api('/api/trabajadores/' + l.trabajador_id);
          const dl = l.datos;
          const partes = dl.tipo === 'varios' ? dl.partes : [{ tipo: dl.tipo, desde: dl.desde, hasta: dl.hasta }];
          const nfx = {};
          for (const p of partes) {
            if (p.tipo === 'cesantias' || p.tipo === 'prima') nfx[p.tipo] = { desde: p.desde, hasta: p.hasta, cambiar: true };
            else if (p.tipo === 'disfrute') nfx.disfrute = { desde: '', hasta: p.desde, cambiar: false }; // en el formulario, "hasta" es el día de salida
            else nfx[p.tipo] = { desde: '', hasta: p.hasta, cambiar: false };
          }
          setFx(nfx);
          setTipos(partes.map((p) => p.tipo));
          setO((x) => ({ ...x, ...dl.opciones }));
          setFecha(dl.fecha);
          setTrab(d.trabajador);
          setFicha(d);
          setCorrigiendo({ id: l.id, consecutivo: l.consecutivo, tipo: l.tipo });
        } catch (e) { avisar(e.message, 'error'); }
      })();
    }
  }, []);
  const elegir = async (t) => {
    try { const d = await api('/api/trabajadores/' + t.id); setTrab(d.trabajador); setFicha(d); setR(null); setFx({}); } catch (e) { avisar(e.message, 'error'); }
  };
  // A cada cosa que se marca le propone fechas (o usa las que vienen en la dirección, la primera vez)
  const fechasDeLaDireccion = useRef(query.desde && query.hasta ? { desde: query.desde, hasta: query.hasta } : null);
  useEffect(() => {
    if (!ficha?.estado) return;
    const dir = fechasDeLaDireccion.current;
    for (const k of tipos) {
      if (fx[k]) continue;
      if (dir && (k === 'cesantias' || k === 'prima')) { fechasDeLaDireccion.current = null; setD(k, { ...dir, cambiar: true }); }
      // Solo si todavía no tiene fecha: si la persona ya escribió una (aunque sea muy rápido), no se le pisa.
      else setFx((x) => (x[k] ? x : { ...x, [k]: { desde: '', hasta: corteSugerido(k, ficha.estado), cambiar: false } }));
      if (k === 'cesantias') setO((x) => ({ ...x, destino_cesantias: 'fondo' }));
    }
  }, [tipos, ficha]);

  // En vacaciones disfrutadas, "hasta" del formulario es el día de salida; el regreso lo calcula el programa.
  const parte = (k) => ({ tipo: k, desde: k === 'disfrute' ? D(k).hasta : D(k).cambiar ? D(k).desde : '', hasta: D(k).hasta });
  const extra = () => ({ corrige: corrigiendo?.id, motivo_correccion: motivoCorr, adjuntos: soportes.map((a) => a.id) });
  // Solo se mandan los ajustes de lo que está marcado (si se desmarca algo, no se arrastra lo que se escribió ahí)
  const opcionesDe = () => ({
    ...o,
    descontar: Object.fromEntries(Object.entries(o.descontar || {}).filter(([k]) => tiene(k) || tiene('definitiva'))),
    def: tiene('definitiva') ? o.def : {},
  });
  const pedido = () => (varios
    ? { trabajador_id: trab.id, tipo: 'varios', partes: ORDEN.filter(tiene).map(parte), fecha, opciones: opcionesDe(), ...extra() }
    : { trabajador_id: trab.id, ...parte(tipo), fecha, opciones: opcionesDe(), ...extra() });
  const listo = trab && tipos.length > 0 && tipos.every((k) => D(k).hasta) && !(tiene('definitiva') && !o.motivo_retiro);

  // Recalcula en vivo
  const turno = useRef(0);
  useEffect(() => {
    if (!listo) { setR(null); setError(''); return; }
    const n = ++turno.current;
    setCalculando(true);
    const t = setTimeout(() => {
      api('/api/calcular', { metodo: 'POST', cuerpo: pedido() })
        .then((res) => { if (n === turno.current) { setR(res); setError(''); } })
        .catch((e) => { if (n === turno.current) { setR(null); setError(e.message); } })
        .finally(() => { if (n === turno.current) setCalculando(false); });
    }, 250);
    return () => clearTimeout(t);
  }, [trab, tipos, fx, fecha, o, corrigiendo]);

  const guardar = async () => {
    const ok = await confirmar({
      titulo: corrigiendo ? `Guardar la corrección de la N.º ${corrigiendo.consecutivo}` : 'Guardar la liquidación',
      texto: html`<div class="pila"><p>Se le asigna un número y queda en el historial de <b>${trab.nombre}</b>.</p>
        ${corrigiendo && html`<${Aviso} tipo="info">La liquidación N.º ${corrigiendo.consecutivo} queda <b>anulada</b> (no se borra) con el motivo "${motivoCorr.trim()}", y esta la reemplaza.</${Aviso}>`}
        ${varios && html`<p>Va en <b>un solo comprobante</b>: ${etiquetaPartes(tipos)}.</p>`}
        ${soportes.length > 0 && html`<p>Con ${soportes.length === 1 ? 'el documento' : `los ${soportes.length} documentos`} de soporte: ${soportes.map((a) => a.nombre).join(', ')}.</p>`}
        <p class="muted">Si después algo quedó mal, se usa "Corregir" en la liquidación: la vieja queda anulada con el motivo y se guarda la nueva. Así lo exige el control legal.</p>
        ${tipo === 'definitiva' && html`<${Aviso}>El trabajador quedará como <b>retirado</b> desde el ${fLarga(D('definitiva').hasta)}.</${Aviso}>`}</div>`,
      boton: corrigiendo ? 'Guardar la corrección' : 'Guardar liquidación',
    });
    if (!ok) return;
    setGuardando(true);
    try {
      const res = await api('/api/liquidaciones', { metodo: 'POST', cuerpo: pedido() });
      avisar(`Liquidación N.º ${res.consecutivo} guardada`, 'ok');
      ir('/liquidacion/' + res.id);
    } catch (e) { avisar(e.message, 'error'); setGuardando(false); }
  };

  const e = ficha?.estado;
  // Al corregir la definitiva, el trabajador figura retirado por esa misma liquidación: se trata como activo.
  const retirado = !!trab?.fecha_retiro && corrigiendo?.tipo !== 'definitiva';
  const integral = trab?.tipo_salario === 'integral';
  const sugeridoDesde = (k) => {
    const h = k === 'cesantias' ? e?.cesantias_hasta : e?.prima_hasta;
    return h ? (h < trab.fecha_ingreso ? trab.fecha_ingreso : sumarDias(h, 1)) : null;
  };
  const huecosDe = (k) => (k === 'cesantias' ? e?.cesantias_huecos || [] : k === 'prima' ? e?.prima_huecos || [] : []);
  const subtitulo = (k) => varios && html`<h4 class="parte-titulo">${TIPOS[k]}</h4>`;

  const bloqueCesPrima = (k) => {
    const d = D(k);
    const huecos = huecosDe(k);
    return html`<div class="pila parte" key=${k}>
      ${subtitulo(k)}
      ${huecos.length > 0 && html`<${Aviso}><b>Quedó tiempo sin liquidar antes de lo último que se le pagó:</b>
        ${huecos.map((h) => html`<div class="fila entre" style="margin-top:6px"><span>Del ${fLarga(h.desde)} al ${fLarga(h.hasta)}</span>
          <button class="btn chico" onClick=${() => setD(k, { cambiar: true, desde: h.desde, hasta: h.hasta })}>Liquidar este periodo</button></div>`)}</${Aviso}>`}
      <div class="campos">
        <${Campo} etiqueta="Desde" id=${idDe('liq-desde', k)} ayuda=${d.cambiar ? html`Cualquier fecha que no esté ya pagada. <button class="btn link" onClick=${() => setD(k, { cambiar: false })}>Volver a la fecha automática</button>` : html`El día siguiente a lo último liquidado. <button class="btn link" onClick=${() => setD(k, { cambiar: true, desde: sugeridoDesde(k) })}>Cambiar</button>`}>
          ${d.cambiar ? html`<input id=${idDe('liq-desde', k)} type="date" value=${d.desde} onInput=${(ev) => setD(k, { desde: ev.target.value })} />` : html`<input id=${idDe('liq-desde', k)} readonly value=${fLarga(sugeridoDesde(k))} />`}
        </${Campo}>
        <${Campo} etiqueta="Hasta (fecha de corte)" id=${idDe('liq-hasta', k)} ayuda=${k === 'cesantias' ? 'Normalmente el 31 de diciembre.' : 'Normalmente el 30 de junio o el 31 de diciembre.'}>
          <input id=${idDe('liq-hasta', k)} type="date" value=${d.hasta} onInput=${(ev) => setD(k, { hasta: ev.target.value })} />
        </${Campo}>
        ${k === 'cesantias' && html`<${Campo} etiqueta="Las cesantías…" id="liq-dest" ancho>
          <div class="segmentado" id="liq-dest">
            <button class=${o.destino_cesantias === 'fondo' ? 'activo' : ''} onClick=${() => setO({ ...o, destino_cesantias: 'fondo' })}>Se consignan al fondo</button>
            <button class=${o.destino_cesantias === 'trabajador' ? 'activo' : ''} onClick=${() => setO({ ...o, destino_cesantias: 'trabajador' })}>Se le pagan directo al trabajador</button>
          </div>
          <div class="ayuda">${o.destino_cesantias === 'fondo' ? 'Lo normal en el corte de fin de año (antes del 14 de febrero). Los intereses sí se le pagan al trabajador.' : 'Solo con autorización: por ejemplo, anticipo para comprar o mejorar vivienda o para estudio, con el soporte. Si se pagan sin autorización, el empleador las pierde (Art. 254 CST).'}</div>
        </${Campo}>`}
        ${k === 'cesantias' && o.destino_cesantias === 'trabajador' && html`<${Campo} etiqueta="¿Por qué se le pagan directo?" requerido id="liq-mpd" ancho>
          <input id="liq-mpd" value=${o.motivo_pago_directo} placeholder="Ej.: anticipo para pago de cuota inicial de vivienda, con promesa de compraventa" onInput=${(ev) => setO({ ...o, motivo_pago_directo: ev.target.value })} />
        </${Campo}>`}
        ${k === 'prima' && ficha?.novedades?.length > 0 && html`<label class="check ancho"><input type="checkbox" checked=${o.prima_descuenta_no_remunerados} onChange=${(ev) => setO({ ...o, prima_descuenta_no_remunerados: ev.target.checked })} /><span>Descontar de la prima los días de licencia no remunerada o suspensión <span class="muted small">(el Ministerio del Trabajo dice que no se descuentan; márquelo solo si así lo decidió la empresa)</span></span></label>`}
        <${DescontarDias} k=${k} o=${o} setO=${setO} />
      </div>
    </div>`;
  };

  const bloques = {
    cesantias: () => bloqueCesPrima('cesantias'),
    prima: () => bloqueCesPrima('prima'),
    disfrute: () => html`<div class="pila parte" key="disfrute">${subtitulo('disfrute')}<div class="campos">
      <${Campo} etiqueta="Sale a vacaciones el" requerido id=${idDe('liq-hasta', 'disfrute')}><input id=${idDe('liq-hasta', 'disfrute')} type="date" value=${D('disfrute').hasta} onInput=${(ev) => setD('disfrute', { hasta: ev.target.value })} /></${Campo}>
      <${Campo} etiqueta="Días hábiles que va a descansar" requerido id="liq-dd" ayuda=${e ? `Hoy tiene ${num(e.vacaciones.pendientes, 2)} días ganados sin tomar. Un periodo completo son 15.` : ''}>
        <input id="liq-dd" inputmode="numeric" value=${o.dias_disfrute} onInput=${(ev) => setO({ ...o, dias_disfrute: ev.target.value.replace(/\D/g, '') })} />
      </${Campo}>
      <label class="check ancho"><input type="checkbox" checked=${o.trabaja_sabados} onChange=${(ev) => setO({ ...o, trabaja_sabados: ev.target.checked })} /><span>Trabaja los sábados <span class="muted small">(si no, los sábados no cuentan como día de vacaciones; domingos y festivos nunca cuentan)</span></span></label>
      <label class="check ancho"><input type="checkbox" checked=${o.descontar_aportes} onChange=${(ev) => setO({ ...o, descontar_aportes: ev.target.checked })} /><span>Descontarle su parte de salud y pensión (4 % + 4 %) de las vacaciones</span></label>
      <p class="small muted ancho">Al guardar, los días quedan descontados de su saldo de vacaciones: no hay que registrarlos aparte en la ficha.</p>
    </div></div>`,
    vacaciones: () => html`<div class="pila parte" key="vacaciones">${subtitulo('vacaciones')}<div class="campos">
      <${Campo} etiqueta="Con corte al" id=${idDe('liq-hasta', 'vacaciones')}><input id=${idDe('liq-hasta', 'vacaciones')} type="date" value=${D('vacaciones').hasta} onInput=${(ev) => setD('vacaciones', { hasta: ev.target.value })} /></${Campo}>
      <${Campo} etiqueta="Días a pagar en dinero" requerido id="liq-dv" ayuda=${e ? (e.vacaciones.tope_dinero > 0 ? `Mientras siga trabajando se puede pagar en dinero hasta la mitad de los periodos ya cumplidos: hoy, máximo ${num(e.vacaciones.tope_dinero)} días. El resto tiene que disfrutarlo.` : 'Todavía no tiene un periodo cumplido (o ya se le pagó la mitad permitida): no se puede pagar en dinero.') : ''}>
        <input id="liq-dv" inputmode="decimal" value=${o.dias_vacaciones} placeholder=${e?.vacaciones.tope_dinero > 0 ? 'Máximo ' + num(e.vacaciones.tope_dinero) : ''} onInput=${(ev) => setO({ ...o, dias_vacaciones: ev.target.value.replace(',', '.') })} />
      </${Campo}>
      <label class="check ancho"><input type="checkbox" checked=${o.solicitud_escrita} onChange=${(ev) => setO({ ...o, solicitud_escrita: ev.target.checked })} /><span>El trabajador lo pidió por escrito y hay un acuerdo firmado <span class="muted small">(Art. 189 CST)</span></span></label>
    </div></div>`,
    definitiva: () => html`<div class="campos" key="definitiva">
      <${Campo} etiqueta="Último día de trabajo" requerido id="liq-hasta"><input id="liq-hasta" type="date" value=${D('definitiva').hasta} onInput=${(ev) => setD('definitiva', { hasta: ev.target.value })} /></${Campo}>
      <${Campo} etiqueta="Motivo del retiro" requerido id="liq-mot">
        <select id="liq-mot" value=${o.motivo_retiro} onChange=${(ev) => setO({ ...o, motivo_retiro: ev.target.value })}><option value="">Escoja…</option>${Object.entries(MOTIVOS).map(([k, v]) => html`<option value=${k}>${v}</option>`)}</select>
      </${Campo}>
      <${Campo} etiqueta="Días de sueldo que se le deben" id="liq-dsp" ayuda="Del último mes, si no se le han pagado por nómina. Si ya se pagaron, deje 0. Todo mes cuenta 30: la segunda quincena siempre es de 15 días, aunque el mes tenga 28 o 31.">
        <input id="liq-dsp" inputmode="numeric" value=${o.dias_salario_pendiente} placeholder="0" onInput=${(ev) => setO({ ...o, dias_salario_pendiente: ev.target.value.replace(/\D/g, '') })} />
      </${Campo}>
      ${Number(o.dias_salario_pendiente) > 0 && html`<label class="check"><input type="checkbox" checked=${o.descontar_aportes} onChange=${(ev) => setO({ ...o, descontar_aportes: ev.target.checked })} /><span>Descontarle su parte de salud y pensión (4 % + 4 %) de ese sueldo</span></label>`}
      ${o.motivo_retiro === 'sin_justa_causa' && html`<label class="check ancho"><input type="checkbox" checked=${o.sin_fuero_verificado} onChange=${(ev) => setO({ ...o, sin_fuero_verificado: ev.target.checked })} /><span>Verifiqué que <b>no</b> está en embarazo o lactancia, con incapacidad o restricciones de salud, a menos de 3 años de pensionarse, ni con fuero sindical <span class="muted small">(si lo está, el despido puede necesitar permiso del Ministerio del Trabajo o de un juez)</span></span></label>`}
      ${o.motivo_retiro && o.motivo_retiro !== 'fallecimiento' && html`<div class="campo ancho pila" style="--g:8px">
        <span class="etiqueta">Lo que se le entrega (la ley lo exige)</span>
        <label class="check"><input type="checkbox" checked=${o.constancia_seguridad_social} onChange=${(ev) => setO({ ...o, constancia_seguridad_social: ev.target.checked })} /><span>Constancia de pago de salud, pensión y parafiscales de los últimos 3 meses <span class="muted small">(Ley 789 de 2002)</span></span></label>
        <label class="check"><input type="checkbox" checked=${o.examen_egreso} onChange=${(ev) => setO({ ...o, examen_egreso: ev.target.checked })} /><span>Orden para el examen médico de egreso <span class="muted small">(Res. 1843 de 2025)</span></span></label>
        <label class="check"><input type="checkbox" checked=${o.certificado_laboral} onChange=${(ev) => setO({ ...o, certificado_laboral: ev.target.checked })} /><span>Certificado laboral <span class="muted small">(Art. 57 CST · después de guardar, sale en su ficha → Certificado laboral)</span></span></label>
      </div>`}
      ${ficha?.novedades?.length > 0 && html`<label class="check ancho"><input type="checkbox" checked=${o.prima_descuenta_no_remunerados} onChange=${(ev) => setO({ ...o, prima_descuenta_no_remunerados: ev.target.checked })} /><span>Descontar de la prima los días de licencia no remunerada o suspensión <span class="muted small">(el Ministerio del Trabajo dice que no; márquelo solo si así lo decidió la empresa)</span></span></label>`}
      ${o.motivo_retiro && D('definitiva').hasta && html`<${AjustesDefinitiva} o=${o} setO=${setO} r=${r} e=${e} />`}
    </div>`,
  };

  const conPrestaciones = tipos.some((k) => k === 'cesantias' || k === 'prima' || k === 'definitiva');
  const conVacaciones = tipos.some((k) => k === 'vacaciones' || k === 'disfrute' || k === 'definitiva');

  return html`<div class="pila">
    <div class="encabezado"><div><h1>${corrigiendo ? `Corregir la liquidación N.º ${corrigiendo.consecutivo}` : 'Liquidar a un trabajador'}</h1><p class="sub">${corrigiendo ? 'Está abierta con sus mismos datos: cambie lo que haga falta. El cálculo se ve a la derecha.' : 'Escoja a quién y qué. El cálculo se ve a la derecha mientras llena los datos.'}</p></div></div>
    <div class="lado">
      <div class="pila">
        ${corrigiendo && html`<div class="panel corrigiendo"><div class="panel-cuerpo pila">
          <p>Al guardar, la liquidación <b>N.º ${corrigiendo.consecutivo}</b> queda <b>anulada</b> (no se borra: sigue en el historial con el motivo) y esta la reemplaza con un número nuevo. Lo que ya se firmó no se escribe por encima: así lo exige el control legal.</p>
          <${Campo} etiqueta="¿Qué se corrige?" requerido id="liq-corr" ayuda="Queda en el registro y en la liquidación anulada.">
            <input id="liq-corr" value=${motivoCorr} placeholder="Ej.: se le descuentan 2 días por las faltas del 3 y 4 de octubre" onInput=${(ev) => setMotivoCorr(ev.target.value)} />
          </${Campo}>
          <div><a class="btn chico" href=${'#/liquidacion/' + corrigiendo.id}>Cancelar la corrección</a></div>
        </div></div>`}
        <div class="panel"><div class="panel-cuerpo pila">
          <h3>1. Trabajador</h3>
          ${trab ? html`<div class="elegido"><div><b>${trab.nombre}</b><div class="small muted">${trab.tipo_documento} ${trab.documento} · ingresó ${fCorta(trab.fecha_ingreso)}${trab.sede ? ' · ' + trab.sede : ''}</div></div>
              ${!corrigiendo && html`<button class="btn chico" onClick=${() => { setTrab(null); setFicha(null); setR(null); setTipos([]); setFx({}); }}>Cambiar</button>`}</div>
            ${retirado && html`<${Aviso} tipo="bad">Ya se retiró el ${fLarga(trab.fecha_retiro)}. Si hay un error en su liquidación definitiva, ábrala desde su ficha o el historial y use «Corregir».</${Aviso}>`}`
          : html`<${BuscadorTrabajador} autoFocus onElegir=${elegir} />`}
        </div></div>

        ${trab && !retirado && html`<div class="panel"><div class="panel-cuerpo pila">
          <div><h3>2. Qué se va a liquidar</h3>
            <p class="small muted" style="margin-top:3px">Puede marcar varias (por ejemplo, la prima y las vacaciones que va a tomar): salen juntas en un solo comprobante. La liquidación definitiva va sola, porque ya incluye todo.</p></div>
          <div class="opciones">${Object.keys(TIPOS).map((k) => {
            const no = integral && (k === 'cesantias' || k === 'prima');
            return html`<button class=${'opcion marcable' + (tiene(k) ? ' activo' : '')} disabled=${no} aria-pressed=${tiene(k)} onClick=${() => alternar(k)} style=${no ? 'opacity:.5;cursor:not-allowed' : ''}>
              <i class="caja" aria-hidden="true"></i><b>${TIPOS[k]}</b><span>${no ? 'No aplica: salario integral.' : DESCRIPCION[k]}</span></button>`;
          })}</div>
        </div></div>`}

        ${trab && !retirado && tipos.length > 0 && html`<div class="panel"><div class="panel-cuerpo pila">
          <h3>3. Fechas y detalles</h3>
          ${ORDEN.filter(tiene).map((k) => bloques[k]())}

          ${trab.tipo_salario !== 'integral' && html`<details class="plegable" open=${trab.tipo_salario === 'variable' && !ficha?.nomina_meses?.n}>
            <summary>¿Gana horas extra, recargos o comisiones?</summary>
            <div class="campos">
              ${conPrestaciones && html`<${Campo} etiqueta="Promedio mensual de lo variable" id="liq-var" ayuda=${ficha?.nomina_meses?.n ? 'Si lo deja en blanco se calcula con la nómina cargada.' : 'No hay nómina cargada. Promedio mensual del último año (para la prima, del semestre): horas extra, recargos, comisiones.'}>
                <${InputPesos} id="liq-var" valor=${o.variable_manual} placeholder="Sin variable" onCambio=${(v) => setO({ ...o, variable_manual: v })} />
              </${Campo}>`}
              ${conVacaciones && html`<${Campo} etiqueta="Promedio mensual para vacaciones" id="liq-varv" ayuda="Igual que el anterior pero SIN horas extra ni trabajo en domingos y festivos (el recargo nocturno sí cuenta).">
                <${InputPesos} id="liq-varv" valor=${o.variable_manual_vacaciones} placeholder="Sin variable" onCambio=${(v) => setO({ ...o, variable_manual_vacaciones: v })} />
              </${Campo}>`}
            </div>
          </details>`}

          <details class="plegable" open=${o.otros_devengos.length > 0 || o.deducciones.length > 0}>
            <summary>Otros pagos o descuentos (préstamos, anticipos…)</summary>
            <div class="pila">
              <${LineasExtra} titulo="Otros pagos" placeholder="Ej.: bonificación" lineas=${o.otros_devengos} onCambio=${(v) => setO({ ...o, otros_devengos: v })} />
              <${LineasExtra} titulo="Descuentos" placeholder="Ej.: saldo de préstamo" lineas=${o.deducciones} onCambio=${(v) => setO({ ...o, deducciones: v })} />
              <p class="small muted">Los descuentos tienen que estar autorizados por escrito por el trabajador (Art. 149 CST).</p>
            </div>
          </details>

          <${Campo} etiqueta="Fecha del comprobante" id="liq-fecha" ayuda="El día en que se hace el pago o se firma."><input id="liq-fecha" type="date" style="max-width:220px" value=${fecha} onInput=${(ev) => setFecha(ev.target.value)} /></${Campo}>
          <${ElegirSoportes} lista=${soportes} onCambio=${setSoportes} id="liq-soporte" />
        </div></div>`}
      </div>

      <div class="panel" style="position:sticky;top:16px">
        <div class="panel-cab"><h2>Resultado</h2>${calculando && html`<span class="small muted">Calculando…</span>`}</div>
        <div class="panel-cuerpo pila">
          ${!trab ? html`<p class="muted">Escoja un trabajador para empezar.</p>`
            : !tipos.length ? html`<p class="muted">Escoja qué se va a liquidar.</p>`
            : tiene('definitiva') && !o.motivo_retiro ? html`<p class="muted">Escoja el motivo del retiro.</p>`
            : error ? html`<${Aviso} tipo="bad">${error}</${Aviso}>`
            : !r ? html`<${Cargando} texto="Calculando…" />`
            : html`
              ${r.tipo === 'varios'
                ? html`<div class="small muted"><b>Un solo comprobante con:</b>${r.partes.map((p) => html`<div>${TIPOS[p.tipo]} · ${p.tipo === 'vacaciones' ? 'corte ' + fCorta(p.hasta) : `${fCorta(p.desde)} → ${fCorta(p.hasta)}`}</div>`)}</div>`
                : html`<div class="small muted">${TIPOS[r.tipo]} · ${r.tipo === 'vacaciones' ? 'corte ' + fCorta(r.hasta) : `${fCorta(r.desde)} → ${fCorta(r.hasta)}`}</div>`}
              <${ResumenCalculo} r=${r} />
              ${r.bloqueos.map((a) => html`<${Aviso} tipo="bad"><b>Falta algo para poder guardar:</b> ${a}</${Aviso}>`)}
              ${r.avisos.map((a) => html`<${Aviso}>${a}</${Aviso}>`)}
              ${corrigiendo && motivoCorr.trim().length < 5 && html`<${Aviso} tipo="info">Escriba arriba qué se corrige para poder guardar.</${Aviso}>`}
              <button class="btn primario grande" style="width:100%" disabled=${guardando || calculando || r.bloqueos.length > 0 || (corrigiendo && motivoCorr.trim().length < 5)} onClick=${guardar}><${Icono} n="ok" />${corrigiendo ? 'Guardar la corrección' : 'Guardar liquidación'}</button>
            `}
        </div>
      </div>
    </div>
  </div>`;
}

// ---------------------------------------------------------------- todos a la vez

// Los días no se escriben a mano: salen de las fechas. Aquí se corrige la fecha que esté mal y la tabla se recalcula.
function CambiarDias({ x, tipo, onCerrar, onCambio, onEliminar }) {
  const [form, setForm] = useState(null);
  const [trab, setTrab] = useState(null);
  const abrirFicha = async () => {
    try { const d = await api('/api/trabajadores/' + x.id); setTrab({ ...d.trabajador, nombre: x.nombre }); setForm('ficha'); } catch (e) { avisar(e.message, 'error'); }
  };
  if (form === 'ficha' && trab) return html`<${FormTrabajador} inicial=${trab} onCerrar=${onCerrar} onGuardado=${onCambio} />`;
  if (form === 'licencia') return html`<${FormRango} trab=${{ id: x.id }} tipo="novedades" onCerrar=${onCerrar} onListo=${onCambio} />`;
  const queC = tipo === 'cesantias' ? 'las cesantías' : 'la prima';
  return html`<${Modal} titulo=${'Cambiar los días de ' + x.nombre} onCerrar=${onCerrar} pie=${html`<button class="btn" onClick=${onCerrar}>Cancelar</button>`}
    sub=${`Ahora tiene ${x.dias} días: del ${fLarga(x.desde)} al ${fLarga(x.hasta)}. Los días no se escriben a mano, salen de las fechas: escoja qué es lo que cambia y la tabla se recalcula sola.`}>
    <div class="pila" style="--g:10px">
      <button class="opcion" id="cd-ingreso" onClick=${abrirFicha}><b>Entró en otra fecha</b><span>Corrija su fecha de ingreso. Ejemplo: quien entró el 14 de febrero tiene 137 días de prima del primer semestre (cada mes cuenta 30, también febrero).</span></button>
      <button class="opcion" id="cd-pagado" onClick=${abrirFicha}><b>Ya se le había pagado una parte</b><span>En su ficha, ponga hasta qué fecha ya se le liquidó ${queC} (en "Lo que ya se le liquidó antes de usar este programa"). Se le paga desde el día siguiente.</span></button>
      <button class="opcion" id="cd-licencia" onClick=${() => setForm('licencia')}><b>Tuvo licencia no remunerada o suspensión</b><span>${tipo === 'cesantias'
        ? 'Anote las fechas y esos días se restan solos. Todo febrero cuenta 30; dos días al final de febrero cuentan 2.'
        : 'Queda anotada en su ficha, pero en la prima esos días NO se restan: el Ministerio del Trabajo dice que no se descuentan. Si la empresa decide descontarlos, desmárquelo aquí y liquídelo en "Liquidar a uno", donde está esa casilla.'}</span></button>
      <a class="opcion" id="cd-descontar" href=${`#/liquidar?t=${x.id}&tipo=${tipo}`} style="display:block;text-decoration:none;color:inherit"><b>Hay que descontarle días (faltas, una sanción…)</b><span>Se abre "Liquidar a uno" con esta persona: ahí escribe cuántos días, por qué, y adjunta el documento que lo respalda. Al volver, ya no le sale aquí (no se le paga dos veces).</span></a>
      <button class="opcion" id="cd-se-fue" onClick=${onEliminar}><b>Ya no trabaja en la empresa</b><span>Se quita de esta lista: si ya se le pagó todo, solo se marca retirado; si no, se le hace la liquidación definitiva.</span></button>
      <a class="opcion" id="cd-otro" href=${`#/liquidar?t=${x.id}&tipo=${tipo}`} style="display:block;text-decoration:none;color:inherit"><b>Otro caso: liquidarlo aparte</b><span>Se abre "Liquidar a uno" con esta persona, donde puede cambiar las fechas. Al volver, desmárquelo aquí para no pagarle dos veces (el programa tampoco lo deja).</span></a>
      <p class="small muted">Las incapacidades, las vacaciones y las licencias de maternidad o paternidad <b>no</b> bajan los días: cuentan como tiempo trabajado.</p>
    </div>
  </${Modal}>`;
}

export function LiquidarTodos({ query }) {
  const y = Number(hoy().slice(0, 4));
  const [tipo, setTipo] = useState(query.tipo === 'prima' ? 'prima' : query.tipo === 'cesantias' ? 'cesantias' : (new Date().getMonth() >= 10 ? 'prima' : 'cesantias'));
  const [anio, setAnio] = useState(Number(query.anio) || (tipo === 'cesantias' && new Date().getMonth() < 10 ? y - 1 : y));
  const [semestre, setSemestre] = useState(Number(query.semestre) || (new Date().getMonth() >= 6 ? 2 : 1));
  const [sede, setSede] = useState('');
  const [fecha, setFecha] = useState(hoy());
  const [res, setRes] = useState(null);
  const [marcados, setMarcados] = useState(new Set());
  const [cargando, setCargando] = useState(false);
  const [hecho, setHecho] = useState(null);
  const sedes = useDatos('/api/sedes');
  const corte = tipo === 'cesantias' ? `${anio}-12-30` : semestre === 1 ? `${anio}-06-30` : `${anio}-12-30`;

  const [cambiar, setCambiar] = useState(null);
  const [eliminar, setEliminar] = useState(null);
  // mantener: después de corregir los días de alguien se recalcula sin perder lo que ya se había marcado o desmarcado.
  const calcular = async (mantener) => {
    setCargando(true); setHecho(null);
    try {
      const d = await api('/api/masiva/calcular', { metodo: 'POST', cuerpo: { tipo, corte, sede, fecha } });
      // Los que traen periodos anteriores sin pagar quedan sin marcar: hay que revisarlos uno por uno.
      const antes = mantener === true && res ? new Map(res.listos.map((x) => [x.id, marcados.has(x.id)])) : null;
      setRes(d); setMarcados(new Set(d.listos.filter((x) => (antes?.has(x.id) && !x.incluye_anteriores ? antes.get(x.id) : !x.incluye_anteriores)).map((x) => x.id)));
    } catch (e) { avisar(e.message, 'error'); }
    setCargando(false);
  };
  useEffect(() => { setRes(null); setHecho(null); }, [tipo, anio, semestre, sede]);
  useEffect(() => { if (query.tipo) calcular(); }, []);

  const sel = res ? res.listos.filter((x) => marcados.has(x.id)) : [];
  const suma = (k) => sel.reduce((s, x) => s + (x[k] || 0), 0);
  const guardar = async () => {
    const ok = await confirmar({ titulo: `Guardar ${sel.length} liquidaciones`, texto: `Cada una queda con su número en el historial de cada trabajador. Total: ${pesos(suma('principal') + suma('intereses'))}.`, boton: 'Guardar todas' });
    if (!ok) return;
    setCargando(true);
    try {
      const d = await api('/api/masiva/guardar', { metodo: 'POST', cuerpo: { tipo, corte, fecha, ids: sel.map((x) => x.id) } });
      setHecho(d); setRes(null);
      avisar(`${d.creadas.length} liquidaciones guardadas`, 'ok');
    } catch (e) { avisar(e.message, 'error'); }
    setCargando(false);
  };
  const excel = () => {
    const filas = [['Documento', 'Trabajador', 'Sede', 'Fondo de cesantías', 'Desde', 'Hasta', 'Días', 'Base mensual', tipo === 'cesantias' ? 'Cesantías' : 'Prima', ...(tipo === 'cesantias' ? ['Intereses'] : []), 'Al fondo', 'Al trabajador']];
    for (const x of sel) filas.push([x.documento, x.nombre, x.sede || '', x.fondo || '', x.desde, x.hasta, x.dias, x.base, x.principal, ...(tipo === 'cesantias' ? [x.intereses] : []), x.a_fondo, x.neto]);
    filas.push(['', 'TOTAL', '', '', '', '', '', '', suma('principal'), ...(tipo === 'cesantias' ? [suma('intereses')] : []), suma('a_fondo'), suma('neto')]);
    const dinero = tipo === 'cesantias' ? [7, 8, 9, 10, 11] : [7, 8, 9, 10];
    descargarExcel(`${tipo}-${corte}.xlsx`, [{ nombre: tipo === 'cesantias' ? 'Cesantías ' + anio : 'Prima', filas, dinero, anchos: [14, 30, 16, 18, 12, 12, 7, 14, 14, 14, 14, 14], negrita: (r) => r === filas.length - 1, finFiltro: filas.length - 2 }]);
  };

  return html`<div class="pila">
    <div class="encabezado"><div><h1>Liquidar a todos</h1><p class="sub">Para el corte de cesantías de fin de año o la prima del semestre. Primero se ve el cálculo; nada se guarda hasta que lo confirme.</p></div></div>
    <div class="panel"><div class="panel-cuerpo">
      <div class="campos">
        <${Campo} etiqueta="Qué" id="m-tipo"><div class="segmentado" id="m-tipo">
          <button class=${tipo === 'cesantias' ? 'activo' : ''} onClick=${() => setTipo('cesantias')}>Cesantías e intereses</button>
          <button class=${tipo === 'prima' ? 'activo' : ''} onClick=${() => setTipo('prima')}>Prima</button></div></${Campo}>
        <${Campo} etiqueta="Año" id="m-anio"><select id="m-anio" value=${anio} onChange=${(e) => setAnio(Number(e.target.value))}>${[y + 1, y, y - 1, y - 2, y - 3].map((a) => html`<option value=${a}>${a}</option>`)}</select></${Campo}>
        ${tipo === 'prima' && html`<${Campo} etiqueta="Semestre" id="m-sem"><select id="m-sem" value=${semestre} onChange=${(e) => setSemestre(Number(e.target.value))}><option value="1">Primero (pago en junio)</option><option value="2">Segundo (pago en diciembre)</option></select></${Campo}>`}
        ${sedes.datos?.length > 0 && html`<${Campo} etiqueta="Sede" id="m-sede"><select id="m-sede" value=${sede} onChange=${(e) => setSede(e.target.value)}><option value="">Todas</option>${sedes.datos.map((s) => html`<option>${s}</option>`)}</select></${Campo}>`}
      </div>
      <div class="fila" style="margin-top:14px"><button class="btn primario" onClick=${() => calcular()} disabled=${cargando}>${cargando ? 'Calculando…' : `Calcular con corte al ${fCorta(corte)}`}</button>
        <span class="small muted">Cada mes cuenta 30 días, también febrero: ${tipo === 'prima' ? 'el semestre completo son 180' : 'el año completo son 360'}.</span></div>
    </div></div>

    ${hecho && html`<${Aviso} tipo="ok"><b>Listo: se guardaron ${hecho.creadas.length} liquidaciones</b> (N.º ${hecho.creadas[0]?.consecutivo} a ${hecho.creadas[hecho.creadas.length - 1]?.consecutivo}).
      <div class="fila" style="margin-top:8px"><a class="btn chico" href=${'#/lote/' + encodeURIComponent(hecho.lote)}><${Icono} n="imprimir" />Imprimir todos los comprobantes</a><a class="btn chico" href=${'#/historial?lote=' + encodeURIComponent(hecho.lote)}>Verlas en el historial</a></div></${Aviso}>`}

    ${res?.futuro && html`<${Aviso}>Está liquidando hasta el <b>${fLarga(res.corte)}</b> y hoy es ${fLarga(hoy())}: incluye días que todavía no se han trabajado. Si alguien se retira antes, se le habrá pagado de más. Lo normal es hacerlo en ${tipo === 'prima' && semestre === 1 ? 'junio' : 'diciembre'}.</${Aviso}>`}
    ${res && html`<div class="panel">
      <div class="panel-cab"><div><h2>${res.listos.length} para liquidar</h2><p class="small muted">${sel.length} marcados · Total ${pesos(suma('principal') + suma('intereses'))}${suma('a_fondo') ? ` · al fondo ${pesos(suma('a_fondo'))}` : ''} · a los trabajadores ${pesos(suma('neto'))}</p></div>
        <div class="acciones"><button class="btn chico" onClick=${excel} disabled=${!sel.length}><${Icono} n="excel" />Excel</button></div></div>
      ${res.listos.length === 0 ? (res.omitidos?.length ? html`<div class="vacio"><b>No hay nadie pendiente con ese corte</b>Todos ya están liquidados o no aplican.</div>` : html`<div class="vacio"><b>No hay trabajadores para ese corte</b>¿Ya los cargó? Súbalos en <a href="#/importar">Importar de Excel</a> y vuelva acá.</div>`) : html`<div class="tabla-scroll"><table class="tabla">
        <thead><tr><th><input type="checkbox" aria-label="Marcar todos" checked=${sel.length === res.listos.length} onChange=${(e) => setMarcados(new Set(e.target.checked ? res.listos.map((x) => x.id) : []))} /></th>
          <th>Trabajador</th><th>Periodo</th><th class="num">Días</th><th class="num">Base</th><th class="num">${tipo === 'cesantias' ? 'Cesantías' : 'Prima'}</th>${tipo === 'cesantias' && html`<th class="num">Intereses</th>`}<th></th></tr></thead>
        <tbody>${res.listos.map((x) => html`<tr key=${x.id}>
          <td><input type="checkbox" aria-label=${'Marcar ' + x.nombre} checked=${marcados.has(x.id)} onChange=${(e) => { const s = new Set(marcados); e.target.checked ? s.add(x.id) : s.delete(x.id); setMarcados(s); }} /></td>
          <td><a href=${'#/trabajador/' + x.id}><b>${x.nombre}</b></a><div class="doc">${x.documento}${x.sede ? ' · ' + x.sede : ''}</div>
            ${x.desde_ingreso ? html`<div class="small" style="color:var(--warn);margin-top:3px">Nunca se le ha liquidado ${tipo === 'cesantias' ? 'cesantías' : 'prima'}: se calcula desde que entró (${fCorta(x.desde)}). Si ya se le pagó antes, corrija su ficha. Quedó sin marcar.</div>`
              : x.incluye_anteriores ? html`<div class="small" style="color:var(--warn);margin-top:3px">Incluye también del ${fCorta(x.desde)} al ${fCorta(sumarDias(x.inicio, -1))}, que figura sin pagar. Si ya se pagó, corrija "liquidada hasta" en su ficha. Quedó sin marcar.</div>` : ''}</td>
          <td class="nowrap">${fCorta(x.desde)} → ${fCorta(x.hasta)}</td><td class="num">${x.dias}</td><td class="num">${pesos(x.base)}</td>
          <td class="num">${pesos(x.principal)}</td>${tipo === 'cesantias' && html`<td class="num">${pesos(x.intereses)}</td>`}
          <td class="nowrap">${!x.incluye_anteriores && x.avisos.length > 0 && html`<span class="chip warn" title=${x.avisos.join('\n')}>Ver nota</span>`}
            <button class="btn chico" aria-label=${'Cambiar días de ' + x.nombre} onClick=${() => setCambiar(x)}>Cambiar días</button>
            <button class="btn chico basura-fila" title="Ya no trabaja aquí: quitarlo" aria-label=${'Eliminar a ' + x.nombre} onClick=${() => setEliminar(x)}><${Icono} n="basura" /></button></td>
        </tr>`)}</tbody>
        <tfoot><tr><td></td><td>Total marcados</td><td></td><td></td><td></td><td class="num">${pesos(suma('principal'))}</td>${tipo === 'cesantias' && html`<td class="num">${pesos(suma('intereses'))}</td>`}<td></td></tr></tfoot>
      </table></div>
      <div class="panel-cuerpo fila entre" style="border-top:1px solid var(--line)">
        <${Campo} etiqueta="Fecha de los comprobantes" id="m-fecha"><input id="m-fecha" type="date" value=${fecha} onInput=${(e) => setFecha(e.target.value)} /></${Campo}>
        <button class="btn primario grande" disabled=${!sel.length || cargando} onClick=${guardar}><${Icono} n="ok" />Guardar ${sel.length} liquidaciones</button>
      </div>`}
      ${res.omitidos.length > 0 && html`<div class="panel-cuerpo" style="border-top:1px solid var(--line)"><details class="plegable"><summary>${res.omitidos.length} no se incluyen (ver por qué)</summary>
        <table class="tabla"><tbody>${res.omitidos.map((x) => html`<tr key=${x.id}><td><a href=${'#/trabajador/' + x.id}>${x.nombre}</a><div class="doc">${x.documento}</div></td><td class="small muted">${x.motivo}</td></tr>`)}</tbody></table>
      </details></div>`}
    </div>`}
    ${cambiar && html`<${CambiarDias} x=${cambiar} tipo=${tipo} onCerrar=${() => setCambiar(null)} onCambio=${() => { setCambiar(null); calcular(true); }} onEliminar=${() => { setEliminar(cambiar); setCambiar(null); }} />`}
    ${eliminar && html`<${EliminarTrabajador} trab=${{ id: eliminar.id, nombre: eliminar.nombre, fecha_retiro: null }} onCerrar=${() => setEliminar(null)}
      onListo=${() => { setEliminar(null); calcular(true); }} onBorrado=${() => { setEliminar(null); calcular(true); }} />`}
  </div>`;
}
