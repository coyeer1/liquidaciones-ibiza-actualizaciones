import { html, useState, useEffect } from './vendor/preact-htm.js';
import { api, pesos, hoy, usuarioActual } from './util.js';
import { Icono, Campo, InputPesos, Aviso, Cargando, useDatos, avisar, confirmar, Modal } from './comp.js';
import { FormEmpresa } from './inicio.js';

function Parametros() {
  const { datos, recargar } = useDatos('/api/parametros');
  const [edit, setEdit] = useState(null);
  const guardar = async () => {
    try { await api('/api/parametros/' + edit.anio, { metodo: 'PUT', cuerpo: edit }); avisar('Valores guardados', 'ok'); setEdit(null); recargar(); } catch (e) { avisar(e.message, 'error'); }
  };
  const siguiente = datos?.length ? datos[0].anio + 1 : Number(hoy().slice(0, 4));
  return html`<div class="panel">
    <div class="panel-cab"><div><h2>Salario mínimo y auxilio de transporte</h2><p class="small muted">Los fija el Gobierno cada diciembre. Cuando salga el del año nuevo, agréguelo aquí.</p></div>
      <div class="acciones"><button class="btn chico" onClick=${() => setEdit({ anio: siguiente, smmlv: null, auxilio_transporte: null, nuevo: true })}><${Icono} n="mas" />Agregar ${siguiente}</button></div></div>
    ${!datos ? html`<${Cargando} />` : html`<div class="tabla-scroll" style="max-height:320px"><table class="tabla">
      <thead><tr><th>Año</th><th class="num">Salario mínimo</th><th class="num">Auxilio de transporte</th><th class="num">2 mínimos (tope auxilio)</th><th></th></tr></thead>
      <tbody>${datos.map((p) => html`<tr key=${p.anio}><td><b>${p.anio}</b></td><td class="num">${pesos(p.smmlv)}</td><td class="num">${pesos(p.auxilio_transporte)}</td><td class="num muted">${pesos(p.smmlv * 2)}</td>
        <td><button class="btn link small" onClick=${() => setEdit({ ...p })}>Cambiar</button></td></tr>`)}</tbody></table></div>`}
    ${edit && html`<${Modal} titulo=${(edit.nuevo ? 'Agregar ' : 'Cambiar ') + edit.anio} onCerrar=${() => setEdit(null)}
      pie=${html`<button class="btn" onClick=${() => setEdit(null)}>Cancelar</button><button class="btn primario" disabled=${!edit.smmlv || edit.auxilio_transporte == null} onClick=${guardar}>Guardar</button>`}>
      <div class="campos">
        ${edit.nuevo && html`<${Campo} etiqueta="Año" id="p-a"><input id="p-a" type="number" value=${edit.anio} onInput=${(e) => setEdit({ ...edit, anio: Number(e.target.value) })} /></${Campo}>`}
        <${Campo} etiqueta="Salario mínimo mensual" id="p-s"><${InputPesos} id="p-s" valor=${edit.smmlv} onCambio=${(v) => setEdit({ ...edit, smmlv: v })} /></${Campo}>
        <${Campo} etiqueta="Auxilio de transporte" id="p-x"><${InputPesos} id="p-x" valor=${edit.auxilio_transporte} onCambio=${(v) => setEdit({ ...edit, auxilio_transporte: v })} /></${Campo}>
        <${Campo} etiqueta="Nota (decreto)" id="p-n" ancho><input id="p-n" value=${edit.nota || ''} onInput=${(e) => setEdit({ ...edit, nota: e.target.value })} placeholder="Ej.: Decreto 1469 de 2025" /></${Campo}>
      </div>
      <p class="small muted" style="margin-top:12px">Las liquidaciones ya guardadas no cambian: conservan los valores con que se hicieron.</p>
    </${Modal}>`}
  </div>`;
}

function Usuarios() {
  const { datos, recargar } = useDatos('/api/usuarios');
  const [nuevo, setNuevo] = useState('');
  const agregar = async (e) => {
    e.preventDefault();
    try { await api('/api/usuarios', { metodo: 'POST', cuerpo: { nombre: nuevo } }); setNuevo(''); recargar(); } catch (err) { avisar(err.message, 'error'); }
  };
  const quitar = async (u) => {
    if (!(await confirmar({ titulo: `Quitar a ${u.nombre}`, texto: 'Deja de salir en la lista. Lo que ya hizo sigue en el historial con su nombre.', boton: 'Quitar' }))) return;
    try { await api('/api/usuarios/' + u.id, { metodo: 'DELETE' }); recargar(); } catch (err) { avisar(err.message, 'error'); }
  };
  return html`<div class="panel">
    <div class="panel-cab"><div><h2>Personas que usan el programa</h2><p class="small muted">Para saber quién hizo cada liquidación.</p></div></div>
    <div class="panel-cuerpo pila">
      <div class="fila">${(datos || []).map((u) => html`<span class="chip" key=${u.id} style="padding:5px 6px 5px 12px;font-size:14px">${u.nombre}${u.nombre === usuarioActual() ? ' (usted)' : ''}
        ${u.nombre !== usuarioActual() && html`<button class="cerrar" style="padding:1px" title="Quitar" aria-label=${'Quitar a ' + u.nombre} onClick=${() => quitar(u)}><${Icono} n="x" style="width:15px;height:15px" /></button>`}</span>`)}</div>
      <form class="fila" onSubmit=${agregar}><input style="max-width:280px" placeholder="Nombre de otra persona" value=${nuevo} onInput=${(e) => setNuevo(e.target.value)} aria-label="Nombre" /><button class="btn" disabled=${!nuevo.trim()}>Agregar</button></form>
    </div>
  </div>`;
}

// Botón para traer todos los datos desde un archivo de copia (.db). Se usa en Ajustes y en la bienvenida de un computador nuevo.
export function BotonRestaurar({ texto = 'Restaurar desde una copia', primario = false }) {
  const [restaurando, setRestaurando] = useState(false);
  const restaurar = async (f) => {
    if (!f) return;
    const ok = await confirmar({
      titulo: 'Reemplazar los datos con esta copia',
      texto: html`<div class="pila"><p>Todo lo que hay ahora en el programa se cambia por lo que trae <b>${f.name}</b>.</p><p class="muted">Antes de hacerlo se guarda una copia automática de lo actual, por si acaso.</p></div>`,
      boton: 'Sí, reemplazar', peligro: true,
    });
    if (!ok) return;
    setRestaurando(true);
    try {
      await api('/api/restaurar', { metodo: 'POST', crudo: await f.arrayBuffer() });
      avisar('Datos restaurados', 'ok');
      setTimeout(() => location.reload(), 800);
    } catch (e) { avisar(e.message, 'error'); }
    setRestaurando(false);
  };
  return html`<label class=${'btn' + (primario ? ' primario' : '')} style="width:fit-content"><${Icono} n="subir" />${restaurando ? 'Restaurando…' : texto}<input type="file" class="sr" accept=".db" onChange=${(e) => { restaurar(e.target.files[0]); e.target.value = ''; }} /></label>`;
}

function Respaldo() {
  const { datos: info, recargar } = useDatos('/api/info');
  if (!info) return html`<${Cargando} />`;
  const mb = (info.tamano / 1024 / 1024).toLocaleString('es-CO', { maximumFractionDigits: 1 });
  const abrir = () => api('/api/abrir-carpeta', { metodo: 'POST' }).catch((e) => avisar(e.message, 'error'));
  const acceso = () => api('/api/acceso-directo', { metodo: 'POST' }).then(() => avisar('Listo: quedó el ícono "Liquidaciones" en el escritorio', 'ok')).catch((e) => avisar(e.message, 'error'));
  return html`<div class="panel">
    <div class="panel-cab"><div><h2>Copias de seguridad y cambio de computador</h2><p class="small muted">Todo se guarda en este computador, en un solo archivo.</p></div></div>
    <div class="panel-cuerpo pila">
      <div class="dos-col">
        <div class="pila">
          <div><div class="small muted">Los datos están en esta carpeta</div><div class="ruta">${info.datos}</div></div>
          <p class="small muted">${info.conteos.trabajadores} trabajadores · ${info.conteos.liquidaciones} liquidaciones · ${mb} MB.
            El programa guarda solo una copia cada día que se abre (las últimas 30, en la carpeta <span class="kbd">respaldos</span>).${info.respaldos[0] ? ' Última: ' + info.respaldos[0].replace(/\.db$/, '') + '.' : ''}</p>
          <div class="fila">
            <a class="btn primario" href="/api/respaldo" onClick=${(e) => { e.preventDefault(); descargarRespaldo(); }}><${Icono} n="descargar" />Descargar una copia ahora</a>
            <button class="btn" onClick=${abrir}><${Icono} n="carpeta" />Abrir la carpeta</button>
          </div>
          <${BotonRestaurar} />
        </div>
        <div class="pila">
          <h3>Para pasar todo a otro computador</h3>
          <div class="aviso info"><div>En este computador hay <b>${info.conteos.trabajadores} trabajadores</b> y <b>${info.conteos.liquidaciones} liquidaciones</b>${info.ultima ? html`; la última es la <b>N.º ${info.ultima.consecutivo}</b>, hecha el ${info.ultima.creado_en.slice(0, 10)}` : ''}.</div></div>
          <ol class="pasos">
            <li>Cierre el programa con el botón de abajo (o cierre la ventana y espere un minuto).</li>
            <li>Copie la carpeta <b>Liquidaciones</b> completa (por ejemplo a una memoria USB).</li>
            <li>Péguela en el otro computador (por ejemplo en <span class="kbd">C:\\</span>) y abra <b>Liquidaciones.exe</b>.</li>
          </ol>
          <p class="small muted">Si el otro computador ya tiene el programa, basta con copiar la carpeta <span class="kbd">datos</span> encima de la que tiene. <b>Antes, compare</b>: abra esta misma pantalla allá; si allá la última liquidación tiene un número MAYOR, no reemplace, porque se perdería ese trabajo. Use el programa en un solo computador a la vez.</p>
          <div><button class="btn" onClick=${cerrarPrograma}>Cerrar el programa</button></div>
          <div><button class="btn" onClick=${acceso}><${Icono} n="escritorio" />Poner el ícono en el escritorio</button></div>
        </div>
      </div>
    </div>
  </div>`;
}

async function cerrarPrograma() {
  const ok = await confirmar({ titulo: 'Cerrar el programa', texto: 'Se guarda todo y el programa se cierra. Después ya puede copiar la carpeta. Para volver a abrirlo, use el ícono Liquidaciones.', boton: 'Cerrar' });
  if (!ok) return;
  try { await api('/api/cerrar', { metodo: 'POST' }); } catch {}
  document.body.innerHTML = '<div style="display:grid;place-items:center;height:100vh;font:16px Segoe UI,sans-serif;color:#333;text-align:center"><div><h2 style="margin:0 0 8px">El programa se cerró</h2><p>Ya puede cerrar esta ventana y copiar la carpeta.</p></div></div>';
  try { window.close(); } catch {}
}

async function descargarRespaldo() {
  try {
    const r = await fetch('/api/respaldo', { headers: { 'X-Liq': '1', 'X-Usuario': encodeURIComponent(usuarioActual()) } });
    if (!r.ok) throw new Error('No se pudo hacer la copia.');
    const blob = await r.blob();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `respaldo-liquidaciones-${hoy()}.db`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    avisar('Copia descargada: búsquela en la carpeta Descargas', 'ok');
  } catch (e) { avisar(e.message, 'error'); }
}

// Versiones nuevas del programa: se bajan de internet ya firmadas; los datos se quedan en este computador.
export async function esperarVersion(nueva) {
  for (let i = 0; i < 90; i++) {
    await new Promise((ok) => setTimeout(ok, 1000));
    try { const p = await fetch('/api/ping').then((x) => x.json()); if (p.version === nueva) { location.reload(); return true; } } catch {}
  }
  return false;
}

function Actualizaciones() {
  const [e, setE] = useState({ cargando: true });
  const [aplicando, setAplicando] = useState(false);
  const [auto, setAuto] = useState(null);
  useEffect(() => { api('/api/auto-actualizacion').then(setAuto).catch(() => {}); }, []);
  const cambiarAuto = async (activa) => {
    try { await api('/api/auto-actualizacion', { metodo: 'PUT', cuerpo: { activa } }); setAuto((x) => ({ ...x, activa })); avisar(activa ? 'Se va a actualizar solo' : 'Ya no se actualiza solo: hay que darle "Actualizar ahora"', 'ok'); } catch (err) { avisar(err.message, 'error'); }
  };
  const buscar = async () => {
    setE({ cargando: true });
    try { setE({ datos: await api('/api/actualizacion') }); } catch (err) { setE({ error: err.message }); }
  };
  useEffect(() => { buscar(); }, []);
  const d = e.datos;
  const actualizar = async () => {
    const ok = await confirmar({
      titulo: `Actualizar a la versión ${d.nueva}`,
      texto: html`<div class="pila"><p>El programa se cierra unos segundos y vuelve a abrir solo.</p><p class="muted">Los trabajadores y las liquidaciones no se tocan: antes se guarda una copia de todo, por si acaso.</p></div>`,
      boton: 'Actualizar ahora',
    });
    if (!ok) return;
    setAplicando(true);
    try { await api('/api/actualizar', { metodo: 'POST' }); } catch (err) { avisar(err.message, 'error'); setAplicando(false); return; }
    if (!(await esperarVersion(d.nueva))) { avisar('El programa no volvió a abrir solo: ciérrelo y ábralo de nuevo con el ícono.', 'error'); setAplicando(false); }
  };
  return html`<div class="panel" id="actualizaciones">
    <div class="panel-cab"><div><h2>Actualizaciones del programa</h2><p class="small muted">Las mejoras llegan por internet. Solo cambia el programa: los datos se quedan en este computador.</p></div>
      <div class="acciones"><button class="btn chico" onClick=${buscar} disabled=${e.cargando || aplicando}>${e.cargando ? 'Buscando…' : 'Buscar de nuevo'}</button></div></div>
    <div class="panel-cuerpo pila">
      ${auto?.instalada && html`<label class="check"><input type="checkbox" id="act-solo" checked=${auto.activa} onChange=${(ev) => cambiarAuto(ev.target.checked)} />
        <span><b>Que se actualice solo</b> (recomendado). Cuando sale una versión nueva, se instala sola al abrir el programa, antes de empezar a trabajar, o al cerrarlo. Nadie tiene que hacer nada. Siempre guarda antes una copia de los datos.</span></label>`}
      ${e.cargando ? html`<p class="small muted">Buscando si hay una versión nueva…</p>`
        : e.error ? html`<${Aviso}>${e.error}</${Aviso}>`
        : d.hay ? html`<${Aviso} tipo="info"><b>Hay una versión nueva: ${d.nueva}</b> (esta es la ${d.actual}).
            ${d.notas?.length > 0 && html`<ul style="margin:6px 0 0 18px;padding:0">${d.notas.map((n, i) => html`<li key=${i}>${n}</li>`)}</ul>`}</${Aviso}>
          ${d.instalada && auto?.activa && html`<p class="small muted">Se va a instalar sola la próxima vez que cierre o abra el programa. Si la quiere ya:</p>`}
          ${d.instalada ? html`<div><button class="btn primario" onClick=${actualizar} disabled=${aplicando}>${aplicando ? 'Actualizando… no cierre la ventana' : 'Actualizar ahora'}</button></div>`
            : html`<p class="small muted">Esta es una copia de pruebas: se actualiza con el instalador.</p>`}`
        : html`<p><span class="chip ok">Al día</span> Tiene la última versión (${d.actual}).</p>`}
    </div>
  </div>`;
}

export function Ajustes() {
  const emp = useDatos('/api/empresa');
  const info = useDatos('/api/info');
  return html`<div class="pila">
    <div class="encabezado"><div><h1>Ajustes y copias</h1><p class="sub">Copias de seguridad, cambio de computador, datos de la empresa y valores de cada año.</p></div><a class="btn" href="#/bitacora"><${Icono} n="lista" />Registro de cambios</a></div>
    <${Respaldo} />
    <${Actualizaciones} />
    <div class="panel"><div class="panel-cab"><div><h2>Datos de la empresa</h2><p class="small muted">Salen en los comprobantes.</p></div></div>
      <div class="panel-cuerpo">${emp.datos ? html`<${FormEmpresa} inicial=${emp.datos} onGuardado=${emp.recargar} />` : html`<${Cargando} />`}</div></div>
    <${Parametros} />
    <${Usuarios} />
    <div class="panel"><div class="panel-cab"><h2>Cómo calcula el programa</h2></div><div class="panel-cuerpo small pila">
      <p><b>Días</b>: todos los meses cuentan 30 días, también febrero, y el año 360 (Ministerio del Trabajo, conceptos 104544 de 2008 y 53034 de 2014; Corte Suprema). El 31 no suma; quien entra el 16 de febrero tiene 15 días ese mes; un semestre completo son 180 y un año 360. Por eso el corte de diciembre es el 30. Las licencias no remuneradas y suspensiones se cuentan igual: todo febrero son 30 días.</p>
      <p><b>Cesantías</b>: un mes de salario por año trabajado (salario + auxilio de transporte si gana hasta 2 mínimos), con días de 360 al año. Si el salario cambió en los últimos 3 meses, se promedia el último año (Art. 249 y 253 CST).</p>
      <p><b>Intereses sobre cesantías</b>: 12 % anual sobre las cesantías, proporcional a los días (Ley 52 de 1975).</p>
      <p><b>Prima de servicios</b>: 30 días de salario por año, por semestres (Art. 306 CST).</p>
      <p><b>Vacaciones</b>: 15 días hábiles por año. Se pagan con el salario básico, sin auxilio de transporte ni horas extra (Art. 186, 189 y 192 CST). Cuando sale a descansar, el programa cuenta los días hábiles sin domingos ni festivos de Colombia (y sin sábados si no los trabaja) y dice qué día vuelve. En dinero, con el contrato vigente, solo hasta la mitad de lo ganado y con acuerdo escrito.</p>
      <p><b>Periodos sueltos</b>: se puede liquidar cualquier rango de fechas que no esté pagado (por ejemplo, solo de febrero a septiembre). Si queda tiempo sin liquidar atrás, el programa lo muestra en la ficha y en Inicio, y la liquidación definitiva lo incluye.</p>
      <p><b>Indemnización sin justa causa</b>: menos de 10 mínimos, 30 días el primer año y 20 por cada año siguiente; 10 mínimos o más, 20 y 15 (Art. 64 CST). La reforma laboral de 2025 (Ley 2466) no la cambió.</p>
      <p><b>Días no pagados</b>: las licencias no remuneradas y suspensiones se descuentan (Art. 51 y 53 CST).</p>
      <p class="muted">Versión ${info.datos?.version || ''}. Las liquidaciones guardadas no se pueden editar ni borrar; solo anular con un motivo. Cada una lleva un código de control que detecta si alguien la cambió por fuera del programa.</p>
    </div></div>
  </div>`;
}

export function Bitacora() {
  const { datos } = useDatos('/api/bitacora?limite=1000');
  return html`<div class="pila">
    <div class="migas"><a href="#/ajustes">Ajustes</a> › Registro de cambios</div>
    <div class="encabezado"><div><h1>Registro de cambios</h1><p class="sub">Todo lo que se ha hecho en el programa, quién y cuándo. No se puede borrar.</p></div></div>
    <div class="panel">${!datos ? html`<${Cargando} />` : datos.length === 0 ? html`<div class="vacio">Sin registros todavía.</div>` : html`<div class="tabla-scroll" style="max-height:none"><table class="tabla">
      <thead><tr><th>Fecha y hora</th><th>Quién</th><th>Qué hizo</th></tr></thead>
      <tbody>${datos.map((b) => html`<tr key=${b.id}><td class="nowrap">${b.fecha}</td><td>${b.usuario || '—'}</td><td>${b.accion}${b.entidad === 'liquidacion' && b.entidad_id ? html` · <a href=${'#/liquidacion/' + b.entidad_id}>ver</a>` : b.entidad === 'trabajador' && b.entidad_id ? html` · <a href=${'#/trabajador/' + b.entidad_id}>ver trabajador</a>` : ''}</td></tr>`)}</tbody></table></div>`}</div>
  </div>`;
}
