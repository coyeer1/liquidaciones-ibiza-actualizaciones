// Utilidades de fechas. Todo se maneja como texto 'AAAA-MM-DD' para no pelear con zonas horarias.
'use strict';

function partes(f) {
  const [y, m, d] = String(f).slice(0, 10).split('-').map(Number);
  return [y, m, d];
}
function texto(y, m, d) {
  return `${String(y).padStart(4, '0')}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}
function esBisiesto(y) {
  return (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
}
function diasDelMes(y, m) {
  return [31, esBisiesto(y) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1];
}
function valida(f) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(f || ''))) return false;
  const [y, m, d] = partes(f);
  return y > 1900 && y < 2200 && m >= 1 && m <= 12 && d >= 1 && d <= diasDelMes(y, m);
}
function sumarDias(f, n) {
  const [y, m, d] = partes(f);
  const t = new Date(Date.UTC(y, m - 1, d) + n * 86400000);
  return texto(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate());
}
function sumarMeses(f, n) {
  let [y, m, d] = partes(f);
  m += n;
  while (m > 12) { m -= 12; y++; }
  while (m < 1) { m += 12; y--; }
  return texto(y, m, Math.min(d, diasDelMes(y, m)));
}
function anio(f) { return partes(f)[0]; }
function finDeMes(f) { const [y, m, d] = partes(f); return d === diasDelMes(y, m); }

// Días "comerciales" de 360 al año (cada mes cuenta 30), INCLUYENDO ambos extremos.
// Es la forma en que se liquidan prestaciones en Colombia: 1-ene a 31-dic = 360 días,
// un semestre = 180, y febrero completo cuenta 30.
function dias360(desde, hasta) {
  if (!desde || !hasta || hasta < desde) return 0;
  let [y1, m1, d1] = partes(desde);
  let [y2, m2, d2] = partes(hasta);
  if (d1 === 31) d1 = 30; // quien entra el 28 de febrero trabaja 28, 29 y 30 "comerciales"
  if (d2 === 31 || (m2 === 2 && d2 === diasDelMes(y2, 2))) d2 = 30;
  return (y2 - y1) * 360 + (m2 - m1) * 30 + (d2 - d1) + 1;
}

// En el mes comercial de 30 días, pagar "hasta el 30" de un mes de 31 ya es pagar el mes completo:
// el 31 no es un día más. Así, "cesantías liquidadas hasta el 30 de diciembre" = hasta el 31.
// Se usa para saber desde dónde sigue lo pendiente (si no, el 31 quedaba como un día sin pagar).
function finComercial(f) {
  if (!f || !valida(f)) return f;
  const [y, m, d] = partes(f);
  return d === 30 && diasDelMes(y, m) === 31 ? texto(y, m, 31) : f;
}

// Días de una licencia o suspensión, en meses de 30 (se cuenta mes por mes):
//  - un mes completo vale 30, también febrero (licencia de todo febrero = 30, no 28);
//  - un pedazo de mes vale los días que de verdad pasaron, sin el 31, que en el mes laboral no existe
//    (27 y 28 de febrero = 2; del 25 al 31 de enero = 6; solo el 31 = 0).
// Es lo que dicen el concepto 53034/2014 del Ministerio del Trabajo y la práctica de nómina: de los 30 días
// del mes se rebajan los que no trabajó ("quien falta dos días en febrero cobra 28, no 26").
function diasAusencia(desde, hasta) {
  if (!desde || !hasta || hasta < desde || !valida(desde) || !valida(hasta)) return 0;
  let total = 0;
  let a = desde;
  for (let guard = 0; a <= hasta && guard < 2400; guard++) {
    const [y, m, d] = partes(a);
    const ultimo = diasDelMes(y, m);
    const finMes = texto(y, m, ultimo);
    const b = hasta < finMes ? hasta : finMes;
    const db = partes(b)[2];
    if (d === 1 && b === finMes) total += 30;
    else total += Math.max(0, Math.min(db, 30) - d + 1);
    a = sumarDias(finMes, 1);
  }
  return total;
}

// Fecha desde la que se cuentan n días de 30 al mes hasta `hasta` (ej. 15 días hasta el 28 de febrero
// arrancan el 16, no el 14; 15 días hasta el 31 de enero arrancan el 16, no el 17).
function inicio360(hasta, n) {
  if (!hasta || !(n > 0)) return hasta;
  let f = hasta;
  for (let guard = 0; guard < 4000; guard++) {
    const antes = sumarDias(f, -1);
    if (dias360(antes, hasta) > n) break;
    f = antes;
  }
  return f;
}

// Para MOSTRAR hasta dónde está pagado algo: el fin de año se escribe "30 de diciembre", como en las planillas
// de Ibiza (cada mes cuenta 30 días, así que el 30 y el 31 de diciembre son lo mismo). Las demás fechas se muestran tal cual.
function finLaboral(f) {
  if (!f || !valida(f)) return f;
  return f.slice(5) === '12-31' ? f.slice(0, 5) + '12-30' : f;
}

// Días 360 en que se cruzan dos rangos.
function cruce360(a1, a2, b1, b2) {
  const desde = a1 > b1 ? a1 : b1;
  const hasta = a2 < b2 ? a2 : b2;
  return hasta >= desde ? dias360(desde, hasta) : 0;
}

const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
function larga(f) {
  if (!f) return '';
  const [y, m, d] = partes(f);
  return `${d} de ${MESES[m - 1]} de ${y}`;
}
function hoy() {
  const t = new Date();
  return texto(t.getFullYear(), t.getMonth() + 1, t.getDate());
}

// 0 = domingo … 6 = sábado
function diaSemana(f) {
  const [y, m, d] = partes(f);
  return new Date(Date.UTC(y, m - 1, d)).getUTCDay();
}
const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
function conDia(f) { return f ? `${DIAS[diaSemana(f)]} ${larga(f)}` : ''; }

// Domingo de Pascua (algoritmo gregoriano anónimo).
function pascua(y) {
  const a = y % 19, b = Math.floor(y / 100), c = y % 100, d = Math.floor(b / 4), e = b % 4;
  const f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451);
  const mes = Math.floor((h + l - 7 * m + 114) / 31);
  const dia = ((h + l - 7 * m + 114) % 31) + 1;
  return texto(y, mes, dia);
}
function lunesSiguiente(f) {
  const ds = diaSemana(f);
  return ds === 1 ? f : sumarDias(f, (8 - ds) % 7);
}
// Festivos de Colombia (Ley 51 de 1983 y Ley 37 de 1905 para los fijos).
const cacheFestivos = {};
function festivos(y) {
  if (cacheFestivos[y]) return cacheFestivos[y];
  const fijos = ['01-01', '05-01', '07-20', '08-07', '12-08', '12-25'].map((md) => `${y}-${md}`);
  const aLunes = ['01-06', '03-19', '06-29', '08-15', '10-12', '11-01', '11-11'].map((md) => lunesSiguiente(`${y}-${md}`));
  const p = pascua(y);
  const santos = [sumarDias(p, -3), sumarDias(p, -2)]; // jueves y viernes santo
  const moviles = [sumarDias(p, 43), sumarDias(p, 64), sumarDias(p, 71)]; // Ascensión, Corpus Christi, Sagrado Corazón (ya en lunes)
  return (cacheFestivos[y] = new Set([...fijos, ...aLunes, ...santos, ...moviles]));
}
function esFestivo(f) { return festivos(anio(f)).has(f); }
function esHabil(f, trabajaSabados = true) {
  const ds = diaSemana(f);
  if (ds === 0 || (ds === 6 && !trabajaSabados) || esFestivo(f)) return false;
  return true;
}
// Último día hábil (lunes a viernes, sin festivos) en o antes de f: para los plazos que caen domingo o festivo.
function habilAnterior(f) {
  let x = f;
  for (let i = 0; i < 10 && !esHabil(x, false); i++) x = sumarDias(x, -1);
  return x;
}
// Vacaciones de n días hábiles que empiezan en `desde`: último día de descanso y día de regreso.
function finVacaciones(desde, n, trabajaSabados = true) {
  let f = desde;
  let contados = 0;
  for (let guard = 0; guard < 2000; guard++) {
    if (esHabil(f, trabajaSabados)) contados++;
    if (contados >= n) break;
    f = sumarDias(f, 1);
  }
  let regreso = sumarDias(f, 1);
  while (!esHabil(regreso, trabajaSabados)) regreso = sumarDias(regreso, 1);
  return { hasta: sumarDias(regreso, -1), regreso, calendario: Math.round((Date.parse(regreso) - Date.parse(desde)) / 86400000) };
}

module.exports = { partes, texto, esBisiesto, diasDelMes, valida, sumarDias, sumarMeses, anio, finDeMes, finComercial, finLaboral, dias360, diasAusencia, inicio360, cruce360, larga, hoy, MESES, diaSemana, conDia, pascua, festivos, esFestivo, esHabil, habilAnterior, finVacaciones };
