// Número a letras en español (para "SON: ... PESOS M/CTE" en los comprobantes).
'use strict';

const U = ['', 'uno', 'dos', 'tres', 'cuatro', 'cinco', 'seis', 'siete', 'ocho', 'nueve', 'diez', 'once', 'doce', 'trece', 'catorce', 'quince', 'dieciséis', 'diecisiete', 'dieciocho', 'diecinueve', 'veinte', 'veintiuno', 'veintidós', 'veintitrés', 'veinticuatro', 'veinticinco', 'veintiséis', 'veintisiete', 'veintiocho', 'veintinueve'];
const D = ['', '', '', 'treinta', 'cuarenta', 'cincuenta', 'sesenta', 'setenta', 'ochenta', 'noventa'];
const C = ['', 'ciento', 'doscientos', 'trescientos', 'cuatrocientos', 'quinientos', 'seiscientos', 'setecientos', 'ochocientos', 'novecientos'];

function hasta999(n) {
  if (n === 0) return '';
  if (n === 100) return 'cien';
  const c = Math.floor(n / 100);
  const r = n % 100;
  let s = C[c];
  if (r) {
    const t = r < 30 ? U[r] : D[Math.floor(r / 10)] + (r % 10 ? ' y ' + U[r % 10] : '');
    s = (s ? s + ' ' : '') + t;
  }
  return s;
}

function enLetras(n) {
  n = Math.round(Math.abs(Number(n) || 0));
  if (n === 0) return 'cero';
  const millones = Math.floor(n / 1e6);
  const miles = Math.floor((n % 1e6) / 1000);
  const resto = n % 1000;
  const partes = [];
  if (millones) {
    if (millones === 1) partes.push('un millón');
    else partes.push(apocope(enLetras(millones)) + ' millones');
  }
  if (miles) partes.push(miles === 1 ? 'mil' : apocope(hasta999(miles)) + ' mil');
  if (resto) partes.push(hasta999(resto));
  return partes.join(' ');
}
// "uno" → "un" y "veintiuno" → "veintiún" delante de "mil"/"millones".
function apocope(s) {
  return s.replace(/veintiuno$/, 'veintiún').replace(/uno$/, 'un');
}

function pesosEnLetras(n) {
  const v = Math.round(Math.abs(Number(n) || 0));
  if (v === 1) return 'UN PESO M/CTE';
  const txt = apocope(enLetras(v));
  const de = v >= 1e6 && v % 1e6 === 0 ? ' de' : '';
  return (txt + de + ' pesos m/cte').toUpperCase();
}

module.exports = { enLetras, pesosEnLetras };
