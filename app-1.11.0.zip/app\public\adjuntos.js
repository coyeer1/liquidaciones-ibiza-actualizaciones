// Documentos de soporte (PDF, fotos, Word…): el memorando de las faltas, la sanción, el comprobante firmado…
// Se guardan DENTRO de los datos del programa: la copia de respaldo y la mudanza los llevan.
import { html, useRef, useState } from './vendor/preact-htm.js';
import { api, usuarioActual } from './util.js';
import { Icono, avisar, confirmar } from './comp.js';

const ACEPTA = '.pdf,.jpg,.jpeg,.png,.webp,.gif,.doc,.docx,.xls,.xlsx,.txt';
const MAX = 10 * 1024 * 1024;

export function tamanoTxt(n) {
  if (n == null) return '';
  if (n < 1024) return n + ' bytes';
  if (n < 1024 * 1024) return Math.round(n / 1024) + ' KB';
  return (n / 1024 / 1024).toFixed(1).replace('.', ',') + ' MB';
}

// Las fotos del celular pesan mucho: se achican a lo que se necesita para leerlas (máx. 2000 px, JPG).
async function achicar(file) {
  if (!/^image\/(jpeg|png|webp)$/.test(file.type) || file.size < 700 * 1024) return { cuerpo: file, nombre: file.name };
  try {
    const img = await createImageBitmap(file);
    const escala = Math.min(1, 2000 / Math.max(img.width, img.height));
    const c = document.createElement('canvas');
    c.width = Math.round(img.width * escala);
    c.height = Math.round(img.height * escala);
    const g = c.getContext('2d');
    g.fillStyle = '#fff';
    g.fillRect(0, 0, c.width, c.height);
    g.drawImage(img, 0, 0, c.width, c.height);
    const blob = await new Promise((ok) => c.toBlob(ok, 'image/jpeg', 0.85));
    if (!blob || blob.size >= file.size) return { cuerpo: file, nombre: file.name };
    return { cuerpo: blob, nombre: file.name.replace(/\.[^.]+$/, '') + '.jpg' };
  } catch {
    return { cuerpo: file, nombre: file.name };
  }
}

// entidad/id: a qué va (si no se dan, queda "suelto" hasta que se guarde el formulario)
export async function subirArchivo(file, { entidad, id } = {}) {
  const { cuerpo, nombre } = await achicar(file);
  if (cuerpo.size > MAX) throw new Error(`"${file.name}" pesa más de 10 MB. Si es un escaneo, guárdelo con menos calidad.`);
  const q = new URLSearchParams({ nombre });
  if (entidad) { q.set('entidad', entidad); q.set('id', id); }
  return api('/api/adjuntos?' + q, { metodo: 'POST', crudo: cuerpo });
}

// Se abre en otra ventana (PDF y fotos); lo demás se descarga.
export async function abrirAdjunto(a) {
  try {
    const r = await fetch('/api/adjuntos/' + a.id, { headers: { 'X-Liq': '1', 'X-Usuario': encodeURIComponent(usuarioActual()) } });
    if (!r.ok) throw new Error('No se pudo abrir el documento.');
    const url = URL.createObjectURL(await r.blob());
    const verAqui = /^(application\/pdf|image\/)/.test(a.tipo || r.headers.get('Content-Type') || '');
    if (!verAqui || !window.open(url, '_blank')) {
      const link = document.createElement('a');
      link.href = url;
      link.download = a.nombre;
      document.body.appendChild(link);
      link.click();
      link.remove();
    }
    setTimeout(() => URL.revokeObjectURL(url), 5 * 60 * 1000);
  } catch (e) { avisar(e.message, 'error'); }
}

function BotonAdjuntar({ id, texto = 'Adjuntar documento', onArchivos, ocupado }) {
  const ref = useRef();
  return html`<span>
    <input ref=${ref} id=${id} type="file" accept=${ACEPTA} multiple style="display:none"
      onChange=${(ev) => { const fs = [...ev.target.files]; ev.target.value = ''; if (fs.length) onArchivos(fs); }} />
    <button type="button" class="btn chico" disabled=${ocupado} onClick=${() => ref.current.click()}><${Icono} n="clip" />${ocupado ? 'Subiendo…' : texto}</button>
  </span>`;
}

function Fila({ a, onQuitar }) {
  return html`<li class="adjunto">
    <${Icono} n="documento" />
    <button type="button" class="btn link" onClick=${() => abrirAdjunto(a)} title="Abrir">${a.nombre}</button>
    <span class="small muted">${tamanoTxt(a.tamano)}${a.creado_por ? ' · ' + a.creado_por : ''}${a.sellado ? ' · va con el comprobante' : ''}</span>
    ${onQuitar && !a.sellado && html`<button type="button" class="btn chico" aria-label=${'Quitar ' + a.nombre} title="Quitar" onClick=${() => onQuitar(a)}><${Icono} n="x" /></button>`}
  </li>`;
}

// Para un formulario que todavía no se ha guardado (p. ej. una liquidación): los documentos se suben al escogerlos
// y se enlazan al guardar.
export function ElegirSoportes({ lista, onCambio, id = 'soportes', ayuda }) {
  const [ocupado, setOcupado] = useState(false);
  const agregar = async (files) => {
    setOcupado(true);
    const nuevos = [];
    for (const f of files) {
      try { nuevos.push(await subirArchivo(f)); } catch (e) { avisar(e.message, 'error'); }
    }
    setOcupado(false);
    if (nuevos.length) onCambio([...lista, ...nuevos]);
  };
  const quitar = async (a) => {
    onCambio(lista.filter((x) => x.id !== a.id));
    api('/api/adjuntos/' + a.id, { metodo: 'DELETE' }).catch(() => {});
  };
  return html`<div class="soportes pila" style="--g:6px">
    <div class="fila entre"><span class="etiqueta" style="font-weight:600;font-size:13.5px">Documentos de soporte <span class="muted small" style="font-weight:400">(opcional)</span></span>
      <${BotonAdjuntar} id=${id} onArchivos=${agregar} ocupado=${ocupado} /></div>
    ${lista.length > 0 && html`<ul class="adjuntos">${lista.map((a) => html`<${Fila} key=${a.id} a=${a} onQuitar=${quitar} />`)}</ul>`}
    <p class="small muted">${ayuda || 'PDF o foto del documento que respalda esto (memorando, permiso, sanción, acuerdo firmado…). Queda guardado con la liquidación.'}</p>
  </div>`;
}

// Para algo que ya está guardado (una liquidación, un pago de antes del programa): ver, agregar y quitar.
export function Adjuntos({ entidad, id, lista, onCambio, titulo = 'Documentos de soporte', vacio = 'No tiene documentos adjuntos.', idBoton = 'adjuntar' }) {
  const [ocupado, setOcupado] = useState(false);
  const agregar = async (files) => {
    setOcupado(true);
    let alguno = false;
    for (const f of files) {
      try { await subirArchivo(f, { entidad, id }); alguno = true; } catch (e) { avisar(e.message, 'error'); }
    }
    setOcupado(false);
    if (alguno) { avisar('Documento adjuntado', 'ok'); onCambio(); }
  };
  const quitar = async (a) => {
    if (!(await confirmar({ titulo: 'Quitar este documento', texto: `"${a.nombre}" se borra del programa (queda anotado en el registro de cambios).`, boton: 'Quitar', peligro: true }))) return;
    try { await api('/api/adjuntos/' + a.id, { metodo: 'DELETE' }); avisar('Documento quitado'); onCambio(); } catch (e) { avisar(e.message, 'error'); }
  };
  return html`<div class="pila" style="--g:8px">
    <div class="fila entre"><b>${titulo}</b><${BotonAdjuntar} id=${idBoton} onArchivos=${agregar} ocupado=${ocupado} /></div>
    ${lista?.length ? html`<ul class="adjuntos">${lista.map((a) => html`<${Fila} key=${a.id} a=${a} onQuitar=${quitar} />`)}</ul>` : html`<p class="small muted">${vacio}</p>`}
  </div>`;
}
