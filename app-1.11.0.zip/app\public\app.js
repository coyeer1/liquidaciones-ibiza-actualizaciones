import { html, render, useState, useEffect } from './vendor/preact-htm.js';
import { api, rutaActual, usuarioActual, fijarUsuario } from './util.js';
import { Icono, Toasts, Confirmaciones, Modal, avisar } from './comp.js';
import { Inicio } from './inicio.js';
import { ListaTrabajadores, FichaTrabajador } from './trabajadores.js';
import { Liquidar, LiquidarTodos } from './liquidar.js';
import { Comprobante, ComprobantesLote, Certificado } from './comprobante.js';
import { Historial } from './historial.js';
import { Importar } from './importar.js';
import { Ajustes, Bitacora } from './ajustes.js';

const MENU = [
  ['/inicio', 'inicio', 'Inicio'],
  ['/trabajadores', 'personas', 'Trabajadores'],
  ['/liquidar', 'calculadora', 'Liquidar a uno'],
  ['/todos', 'grupo', 'Liquidar a todos'],
  ['/historial', 'historial', 'Historial'],
  null,
  ['/importar', 'importar', 'Importar de Excel'],
  ['/ajustes', 'ajustes', 'Ajustes y copias'],
];

function QuienUsa({ onListo, puedeCerrar, onCerrar }) {
  const [lista, setLista] = useState(null);
  const [nuevo, setNuevo] = useState('');
  useEffect(() => { api('/api/usuarios').then(setLista).catch(() => setLista([])); }, []);
  const entrar = (n) => { fijarUsuario(n); onListo(n); };
  const crear = async (e) => {
    e.preventDefault();
    const n = nuevo.trim();
    if (!n) return;
    try { await api('/api/usuarios', { metodo: 'POST', cuerpo: { nombre: n } }); entrar(n); } catch (err) { avisar(err.message, 'error'); }
  };
  return html`<${Modal} titulo="¿Quién está usando el programa?" sub="Queda anotado en cada liquidación y en el registro de cambios." onCerrar=${puedeCerrar ? onCerrar : null}>
    <div class="pila">
      ${lista && lista.length > 0 && html`<div class="opciones">${lista.map((u) => html`<button class="opcion" key=${u.id} onClick=${() => entrar(u.nombre)}><b>${u.nombre}</b><span>Entrar</span></button>`)}</div>`}
      <form onSubmit=${crear} class="campo">
        <label for="nuevo-usuario">${lista && lista.length ? 'O escriba otro nombre' : 'Escriba su nombre'}</label>
        <div class="fila" style="flex-wrap:nowrap">
          <input id="nuevo-usuario" value=${nuevo} onInput=${(e) => setNuevo(e.target.value)} placeholder="Ej.: Tatiana Gómez" />
          <button class="btn primario" disabled=${!nuevo.trim()}>Entrar</button>
        </div>
      </form>
    </div>
  </${Modal}>`;
}

// Cuando el programa se actualiza solo al abrirlo: tapa la pantalla unos segundos y vuelve sola con la versión nueva.
function AutoActualizacion() {
  const [a, setA] = useState(null);
  const [tarda, setTarda] = useState(false);
  useEffect(() => {
    let vivo = true;
    const inicio = Date.now();
    const pausa = (ms) => new Promise((ok) => setTimeout(ok, ms));
    const esperar = async (nueva) => {
      const hasta = Date.now() + 180000;
      while (vivo && Date.now() < hasta) {
        await pausa(1000);
        try { const p = await (await fetch('/api/ping', { cache: 'no-store' })).json(); if (p.version === nueva) { location.reload(); return; } } catch {}
        try { const d = await api('/api/auto-actualizacion'); if (d.estado === 'error') { setA(d); avisar('No se pudo actualizar solo: sigue con la versión que tenía. ' + (d.error || ''), 'error'); return; } } catch {}
      }
      if (vivo) setTarda(true);
    };
    (async () => {
      while (vivo && Date.now() - inicio < 120000) {
        try {
          const d = await api('/api/auto-actualizacion');
          setA(d);
          if (d.estado === 'aplicando' || d.estado === 'lista') { esperar(d.nueva); return; }
          if (!['nada', 'buscando'].includes(d.estado)) return;
        } catch {}
        await pausa(1000);
      }
    })();
    return () => { vivo = false; };
  }, []);
  if (!a || !(a.estado === 'aplicando' || a.estado === 'lista')) return null;
  return html`<div class="tapa-actualizando" role="alertdialog" aria-live="assertive" aria-label="Actualizando el programa">
    <div class="caja pila">
      <div class="girando" aria-hidden="true"></div>
      <h2>Actualizando el programa${a.nueva ? ' a la versión ' + a.nueva : ''}</h2>
      <p>Tarda unos segundos y vuelve solo. No cierre la ventana.</p>
      <p class="small muted">Los trabajadores y las liquidaciones no se tocan: antes se guarda una copia de todo.</p>
      ${tarda && html`<p class="small" style="color:var(--bad)">Está tardando más de la cuenta. Cierre el programa y vuelva a abrirlo con el ícono.</p>`}
    </div>
  </div>`;
}

function App() {
  const [ruta, setRuta] = useState(rutaActual());
  const [usuario, setUsuario] = useState(usuarioActual());
  const [cambiarUsuario, setCambiarUsuario] = useState(false);

  useEffect(() => {
    const f = () => { setRuta(rutaActual()); window.scrollTo(0, 0); };
    addEventListener('hashchange', f);
    return () => removeEventListener('hashchange', f);
  }, []);

  // Le avisa al programa que la ventana sigue abierta (si se cierra, se apaga solo).
  useEffect(() => {
    const s = () => api('/api/senal', { metodo: 'POST' }).catch(() => {});
    s();
    const t = setInterval(s, 20000);
    const adios = () => navigator.sendBeacon?.('/api/adios');
    addEventListener('pagehide', adios);
    return () => { clearInterval(t); removeEventListener('pagehide', adios); };
  }, []);

  const [p0, p1] = ruta.partes;
  let pagina;
  switch (p0) {
    case 'trabajadores': pagina = html`<${ListaTrabajadores} query=${ruta.query} />`; break;
    case 'trabajador': pagina = html`<${FichaTrabajador} id=${Number(p1)} key=${p1} />`; break;
    case 'liquidar': pagina = html`<${Liquidar} query=${ruta.query} key=${JSON.stringify(ruta.query)} />`; break;
    case 'todos': pagina = html`<${LiquidarTodos} query=${ruta.query} />`; break;
    case 'liquidacion': pagina = html`<${Comprobante} id=${Number(p1)} key=${p1} />`; break;
    case 'certificado': pagina = html`<${Certificado} id=${Number(p1)} key=${p1} />`; break;
    case 'lote': pagina = html`<${ComprobantesLote} lote=${decodeURIComponent(p1 || '')} />`; break;
    case 'historial': pagina = html`<${Historial} query=${ruta.query} />`; break;
    case 'importar': pagina = html`<${Importar} />`; break;
    case 'ajustes': pagina = html`<${Ajustes} />`; break;
    case 'bitacora': pagina = html`<${Bitacora} />`; break;
    default: pagina = html`<${Inicio} usuario=${usuario} />`;
  }
  const activo = '/' + (p0 === 'trabajador' ? 'trabajadores' : p0 === 'liquidacion' || p0 === 'lote' ? 'historial' : p0 === 'bitacora' ? 'ajustes' : p0 || 'inicio');

  return html`<div class="marco">
    <nav class="lateral" aria-label="Menú principal">
      <div class="marca"><img src="marca/ibiza-sin-lema.png" alt="Ibiza Motos" /><div><b>Liquidaciones</b><small>Prestaciones sociales</small></div></div>
      ${MENU.map((m) => (m ? html`<a class=${'nav-item' + (activo === m[0] ? ' activo' : '')} href=${'#' + m[0]} aria-current=${activo === m[0] ? 'page' : null}><${Icono} n=${m[1]} />${m[2]}</a>` : html`<div class="nav-sep" />`))}
      <div class="pie">
        ${usuario ? html`Usando: <b style="color:#fff">${usuario}</b><br /><button onClick=${() => setCambiarUsuario(true)}>Cambiar de persona</button>` : null}
      </div>
    </nav>
    <main class="contenido">${pagina}</main>
    ${(!usuario || cambiarUsuario) && html`<${QuienUsa} puedeCerrar=${!!usuario} onCerrar=${() => setCambiarUsuario(false)} onListo=${(n) => { setUsuario(n); setCambiarUsuario(false); }} />`}
    <${Confirmaciones} />
    <${Toasts} />
    <${AutoActualizacion} />
  </div>`;
}

render(html`<${App} />`, document.getElementById('app'));
