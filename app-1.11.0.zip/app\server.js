// Servidor local del programa de liquidaciones. Solo escucha en 127.0.0.1 (este computador).
'use strict';
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const D = require('./db');
const C = require('./calc');
const F = require('./fechas');
const { pesosEnLetras } = require('./letras');

const VERSION = '1.11.0';
const PUBLICO = path.join(__dirname, 'public');
const argPuerto = process.argv.indexOf('--puerto');
const PUERTO = Number(process.env.LIQ_PUERTO || (argPuerto > 0 ? process.argv[argPuerto + 1] : 0) || 47321);
const AUTOAPAGADO_MS = 10 * 60 * 1000;

// Abierto desde Liquidaciones.exe no hay consola: lo que se escribe va a datos\programa.log
if (process.env.LIQ_REGISTRO) {
  fs.mkdirSync(D.DATOS, { recursive: true });
  const log = path.join(D.DATOS, 'programa.log');
  try { if (fs.statSync(log).size > 1024 * 1024) fs.renameSync(log, log + '.anterior'); } catch {}
  const escribir = (...a) => { try { fs.appendFileSync(log, `[${new Date().toISOString()}] ${a.map((x) => (x instanceof Error ? x.stack : String(x))).join(' ')}\n`); } catch {} };
  console.log = escribir;
  console.error = escribir;
  process.on('uncaughtException', (e) => { escribir('ERROR', e); process.exit(1); });
}

D.abrir();
try { D.respaldoDiario(); } catch (e) { console.error('No se pudo hacer el respaldo diario:', e.message); }
try { D.run('DELETE FROM adjuntos WHERE entidad IS NULL AND creado_en < ?', D.ahora().slice(0, 10)); } catch (e) { console.error('No se pudieron limpiar los adjuntos sueltos:', e.message); }

// ---------------------------------------------------------------- utilidades

class ErrorUsuario extends Error {}
const falla = (msg) => { throw new ErrorUsuario(msg); };
const ACT = require('./actualizar').crear({ D, VERSION, falla });
const { AUTOMATICA } = require('./actualizar');

function texto(v, max = 200) {
  if (v == null) return null;
  const s = String(v).trim();
  return s ? s.slice(0, max) : null;
}
function fechaOpcional(v, nombre) {
  const s = texto(v, 10);
  if (!s) return null;
  if (!F.valida(s)) falla(`La fecha "${nombre}" no es válida.`);
  return s;
}
function entero(v) {
  if (v == null || v === '') return null;
  const n = Math.round(Number(v));
  return Number.isFinite(n) ? n : null;
}
function nombreCompleto(t) {
  return `${t.nombres || ''} ${t.apellidos || ''}`.trim();
}

function parametros() {
  const out = {};
  for (const p of D.all('SELECT * FROM parametros')) out[p.anio] = { smmlv: p.smmlv, auxilio_transporte: p.auxilio_transporte };
  return out;
}

function minimoDe(fecha) {
  return D.get('SELECT smmlv FROM parametros WHERE anio <= ? ORDER BY anio DESC LIMIT 1', F.anio(fecha))?.smmlv || 0;
}

// excluir: liquidación que se está corrigiendo (se calcula como si no existiera; si era la definitiva, como si siguiera activo)
function contexto(trabId, excluir = null) {
  let trab = D.get('SELECT * FROM trabajadores WHERE id = ?', trabId);
  if (!trab) falla('No existe ese trabajador.');
  if (excluir && excluir.tipo === 'definitiva') trab = { ...trab, fecha_retiro: null, motivo_retiro: null };
  return {
    trab,
    salarios: D.all('SELECT vigente_desde, salario FROM salarios WHERE trabajador_id = ? ORDER BY vigente_desde', trabId),
    novedades: D.all('SELECT tipo, desde, hasta FROM novedades WHERE trabajador_id = ?', trabId),
    vacaciones: D.all('SELECT desde, hasta, dias_habiles FROM vacaciones WHERE trabajador_id = ?', trabId),
    // Una fila por mes: si la nómina vino por quincenas, se suman
    nomina: D.all(`SELECT periodo, SUM(salario_basico) salario_basico, SUM(extras_recargos) extras_recargos, SUM(recargo_nocturno) recargo_nocturno,
                   SUM(comisiones) comisiones, SUM(otros_salariales) otros_salariales, SUM(auxilio_transporte) auxilio_transporte, SUM(dias) dias
                   FROM nomina WHERE trabajador_id = ? GROUP BY periodo`, trabId),
    // Y cada planilla por separado, para comparar los días trabajados con las licencias anotadas
    planillas: D.all('SELECT periodo, corte, dias FROM nomina WHERE trabajador_id = ? AND dias IS NOT NULL', trabId),
    previos: D.all(`SELECT c.concepto, c.desde, c.hasta, c.dias, l.consecutivo FROM conceptos c JOIN liquidaciones l ON l.id = c.liquidacion_id
                    WHERE c.trabajador_id = ? AND l.estado = 'vigente' AND l.id <> ?`, trabId, excluir?.id ?? 0),
    params: parametros(),
  };
}

function estadoDe(trabId, corte = F.hoy()) {
  const ctx = contexto(trabId);
  if (!ctx.salarios.length || !F.valida(ctx.trab.fecha_ingreso)) return null;
  return C.estado(ctx, corte);
}

// ---------------------------------------------------------------- trabajadores

const CAMPOS_TRAB = ['tipo_documento', 'documento', 'nombres', 'apellidos', 'cargo', 'sede', 'telefono', 'correo', 'fecha_ingreso', 'tipo_salario', 'salario_minimo', 'auxilio_transporte', 'fondo_cesantias', 'cesantias_hasta_inicial', 'prima_hasta_inicial', 'vac_saldo_fecha', 'vac_saldo_dias', 'notas'];

function limpiarTrabajador(b, actual) {
  const t = {};
  t.tipo_documento = texto(b.tipo_documento, 10) || actual?.tipo_documento || 'CC';
  t.documento = (texto(b.documento, 30) || '').replace(/[\s.]/g, '');
  if (!t.documento) falla('Falta el número de documento.');
  t.nombres = texto(b.nombres, 100);
  if (!t.nombres) falla('Faltan los nombres.');
  t.apellidos = texto(b.apellidos, 100) || '';
  t.cargo = texto(b.cargo, 100);
  t.sede = texto(b.sede, 100);
  t.telefono = texto(b.telefono, 40);
  t.correo = texto(b.correo, 120);
  t.fecha_ingreso = fechaOpcional(b.fecha_ingreso, 'ingreso');
  if (!t.fecha_ingreso) falla('Falta la fecha de ingreso.');
  if (t.fecha_ingreso > F.sumarDias(F.hoy(), 366)) falla('La fecha de ingreso está muy en el futuro.');
  t.tipo_salario = ['fijo', 'variable', 'integral'].includes(b.tipo_salario) ? b.tipo_salario : actual?.tipo_salario || 'fijo';
  t.salario_minimo = [true, 1, '1', 'si', 'sí', 'true'].includes(b.salario_minimo) && t.tipo_salario !== 'integral' ? 1 : 0;
  t.auxilio_transporte = b.auxilio_transporte === 'no' ? 'no' : 'auto';
  t.fondo_cesantias = texto(b.fondo_cesantias, 80);
  t.cesantias_hasta_inicial = fechaOpcional(b.cesantias_hasta_inicial, 'cesantías liquidadas hasta');
  t.prima_hasta_inicial = fechaOpcional(b.prima_hasta_inicial, 'prima liquidada hasta');
  t.vac_saldo_fecha = fechaOpcional(b.vac_saldo_fecha, 'saldo de vacaciones al');
  t.vac_saldo_dias = b.vac_saldo_dias === '' || b.vac_saldo_dias == null ? null : Number(String(b.vac_saldo_dias).replace(',', '.'));
  if (t.vac_saldo_dias != null && !Number.isFinite(t.vac_saldo_dias)) falla('Los días de vacaciones pendientes no son un número.');
  if (t.vac_saldo_dias != null && !t.vac_saldo_fecha) falla('Si escribe días de vacaciones pendientes, ponga también a qué fecha.');
  t.notas = texto(b.notas, 2000);
  return t;
}

function crearTrabajador(usuario, b, { reingresoDe = null } = {}) {
  const salario = entero(b.salario);
  if (b.salario_minimo == null || b.salario_minimo === '') b = { ...b, salario_minimo: salario === minimoDe(F.hoy()) ? 1 : 0 };
  const t = limpiarTrabajador(b);
  if (!salario || salario <= 0) falla('Falta el salario mensual.');
  if (D.get('SELECT id FROM trabajadores WHERE documento = ? AND fecha_retiro IS NULL', t.documento)) falla(`Ya existe un trabajador activo con el documento ${t.documento}.`);
  const anterior = D.get('SELECT * FROM trabajadores WHERE documento = ? ORDER BY fecha_retiro DESC LIMIT 1', t.documento);
  if (anterior && !reingresoDe) falla(`Esa cédula es de ${nombreCompleto(anterior)}, que ya trabajó aquí y se retiró el ${F.larga(anterior.fecha_retiro)}. Si volvió, abra su ficha y use "Volver a contratar": así su contrato anterior queda aparte con su historia.`);
  return D.tx(() => {
    const now = D.ahora();
    const r = D.run(`INSERT INTO trabajadores (${CAMPOS_TRAB.join(',')}, creado, actualizado) VALUES (${CAMPOS_TRAB.map(() => '?').join(',')}, ?, ?)`,
      ...CAMPOS_TRAB.map((k) => t[k]), now, now);
    const id = Number(r.lastInsertRowid);
    if (reingresoDe) D.run('UPDATE trabajadores SET reingreso_de = ? WHERE id = ?', reingresoDe, id);
    const desde = fechaOpcional(b.salario_desde, 'salario desde') || t.fecha_ingreso;
    D.run('INSERT INTO salarios (trabajador_id, vigente_desde, salario, nota, creado) VALUES (?, ?, ?, ?, ?)', id, desde, salario, 'Salario inicial', now);
    D.bitacora(usuario, 'Creó trabajador', 'trabajador', id, { ...t, salario });
    return id;
  });
}

function editarTrabajador(usuario, id, b) {
  const actual = D.get('SELECT * FROM trabajadores WHERE id = ?', id);
  if (!actual) falla('No existe ese trabajador.');
  const t = limpiarTrabajador({ ...actual, ...b }, actual);
  const otro = actual.fecha_retiro ? null : D.get('SELECT id FROM trabajadores WHERE documento = ? AND id <> ? AND fecha_retiro IS NULL', t.documento, id);
  if (otro) falla(`Ya existe otro trabajador activo con el documento ${t.documento}.`);
  const cambios = {};
  for (const k of CAMPOS_TRAB) if ((actual[k] ?? null) !== (t[k] ?? null)) cambios[k] = { antes: actual[k], ahora: t[k] };
  if (!Object.keys(cambios).length) return;
  D.tx(() => {
    D.run(`UPDATE trabajadores SET ${CAMPOS_TRAB.map((k) => k + ' = ?').join(', ')}, actualizado = ? WHERE id = ?`, ...CAMPOS_TRAB.map((k) => t[k]), D.ahora(), id);
    D.bitacora(usuario, 'Editó trabajador', 'trabajador', id, cambios);
  });
}

function listaTrabajadores(q) {
  const filtros = [];
  const p = [];
  if (q.estado === 'activos') filtros.push('t.fecha_retiro IS NULL');
  if (q.estado === 'retirados') filtros.push('t.fecha_retiro IS NOT NULL');
  if (q.sede) { filtros.push('t.sede = ?'); p.push(q.sede); }
  if (q.q) {
    filtros.push("(t.documento LIKE ? OR (t.nombres || ' ' || t.apellidos) LIKE ? OR t.cargo LIKE ?)");
    const like = `%${q.q}%`;
    p.push(like, like, like);
  }
  const rows = D.all(`SELECT t.* FROM trabajadores t ${filtros.length ? 'WHERE ' + filtros.join(' AND ') : ''} ORDER BY t.fecha_retiro IS NOT NULL, t.nombres, t.apellidos`, ...p);
  const hoy = F.hoy();
  return rows.map((t) => {
    let est = null;
    try { est = estadoDe(t.id, hoy); } catch {}
    return {
      id: t.id, documento: t.documento, tipo_documento: t.tipo_documento, nombre: nombreCompleto(t), cargo: t.cargo, sede: t.sede,
      fecha_ingreso: t.fecha_ingreso, fecha_retiro: t.fecha_retiro, tipo_salario: t.tipo_salario,
      salario: est?.salario_actual ?? null,
      cesantias_hasta: est?.cesantias_hasta ?? null, prima_hasta: est?.prima_hasta ?? null,
      vacaciones_pendientes: est?.vacaciones.pendientes ?? null,
      vacaciones_sin_historia: est?.vacaciones_sin_historia ?? false,
    };
  });
}

function fichaTrabajador(id) {
  const t = D.get('SELECT * FROM trabajadores WHERE id = ?', id);
  if (!t) falla('No existe ese trabajador.');
  let est = null;
  let errorEstado = null;
  try { est = estadoDe(id); } catch (e) { errorEstado = e.message; }
  return {
    trabajador: { ...t, nombre: nombreCompleto(t) },
    historicas: D.all("SELECT h.*, (SELECT COUNT(*) FROM adjuntos a WHERE a.entidad = 'historica' AND a.entidad_id = h.id) adjuntos FROM historicas h WHERE documento = ? ORDER BY hasta DESC, concepto", t.documento),
    retiro_por_fuera: !!t.fecha_retiro && !D.get("SELECT id FROM liquidaciones WHERE trabajador_id = ? AND estado = 'vigente' AND tipo = 'definitiva'", id),
    otros_contratos: D.all('SELECT id, fecha_ingreso, fecha_retiro FROM trabajadores WHERE documento = ? AND id <> ? ORDER BY fecha_ingreso', t.documento, id),
    estado: est, error_estado: errorEstado,
    salarios: D.all('SELECT * FROM salarios WHERE trabajador_id = ? ORDER BY vigente_desde DESC', id),
    novedades: D.all('SELECT * FROM novedades WHERE trabajador_id = ? ORDER BY desde DESC', id),
    vacaciones: D.all('SELECT * FROM vacaciones WHERE trabajador_id = ? ORDER BY desde DESC', id),
    nomina_meses: D.get('SELECT COUNT(DISTINCT periodo) n, MIN(periodo) desde, MAX(periodo) hasta FROM nomina WHERE trabajador_id = ?', id),
    liquidaciones: D.all('SELECT id, consecutivo, tipo, (SELECT GROUP_CONCAT(DISTINCT concepto) FROM conceptos c WHERE c.liquidacion_id = liquidaciones.id) conceptos_lista, fecha, desde, hasta, devengado, deducciones, a_fondo, neto, estado, anulada_motivo FROM liquidaciones WHERE trabajador_id = ? ORDER BY consecutivo DESC', id),
    periodos: D.all(`SELECT c.concepto, c.desde, c.hasta, c.dias, c.valor, l.consecutivo, l.id liquidacion_id FROM conceptos c JOIN liquidaciones l ON l.id = c.liquidacion_id
                     WHERE c.trabajador_id = ? AND l.estado = 'vigente' AND c.concepto IN ('cesantias','prima','vacaciones','vacaciones_disfrutadas') ORDER BY c.hasta DESC`, id),
  };
}

// ---------------------------------------------------------------- liquidaciones

function pedidoDe(b) {
  return {
    trabajador_id: entero(b.trabajador_id),
    tipo: b.tipo,
    desde: texto(b.desde, 10),
    hasta: texto(b.hasta, 10),
    fecha: texto(b.fecha, 10) || F.hoy(),
    opciones: b.opciones || {},
    // Varias cosas en un solo comprobante (prima + vacaciones, etc.)
    partes: Array.isArray(b.partes) && b.partes.length > 1 ? b.partes.slice(0, 4).map((p) => ({ tipo: String(p?.tipo || ''), desde: texto(p?.desde, 10), hasta: texto(p?.hasta, 10) })) : null,
    // "Corregir": la liquidación que esta reemplaza (se anula al guardar)
    corrige: entero(b.corrige),
    motivo_correccion: texto(b.motivo_correccion, 300),
    adjuntos: Array.isArray(b.adjuntos) ? [...new Set(b.adjuntos.map(Number).filter((n) => Number.isInteger(n) && n > 0))].slice(0, 20) : [],
  };
}

function liquidacionACorregir(pedido) {
  const l = D.get('SELECT * FROM liquidaciones WHERE id = ?', pedido.corrige);
  if (!l) falla('No existe la liquidación que se va a corregir.');
  if (l.estado !== 'vigente') falla(`La liquidación N.º ${l.consecutivo} ya está anulada: no se puede corregir.`);
  if (l.trabajador_id !== pedido.trabajador_id) falla('La corrección tiene que ser del mismo trabajador.');
  return l;
}

// ¿Se puede anular (o corregir) esta liquidación?
function validarAnulable(l) {
  // Se puede anular cualquiera: lo que cubría vuelve a quedar sin liquidar y sale como pendiente.
  // La única excepción es si ya hay una definitiva: esa cierra el contrato y se anula primero.
  if (l.tipo !== 'definitiva') {
    const def = D.get("SELECT consecutivo FROM liquidaciones WHERE trabajador_id = ? AND estado = 'vigente' AND tipo = 'definitiva' AND consecutivo > ?", l.trabajador_id, l.consecutivo);
    if (def) falla(`Primero hay que anular la liquidación definitiva N.º ${def.consecutivo}: ya cerró el contrato con lo que había liquidado.`);
  }
  if (l.tipo === 'definitiva') {
    const t = D.get('SELECT documento FROM trabajadores WHERE id = ?', l.trabajador_id);
    const nuevo = D.get('SELECT id, fecha_ingreso FROM trabajadores WHERE documento = ? AND id <> ? AND fecha_retiro IS NULL', t.documento, l.trabajador_id);
    if (nuevo) falla(`No se puede: esta persona ya volvió a trabajar con otro contrato (desde el ${F.larga(nuevo.fecha_ingreso)}). Esta liquidación cerró el contrato anterior.`);
  }
}

function marcarAnulada(usuario, l, motivo) {
  D.run("UPDATE liquidaciones SET estado = 'anulada', anulada_motivo = ?, anulada_por = ?, anulada_en = ? WHERE id = ?", motivo, usuario || null, D.ahora(), l.id);
  if (l.tipo === 'definitiva') D.run('UPDATE trabajadores SET fecha_retiro = NULL, motivo_retiro = NULL, actualizado = ? WHERE id = ?', D.ahora(), l.trabajador_id);
  D.bitacora(usuario, `Anuló la liquidación N.º ${l.consecutivo}`, 'liquidacion', l.id, { motivo });
}

function calcular(b) {
  const pedido = pedidoDe(b);
  if (!pedido.trabajador_id) falla('Escoja el trabajador.');
  const original = pedido.corrige ? liquidacionACorregir(pedido) : null;
  const ctx = contexto(pedido.trabajador_id, original);
  if (pedido.tipo === 'definitiva' && ctx.trab.fecha_retiro) falla(`Este trabajador ya tiene retiro registrado el ${F.larga(ctx.trab.fecha_retiro)}.`);
  try {
    const r = pedido.partes ? C.armarVarios(ctx, pedido) : C.armar(ctx, pedido);
    const anioActual = `${F.anio(F.hoy())}-01-01`;
    if (ctx.salarios.length === 1 && !Number(ctx.trab.salario_minimo) && ctx.trab.tipo_salario !== 'integral' && r.desde && r.desde < anioActual && ctx.salarios[0].vigente_desde <= r.desde) {
      r.avisos.unshift(`Tiene un solo salario registrado (${C.pesos(ctx.salarios[0].salario)}) y se está liquidando tiempo de años anteriores. Si en ese tiempo ganaba otra cosa, registre el cambio de salario en su ficha antes de guardar.`);
    }
    const futura = r.tipo === 'varios' ? r.partes.filter((p) => p.tipo !== 'disfrute').map((p) => p.hasta).sort().pop() : pedido.tipo !== 'definitiva' && pedido.tipo !== 'disfrute' ? r.hasta : null;
    if (futura && futura > F.hoy()) r.avisos.unshift(`La fecha de corte (${F.larga(futura)}) todavía no ha llegado: el cálculo supone que sigue trabajando hasta ese día con el mismo salario.`);
    return { ...r, trabajador: { ...ctx.trab, nombre: nombreCompleto(ctx.trab) } };
  } catch (e) {
    if (e instanceof ErrorUsuario) throw e;
    falla(e.message);
  }
}

function siguienteConsecutivo() {
  return (D.get('SELECT MAX(consecutivo) m FROM liquidaciones').m || 0) + 1;
}

function guardarLiquidacion(usuario, b, lote) {
  const pedido = pedidoDe(b);
  if (!F.valida(pedido.fecha)) falla('La fecha del documento no es válida.');
  const original = pedido.corrige ? liquidacionACorregir(pedido) : null;
  if (original) {
    validarAnulable(original);
    if (!pedido.motivo_correccion || pedido.motivo_correccion.length < 5) falla('Escriba qué se corrige (queda en el registro y en la liquidación anulada).');
  }
  const r = calcular(b);
  if (r.bloqueos?.length) falla(r.bloqueos[0]);
  const ctx = contexto(pedido.trabajador_id, original);
  const adjuntos = pedido.adjuntos.length
    ? D.all(`SELECT id, nombre, tamano, sha256 FROM adjuntos WHERE entidad IS NULL AND id IN (${pedido.adjuntos.map(() => '?').join(',')})`, ...pedido.adjuntos)
    : [];
  if (adjuntos.length !== pedido.adjuntos.length) falla('Uno de los documentos adjuntos ya no está. Quítelo y vuelva a adjuntarlo.');
  const empresa = D.get('SELECT * FROM empresa WHERE id = 1') || {};
  const consecutivo = siguienteConsecutivo();
  const creado = D.ahora();
  const datos = {
    version: 1, consecutivo, fecha: pedido.fecha, creado_en: creado, creado_por: usuario || null,
    empresa,
    trabajador: { ...ctx.trab, nombre: nombreCompleto(ctx.trab), salario_actual: C.salarioEn(ctx, r.hasta) },
    tipo: r.tipo, partes: r.partes || null, desde: r.desde, hasta: r.hasta, conceptos: r.conceptos.map(({ base_detalle, ...c }) => (base_detalle ? { ...c, base_detalle: { ...base_detalle, bloqueos: undefined } } : c)), totales: r.totales, avisos: r.avisos, opciones: r.opciones,
    neto_letras: pesosEnLetras(r.totales.neto),
    corrige: original ? { id: original.id, consecutivo: original.consecutivo, motivo: pedido.motivo_correccion } : undefined,
    adjuntos: adjuntos.length ? adjuntos.map((a) => ({ id: a.id, nombre: a.nombre, tamano: a.tamano, sha256: a.sha256 })) : undefined,
  };
  if (original) marcarAnulada(usuario, original, `Corregida con la N.º ${consecutivo}: ${pedido.motivo_correccion}`);
  const json = JSON.stringify(datos);
  const huella = crypto.createHash('sha256').update(json).digest('hex');
  const res = D.run(`INSERT INTO liquidaciones (consecutivo, trabajador_id, tipo, fecha, desde, hasta, devengado, deducciones, a_fondo, neto, datos, huella, lote, creado_por, creado_en, corrige_a)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  consecutivo, pedido.trabajador_id, r.tipo, pedido.fecha, r.desde, r.hasta, r.totales.devengado, r.totales.deducciones, r.totales.a_fondo, r.totales.neto, json, huella, lote || original?.lote || null, usuario || null, creado, original?.id ?? null);
  const id = Number(res.lastInsertRowid);
  for (const a of adjuntos) D.run("UPDATE adjuntos SET entidad = 'liquidacion', entidad_id = ? WHERE id = ?", id, a.id);
  // Al corregir, los documentos de la anterior siguen sirviendo: se copian a la nueva (la anulada conserva los suyos).
  if (original) {
    D.run(`INSERT INTO adjuntos (entidad, entidad_id, nombre, tipo, tamano, sha256, contenido, nota, creado_por, creado_en)
      SELECT 'liquidacion', ?, nombre, tipo, tamano, sha256, contenido, ?, creado_por, creado_en FROM adjuntos WHERE entidad = 'liquidacion' AND entidad_id = ? ORDER BY id`,
    id, `Venía de la N.º ${original.consecutivo}`, original.id);
  }
  for (const c of r.conceptos) {
    D.run('INSERT INTO conceptos (liquidacion_id, trabajador_id, concepto, detalle, desde, hasta, dias, base, valor, destino) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      id, pedido.trabajador_id, c.concepto, c.detalle || null, c.desde, c.hasta, c.dias, c.base, c.valor, c.destino);
  }
  if (r.tipo === 'definitiva') {
    D.run('UPDATE trabajadores SET fecha_retiro = ?, motivo_retiro = ?, actualizado = ? WHERE id = ?', r.hasta, r.opciones.motivo_retiro, creado, pedido.trabajador_id);
  }
  D.bitacora(usuario, `${original ? `Corrigió la N.º ${original.consecutivo} con la ` : ''}Liquidación N.º ${consecutivo} (${r.tipo === 'varios' ? r.partes.map((p) => C.TIPOS[p.tipo]).join(' + ') : C.TIPOS[r.tipo]})`, 'liquidacion', id, { trabajador: nombreCompleto(ctx.trab), desde: r.desde, hasta: r.hasta, neto: r.totales.neto, a_fondo: r.totales.a_fondo, lote, corrige: original?.consecutivo, motivo_correccion: pedido.motivo_correccion, adjuntos: adjuntos.map((a) => a.nombre) });
  return { id, consecutivo };
}

function verLiquidacion(id) {
  const l = D.get('SELECT * FROM liquidaciones WHERE id = ?', id);
  if (!l) falla('No existe esa liquidación.');
  const datos = JSON.parse(l.datos);
  const integra = crypto.createHash('sha256').update(l.datos).digest('hex') === l.huella;
  const sellados = new Set((datos.adjuntos || []).map((a) => a.id));
  const adjuntos = D.all("SELECT id, nombre, tipo, tamano, sha256, nota, creado_por, creado_en FROM adjuntos WHERE entidad = 'liquidacion' AND entidad_id = ? ORDER BY id", id)
    .map((a) => ({ ...a, sellado: sellados.has(a.id) }));
  const corrige = l.corrige_a ? D.get('SELECT id, consecutivo FROM liquidaciones WHERE id = ?', l.corrige_a) : null;
  const corregida_por = D.get('SELECT id, consecutivo FROM liquidaciones WHERE corrige_a = ? ORDER BY id DESC LIMIT 1', id) || null;
  return { ...l, datos, integra, adjuntos, corrige, corregida_por };
}

function anular(usuario, id, motivo) {
  motivo = texto(motivo, 500);
  if (!motivo || motivo.length < 5) falla('Escriba el motivo de la anulación (queda en el registro).');
  const l = D.get('SELECT * FROM liquidaciones WHERE id = ?', id);
  if (!l) falla('No existe esa liquidación.');
  if (l.estado === 'anulada') falla('Ya estaba anulada.');
  validarAnulable(l);
  D.tx(() => marcarAnulada(usuario, l, motivo));
}

function historial(q) {
  const f = [];
  const p = [];
  const campo = q.campo === 'periodo' ? 'periodo' : 'fecha';
  if (q.desde && F.valida(q.desde)) { f.push(campo === 'fecha' ? 'l.fecha >= ?' : 'l.hasta >= ?'); p.push(q.desde); }
  if (q.hasta && F.valida(q.hasta)) { f.push(campo === 'fecha' ? 'l.fecha <= ?' : 'COALESCE(l.desde, l.hasta) <= ?'); p.push(q.hasta); }
  if (q.tipo) {
    // Un comprobante con varias cosas sale también al filtrar por cada una de ellas
    const conc = { cesantias: 'cesantias', prima: 'prima', disfrute: 'vacaciones_disfrutadas', vacaciones: 'vacaciones' }[q.tipo];
    if (conc) { f.push("(l.tipo = ? OR (l.tipo = 'varios' AND EXISTS (SELECT 1 FROM conceptos c WHERE c.liquidacion_id = l.id AND c.concepto = ?)))"); p.push(q.tipo, conc); }
    else { f.push('l.tipo = ?'); p.push(q.tipo); }
  }
  if (q.sede) { f.push('t.sede = ?'); p.push(q.sede); }
  if (q.trabajador_id) { f.push('l.trabajador_id = ?'); p.push(Number(q.trabajador_id)); }
  if (q.lote) { f.push('l.lote = ?'); p.push(q.lote); }
  if (q.q) {
    f.push("(t.documento LIKE ? OR (t.nombres || ' ' || t.apellidos) LIKE ? OR CAST(l.consecutivo AS TEXT) = ?)");
    p.push(`%${q.q}%`, `%${q.q}%`, String(q.q).replace(/\D/g, ''));
  }
  if (q.estado !== 'todas') { f.push('l.estado = ?'); p.push(q.estado === 'anulada' ? 'anulada' : 'vigente'); }
  const filas = D.all(`SELECT l.id, l.consecutivo, l.tipo, l.fecha, (SELECT GROUP_CONCAT(DISTINCT concepto) FROM conceptos WHERE liquidacion_id = l.id) conceptos_lista, l.desde, l.hasta, l.devengado, l.deducciones, l.a_fondo, l.neto, l.estado, l.anulada_motivo, l.lote, l.creado_por,
      t.id trabajador_id, t.documento, (t.nombres || ' ' || t.apellidos) nombre, t.sede, t.cargo,
      (SELECT COALESCE(SUM(valor),0) FROM conceptos WHERE liquidacion_id = l.id AND concepto = 'cesantias') cesantias,
      (SELECT COALESCE(SUM(valor),0) FROM conceptos WHERE liquidacion_id = l.id AND concepto = 'intereses') intereses,
      (SELECT COALESCE(SUM(valor),0) FROM conceptos WHERE liquidacion_id = l.id AND concepto = 'prima') prima,
      (SELECT COALESCE(SUM(valor),0) FROM conceptos WHERE liquidacion_id = l.id AND concepto IN ('vacaciones','vacaciones_disfrutadas')) vacaciones,
      (SELECT COALESCE(SUM(valor),0) FROM conceptos WHERE liquidacion_id = l.id AND concepto = 'indemnizacion') indemnizacion,
      (SELECT COALESCE(SUM(valor),0) FROM conceptos WHERE liquidacion_id = l.id AND concepto IN ('salario','auxilio_salario','otro_devengo')) otros
    FROM liquidaciones l JOIN trabajadores t ON t.id = l.trabajador_id
    ${f.length ? 'WHERE ' + f.join(' AND ') : ''} ORDER BY l.fecha DESC, l.consecutivo DESC LIMIT 5000`, ...p);
  const totales = {};
  for (const k of ['cesantias', 'intereses', 'prima', 'vacaciones', 'indemnizacion', 'otros', 'devengado', 'deducciones', 'a_fondo', 'neto']) {
    totales[k] = filas.filter((x) => x.estado === 'vigente').reduce((s, x) => s + (x[k] || 0), 0);
  }
  return { filas, totales };
}

// ---------------------------------------------------------------- liquidación de todos a la vez

function masivaCalcular(b) {
  const tipo = b.tipo === 'prima' ? 'prima' : 'cesantias';
  const corte = texto(b.corte, 10);
  if (!F.valida(corte)) falla('La fecha de corte no es válida.');
  const f = ['fecha_ingreso <= ?', 'fecha_retiro IS NULL'];
  const p = [corte];
  if (b.sede) { f.push('sede = ?'); p.push(b.sede); }
  const trabs = D.all(`SELECT * FROM trabajadores WHERE ${f.join(' AND ')} ORDER BY sede, nombres, apellidos`, ...p);
  const listos = [];
  const omitidos = [];
  for (const t of trabs) {
    const nombre = nombreCompleto(t);
    if (t.tipo_salario === 'integral') { omitidos.push({ id: t.id, nombre, documento: t.documento, sede: t.sede, motivo: 'Salario integral: no aplica.' }); continue; }
    try {
      const ctx = contexto(t.id);
      const h = C.hastaLiquidado(ctx, tipo);
      if (h.hasta >= corte) { omitidos.push({ id: t.id, nombre, documento: t.documento, sede: t.sede, motivo: `Ya liquidado hasta el ${F.larga(F.finLaboral(h.hasta))}.` }); continue; }
      const r = C.armar(ctx, { tipo, hasta: corte, fecha: b.fecha || F.hoy(), opciones: {} });
      if (r.bloqueos.length) { omitidos.push({ id: t.id, nombre, documento: t.documento, sede: t.sede, motivo: r.bloqueos[0] }); continue; }
      const inicio = tipo === 'cesantias' ? `${F.anio(corte)}-01-01` : corte.slice(5) === '06-30' ? `${F.anio(corte)}-01-01` : `${F.anio(corte)}-07-01`;
      const suma = (k) => r.conceptos.filter((c) => c.concepto === k).reduce((s, c) => s + c.valor, 0);
      listos.push({
        id: t.id, nombre, documento: t.documento, sede: t.sede, desde: r.desde, hasta: r.hasta,
        dias: r.conceptos.filter((c) => c.concepto === tipo).reduce((s, c) => s + c.dias, 0),
        base: r.conceptos.find((c) => c.concepto === tipo)?.base ?? 0,
        principal: suma(tipo), intereses: suma('intereses'), neto: r.totales.neto, a_fondo: r.totales.a_fondo,
        fondo: t.fondo_cesantias, avisos: r.avisos, desde_ingreso: h.origen === 'ingreso' && r.desde < inicio, incluye_anteriores: r.desde < inicio, inicio,
      });
    } catch (e) {
      omitidos.push({ id: t.id, nombre, documento: t.documento, sede: t.sede, motivo: e.message });
    }
  }
  return { tipo, corte, futuro: corte > F.hoy(), listos, omitidos };
}

function masivaGuardar(usuario, b) {
  const tipo = b.tipo === 'prima' ? 'prima' : 'cesantias';
  const corte = texto(b.corte, 10);
  const ids = (b.ids || []).map(Number).filter(Boolean);
  if (!ids.length) falla('No hay trabajadores seleccionados.');
  const lote = `${tipo}-${corte}-${Date.now().toString(36)}`;
  const creadas = D.tx(() => ids.map((id) => guardarLiquidacion(usuario, { trabajador_id: id, tipo, hasta: corte, fecha: b.fecha, opciones: {} }, lote)));
  D.bitacora(usuario, `Liquidó ${creadas.length} trabajadores a la vez (${C.TIPOS[tipo]} al ${corte})`, 'lote', null, { lote });
  return { lote, creadas };
}

// ---------------------------------------------------------------- pendientes legales

function pendientes() {
  const hoy = F.hoy();
  const y = F.anio(hoy);
  const grupos = {};
  const add = (clave, titulo, explica, vence, t, extra) => {
    if (!grupos[clave]) grupos[clave] = { clave, titulo, explica, vence, vencido: vence ? hoy > vence : false, trabajadores: [] };
    grupos[clave].trabajadores.push({ id: t.id, nombre: nombreCompleto(t), documento: t.documento, sede: t.sede, ...extra });
  };
  const activos = D.all('SELECT * FROM trabajadores WHERE fecha_retiro IS NULL ORDER BY nombres, apellidos');
  for (const t of activos) {
    let ctx;
    try { ctx = contexto(t.id); } catch { continue; }
    if (!ctx.salarios.length) { add('sin_salario', 'Trabajadores sin salario registrado', 'No se les puede liquidar nada hasta que tengan salario.', null, t); continue; }
    if (t.tipo_salario !== 'integral') {
      const ces = C.hastaLiquidado(ctx, 'cesantias').hasta;
      const finAnt = `${y - 1}-12-31`;
      if (t.fecha_ingreso <= finAnt && ces < finAnt) {
        add(`int_${y - 1}`, `Intereses sobre cesantías de ${y - 1} sin pagar`, `Se pagan al trabajador a más tardar el 31 de enero de ${y}. Si se pagan tarde, la ley obliga a pagar otro tanto igual (Ley 52 de 1975). Se liquidan junto con las cesantías.`, `${y}-01-31`, t, { hasta: ces });
        add(`ces_${y - 1}`, `Cesantías ${y - 1} sin liquidar`, `Se consignan al fondo a más tardar el 14 de febrero de ${y}. Si se consignan tarde, la ley cobra un día de salario por cada día de retraso (Art. 99 Ley 50 de 1990).`, `${y}-02-14`, t, { hasta: ces });
      }
      const pri = C.hastaLiquidado(ctx, 'prima').hasta;
      if (t.fecha_ingreso <= finAnt && pri < finAnt) {
        add(`pri_${y - 1}`, `Prima de diciembre de ${y - 1} sin liquidar`, `La prima del segundo semestre de ${y - 1} vencía el 20 de diciembre.`, `${y - 1}-12-20`, t, { hasta: pri });
      }
      const junio = `${y}-06-30`;
      if (hoy > junio && t.fecha_ingreso <= junio && pri < junio) {
        add(`pri_${y}_1`, `Prima de junio de ${y} sin liquidar`, 'La prima del primer semestre se paga a más tardar el 30 de junio.', junio, t, { hasta: pri });
      }
      const dic = `${y}-12-20`;
      if (hoy >= `${y}-11-15` && hoy <= `${y}-12-31` && pri < `${y}-12-31`) {
        add(`pri_${y}_2`, `Prima de diciembre de ${y}`, 'Se paga a más tardar el 20 de diciembre. Use "Liquidar a todos" con corte al 30 de diciembre.', dic, t, { hasta: pri });
      }
    }
    if (t.tipo_salario !== 'integral') {
      const huecos = [];
      for (const [k, que] of [['cesantias', 'cesantías'], ['prima', 'prima']]) for (const h of C.huecos(ctx, k)) huecos.push({ que, desde: h.desde, hasta: h.hasta });
      if (huecos.length) add('huecos', 'Periodos que quedaron sin liquidar', 'Se liquidó un periodo más adelante y quedó tiempo sin pagar antes. En la ficha de cada uno está el botón para liquidarlo.', null, t, { huecos });
      // Solo lo que todavía no se ha liquidado
      const ces2 = C.hastaLiquidado(ctx, 'cesantias').hasta, pri2 = C.hastaLiquidado(ctx, 'prima').hasta;
      const sinNota = C.diasNominaSinExplicar(ctx, F.sumarDias(ces2 < pri2 ? ces2 : pri2, 1), hoy);
      if (sinNota.length) add('nomina_dias', 'La nómina trae menos días y no hay licencia anotada', 'Si fue licencia no remunerada o suspensión, anótela en "Días no pagados" de su ficha para que se descuente. Si fueron vacaciones o incapacidad, no hay que hacer nada.', null, t, { nota: sinNota.map((x) => `${x.dias} de ${x.tocaban} días en ${x.planilla}`).join('; ') });
    }
    const vac = C.saldoVacaciones(ctx, hoy);
    // Sin saldo inicial ni vacaciones registradas, el programa cree que nunca ha salido a vacaciones desde que entró.
    const sinHistoria = C.sinHistoriaVacaciones(ctx);
    if (sinHistoria && F.dias360(t.fecha_ingreso, hoy) > 360) {
      add('vac_sin_historia', 'Vacaciones sin confirmar', 'El programa no tiene anotadas las vacaciones que ya tomaron, así que cuenta todas desde su ingreso (por eso salen tantos días). Antes de pagar vacaciones o una liquidación definitiva, ponga en su ficha (Editar datos) los días pendientes y a qué fecha, o anote las vacaciones que tomó; también se pueden subir por Excel.', null, t, { dias: vac.pendientes });
    }
    if (vac.pendientes >= 30) {
      add('vac_acumuladas', 'Vacaciones muy acumuladas', 'Tienen 2 periodos o más sin disfrutar. La ley permite acumular hasta 2 años (Art. 190 CST): conviene programarlas.', null, t, { dias: vac.pendientes });
    }
  }
  // Avisos que no son de una persona: el salario mínimo del año
  const generales = [];
  const tieneAnio = (a) => !!D.get('SELECT anio FROM parametros WHERE anio = ?', a);
  if (!tieneAnio(y)) generales.push({ titulo: `Falta el salario mínimo de ${y}`, explica: `Sin el salario mínimo y el auxilio de transporte de ${y} no se puede liquidar nada de este año. Búsquelos en el decreto del Gobierno y póngalos en Ajustes y copias → Valores de cada año.`, vencido: true });
  else if (hoy >= `${y}-12-15` && !tieneAnio(y + 1)) generales.push({ titulo: `En enero cambia el salario mínimo`, explica: `Cuando salga el decreto del salario mínimo de ${y + 1}, póngalo en Ajustes y copias → Valores de cada año. Sin él, el programa no deja liquidar nada de ${y + 1}.`, vencido: false });
  const orden = Object.values(grupos).sort((a, b) => (b.vencido - a.vencido) || (a.vence || 'z').localeCompare(b.vence || 'z'));
  const proximos = [];
  const venc = [
    [`${y}-01-31`, `Pagar intereses sobre cesantías de ${y - 1} al trabajador`],
    [`${y}-02-14`, `Consignar cesantías de ${y - 1} al fondo`],
    [`${y}-06-30`, `Pagar prima del primer semestre de ${y}`],
    [`${y}-12-20`, `Pagar prima del segundo semestre de ${y}`],
    [`${y + 1}-01-31`, `Pagar intereses sobre cesantías de ${y}`],
    [`${y + 1}-02-14`, `Consignar cesantías de ${y} al fondo`],
  ];
  for (const [f, txt] of venc) if (f >= hoy) proximos.push({ fecha: f, texto: txt, faltan: F.dias360(hoy, f) - 1 });
  // Plazos que caen sábado, domingo o festivo: mejor pagar el último día hábil antes (el 20-dic-2026, el 31-ene y el 14-feb-2027 son domingo).
  const avisoDia = (f) => (f && !F.esHabil(f, false) ? ` El ${F.conDia(f)} no es día hábil: mejor pagar a más tardar el ${F.conDia(F.habilAnterior(f))}.` : '');
  for (const g of orden) if (g.vence && !g.vencido) g.explica += avisoDia(g.vence);
  for (const p of proximos) p.nota = avisoDia(p.fecha).trim();
  return { hoy, grupos: orden, generales, proximos: proximos.slice(0, 3) };
}

// ---------------------------------------------------------------- importación

const ETIQUETA_CAMPO = {
  tipo_documento: 'tipo de documento', documento: 'documento', nombres: 'nombres', apellidos: 'apellidos', cargo: 'cargo', sede: 'sede',
  telefono: 'teléfono', correo: 'correo', fecha_ingreso: 'fecha de ingreso', tipo_salario: 'tipo de salario', salario_minimo: 'gana el mínimo',
  auxilio_transporte: 'auxilio de transporte', fondo_cesantias: 'fondo de cesantías', cesantias_hasta_inicial: 'cesantías liquidadas hasta',
  prima_hasta_inicial: 'prima liquidada hasta', vac_saldo_fecha: 'vacaciones contadas al', vac_saldo_dias: 'vacaciones pendientes', notas: 'notas',
};
function verValor(k, v) {
  if (v == null || v === '') return '(vacío)';
  if (k === 'salario_minimo') return Number(v) ? 'sí' : 'no';
  if (k === 'auxilio_transporte') return v === 'no' ? 'no aplica' : 'sí';
  if (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v)) return v.split('-').reverse().join('/');
  if (k === 'vac_saldo_dias') return String(v).replace('.', ',') + ' días';
  return String(v);
}

function importarTrabajadores(usuario, filas, guardar) {
  if (!Array.isArray(filas) || !filas.length) falla('El archivo no trae filas.');
  if (filas.length > 5000) falla('Máximo 5.000 filas por archivo.');
  const res = [];
  const vistos = new Set();
  for (let i = 0; i < filas.length; i++) {
    const b = filas[i];
    const fila = b.__fila || i + 2;
    try {
      const doc = String(b.documento || '').replace(/[\s.]/g, '');
      if (!doc) falla('Falta el documento.');
      if (vistos.has(doc)) falla('El documento está repetido en el archivo.');
      vistos.add(doc);
      const existente = D.get('SELECT * FROM trabajadores WHERE documento = ? AND fecha_retiro IS NULL', doc);
      const retirado = existente ? null : D.get('SELECT * FROM trabajadores WHERE documento = ? ORDER BY fecha_retiro DESC LIMIT 1', doc);
      if (retirado) falla(`Figura retirado desde el ${F.larga(retirado.fecha_retiro)}. Si volvió a trabajar, abra su ficha y use "Volver a contratar".`);
      const salario = entero(b.salario);
      if (existente) {
        const datos = { ...existente };
        for (const k of CAMPOS_TRAB) if (b[k] != null && b[k] !== '') datos[k] = b[k];
        const limpio = limpiarTrabajador(datos, existente);
        const actual = C.salarioEn({ salarios: D.all('SELECT vigente_desde, salario FROM salarios WHERE trabajador_id = ?', existente.id) }, F.hoy());
        const cambiaSalario = salario && salario !== actual;
        const desdeSal = fechaOpcional(b.salario_desde, 'salario desde') || F.hoy();
        // Qué cambia exactamente (las celdas vacías del Excel NO borran lo que ya hay)
        const cambios = CAMPOS_TRAB.filter((k) => (existente[k] ?? null) !== (limpio[k] ?? null))
          .map((k) => `${ETIQUETA_CAMPO[k] || k}: ${verValor(k, existente[k])} → ${verValor(k, limpio[k])}`);
        if (cambiaSalario) cambios.push(`salario: ${C.pesos(actual)} → ${C.pesos(salario)} desde el ${verValor('f', desdeSal)}${b.salario_desde ? '' : ' (no venía "Salario desde": si el aumento fue antes, ponga esa columna)'}`);
        const nLiq = D.get("SELECT COUNT(*) n FROM liquidaciones WHERE trabajador_id = ? AND estado = 'vigente'", existente.id).n;
        const delicado = ['fecha_ingreso', 'cesantias_hasta_inicial', 'prima_hasta_inicial', 'vac_saldo_dias', 'vac_saldo_fecha'].some((k) => (existente[k] ?? null) !== (limpio[k] ?? null));
        const aviso = nLiq > 0 && delicado ? `Ojo: ya tiene ${nLiq} ${nLiq === 1 ? 'liquidación guardada' : 'liquidaciones guardadas'}; esas no cambian. Revise su ficha después de importar.` : '';
        res.push({ fila, documento: doc, nombre: nombreCompleto(limpio), accion: cambios.length ? 'actualizar' : 'igual', aviso, detalle: cambios.length ? 'Cambia ' + cambios.join(' · ') : 'Sin cambios' });
        if (guardar) {
          editarTrabajador(usuario, existente.id, Object.fromEntries(Object.entries(b).filter(([k, v]) => CAMPOS_TRAB.includes(k) && v != null && v !== '')));
          if (cambiaSalario) agregarSalario(usuario, existente.id, { vigente_desde: desdeSal, salario, nota: 'Importado de Excel' });
          if (b.fecha_retiro && !existente.fecha_retiro) res[res.length - 1].detalle += ' (la fecha de retiro no se importa: haga la liquidación definitiva)';
        }
      } else {
        const t = limpiarTrabajador(b);
        if (!salario || salario <= 0) falla('Falta el salario.');
        const minimo = b.salario_minimo == null || b.salario_minimo === '' ? salario === minimoDe(F.hoy()) && t.tipo_salario !== 'integral' : !!t.salario_minimo;
        const borrado = D.get("SELECT fecha FROM bitacora WHERE accion LIKE 'Borró al trabajador %' AND accion LIKE ? ORDER BY id DESC LIMIT 1", `%(${doc})`);
        res.push({ fila, documento: doc, nombre: nombreCompleto(t), accion: 'nuevo', aviso: borrado ? `Ojo: esta persona se borró del programa el ${F.larga(borrado.fecha.slice(0, 10))} ("Se cargó por error"). Si no trabaja aquí, quítela del archivo antes de subirlo.` : '', detalle: `Ingreso ${t.fecha_ingreso} · ${C.pesos(salario)}${minimo ? ' · gana el mínimo: se ajusta solo cada año' : b.salario_desde ? ` desde ${fechaOpcional(b.salario_desde, 'salario desde')}` : ' · se toma como si lo ganara desde su ingreso'}` });
        if (guardar) crearTrabajador(usuario, b);
      }
    } catch (e) {
      res.push({ fila, documento: b.documento || '', nombre: `${b.nombres || ''} ${b.apellidos || ''}`.trim(), accion: 'error', detalle: e.message });
    }
  }
  if (guardar) D.bitacora(usuario, `Importó trabajadores desde Excel (${res.filter((r) => r.accion !== 'error').length} filas)`, 'importacion', null, null);
  return res;
}

// ---------------------------------------------------------------- liquidaciones de ANTES del programa (Excel de la empresa)
// Se guardan tal cual (es historia de lo que se pagó). No se recalculan. Si alguien ya está en el programa y no tiene
// "liquidada hasta" o lo tiene más atrás, se corre hasta donde dice el Excel para no volver a pagarle ese periodo.
const CONCEPTOS_HIST = { prima: 'Prima de servicios', cesantias: 'Cesantías e intereses', vacaciones: 'Vacaciones', otro: 'Otro pago' };
function importarHistoricas(usuario, b) {
  const concepto = CONCEPTOS_HIST[b.concepto] ? b.concepto : falla('Escoja qué es: prima, cesantías, vacaciones u otro.');
  const filas = Array.isArray(b.filas) ? b.filas : [];
  if (!filas.length) falla('El archivo no trae filas.');
  if (filas.length > 20000) falla('Máximo 20.000 filas por archivo.');
  const fuente = texto(b.fuente, 200) || 'Excel';
  const guardar = !!b.guardar;
  const res = [];
  const vistos = new Map();
  const ajustes = new Map(); // trabajador → el "hasta" más lejano de este archivo
  const n = (v) => (v == null || v === '' || !Number.isFinite(Number(v)) ? null : Math.round(Number(v)));
  for (let i = 0; i < filas.length; i++) {
    const f = filas[i];
    const fila = f.__fila || i + 2;
    const doc = String(f.documento ?? '').replace(/\D/g, '');
    const nombreExcel = texto(f.nombre, 150) || '';
    try {
      const hasta = F.valida(f.hasta) ? f.hasta : null;
      const desde = F.valida(f.desde) ? f.desde : null;
      const hastaTxt = f.hasta_txt || (f.hasta && !hasta ? f.hasta : '');
      const desdeTxt = f.desde_txt || (f.desde && !desde ? f.desde : '');
      const valor = n(f.valor);
      // Filas de totales, resúmenes por fondo o notas al final de la hoja: no son pagos de nadie.
      const pareceResumen = (!hasta && valor == null) || (doc.length < 5 && (!nombreExcel || valor == null));
      if (pareceResumen) { res.push({ fila, documento: doc, nombre: nombreExcel, accion: 'resumen', detalle: 'Fila de totales, resumen o nota: se salta.' }); continue; }
      if (doc.length < 5) falla('Falta la cédula en el Excel: pídala y vuelva a subir la hoja (no duplica lo que ya entró).');
      if (!hasta) falla(hastaTxt ? `La fecha final "${String(hastaTxt).slice(0, 40)}" no se entiende.` : 'Falta la fecha final del periodo.');
      if (valor == null || valor < 0) falla('Falta el valor.');
      const obs = [texto(f.observacion, 300), desdeTxt && !desde ? `Fecha inicial en el Excel: "${String(desdeTxt).slice(0, 40)}"` : ''].filter(Boolean).join(' · ') || null;
      const dias = f.dias == null || f.dias === '' ? null : Number(String(f.dias).replace(',', '.'));
      const reg = {
        documento: doc, nombre: nombreExcel || null, concepto, desde, hasta, dias: Number.isFinite(dias) ? dias : null,
        salario: n(f.salario), auxilio: n(f.auxilio), base: n(f.base), valor, intereses: concepto === 'cesantias' ? n(f.intereses) : null,
        descuentos: n(f.descuentos), neto: n(f.neto), fondo: texto(f.fondo, 80), observacion: obs,
      };
      const t = D.get('SELECT * FROM trabajadores WHERE documento = ? ORDER BY (fecha_retiro IS NULL) DESC, fecha_ingreso DESC LIMIT 1', doc);
      const base = { fila, documento: doc, nombre: t ? nombreCompleto(t) : nombreExcel, en_programa: !!t, desde, hasta, valor, intereses: reg.intereses };
      const clave = doc + '|' + hasta;
      if (vistos.has(clave)) {
        const otra = vistos.get(clave);
        if (otra.valor === valor) { res.push({ ...base, accion: 'repetida', detalle: `Repetida en el archivo (igual a la fila ${otra.fila}): se guarda una sola vez.` }); continue; }
        falla(`Está dos veces con valores distintos (fila ${otra.fila}: ${C.pesos(otra.valor)}; esta: ${C.pesos(valor)}). Corrija el Excel y vuelva a subirlo.`);
      }
      vistos.set(clave, { fila, valor });
      const ya = D.get('SELECT * FROM historicas WHERE documento = ? AND concepto = ? AND hasta = ?', doc, concepto, hasta);
      let accion = 'nuevo';
      let detalle = t ? '' : 'No está en el programa (ya no trabaja o falta cargarlo): se guarda igual y sale en su ficha cuando se cargue.';
      if (ya) {
        const campos = ['desde', 'dias', 'salario', 'auxilio', 'base', 'valor', 'intereses', 'descuentos', 'neto', 'fondo'];
        const cambia = campos.filter((k) => (ya[k] ?? null) !== (reg[k] ?? null));
        accion = cambia.length ? 'actualizar' : 'igual';
        detalle = cambia.length ? 'Ya estaba; cambia: ' + cambia.join(', ') : 'Ya estaba igual.';
      }
      // ¿Hay que correr su "liquidada hasta"? Solo prima y cesantías, y solo si el pago es de su contrato actual.
      if (t && (concepto === 'prima' || concepto === 'cesantias') && hasta >= t.fecha_ingreso) {
        const k = t.id;
        if (!ajustes.has(k) || ajustes.get(k).hasta < hasta) ajustes.set(k, { t, hasta, pos: res.length });
      }
      res.push({ ...base, accion, detalle });
      if (guardar && accion !== 'igual') {
        const cols = ['documento', 'nombre', 'concepto', 'desde', 'hasta', 'dias', 'salario', 'auxilio', 'base', 'valor', 'intereses', 'descuentos', 'neto', 'fondo', 'observacion'];
        if (ya) D.run(`UPDATE historicas SET ${cols.map((c) => c + ' = ?').join(', ')}, fuente = ? WHERE id = ?`, ...cols.map((c) => reg[c]), fuente, ya.id);
        else D.run(`INSERT INTO historicas (${cols.join(', ')}, fuente, creado, creado_por) VALUES (${cols.map(() => '?').join(', ')}, ?, ?, ?)`, ...cols.map((c) => reg[c]), fuente, D.ahora(), usuario || null);
      }
    } catch (e) {
      if (!(e instanceof ErrorUsuario)) throw e;
      res.push({ fila, documento: doc, nombre: nombreExcel, accion: 'error', detalle: e.message });
    }
  }
  // Correr "liquidada hasta" donde el Excel muestra que ya se pagó más adelante
  for (const { t, hasta, pos } of ajustes.values()) {
    const actual = C.hastaLiquidado(contexto(t.id), concepto).hasta;
    if (F.finComercial(hasta) <= actual) continue;
    const campo = concepto === 'prima' ? 'prima_hasta_inicial' : 'cesantias_hasta_inicial';
    const antes = actual && actual >= t.fecha_ingreso ? F.larga(F.finLaboral(actual)) : 'nunca';
    res[pos].ajuste = `Su ${concepto === 'prima' ? 'prima' : 'cesantía'} queda liquidada hasta el ${F.larga(F.finLaboral(hasta))} (antes: ${antes}), para no volver a pagar ese periodo.`;
    if (guardar) editarTrabajador(usuario, t.id, { [campo]: hasta });
  }
  if (guardar) D.bitacora(usuario, `Importó pagos de antes del programa (${CONCEPTOS_HIST[concepto]}, ${res.filter((r) => r.accion === 'nuevo' || r.accion === 'actualizar').length} filas) de ${fuente}`, 'importacion', null, null);
  return res;
}

function listaHistoricas(q) {
  const f = [];
  const p = [];
  if (q.concepto && CONCEPTOS_HIST[q.concepto]) { f.push('h.concepto = ?'); p.push(q.concepto); }
  if (q.anio && /^\d{4}$/.test(q.anio)) { f.push('substr(h.hasta, 1, 4) = ?'); p.push(q.anio); }
  if (q.q) {
    f.push("(h.documento LIKE ? OR h.nombre LIKE ? OR EXISTS (SELECT 1 FROM trabajadores t WHERE t.documento = h.documento AND (t.nombres || ' ' || t.apellidos) LIKE ?))");
    p.push(`%${q.q}%`, `%${q.q}%`, `%${q.q}%`);
  }
  return D.all(`SELECT h.*, (SELECT COUNT(*) FROM adjuntos a WHERE a.entidad = 'historica' AND a.entidad_id = h.id) adjuntos,
    (SELECT t.id FROM trabajadores t WHERE t.documento = h.documento ORDER BY (t.fecha_retiro IS NULL) DESC, t.fecha_ingreso DESC LIMIT 1) trabajador_id,
    (SELECT t.nombres || ' ' || t.apellidos FROM trabajadores t WHERE t.documento = h.documento ORDER BY (t.fecha_retiro IS NULL) DESC, t.fecha_ingreso DESC LIMIT 1) nombre_programa
    FROM historicas h ${f.length ? 'WHERE ' + f.join(' AND ') : ''} ORDER BY h.hasta DESC, h.concepto, h.nombre`, ...p);
}

// Cambiar un pago de antes del programa (p. ej. se le descontaron días): queda el motivo y lo que había antes.
function editarHistorica(usuario, id, b) {
  const h = D.get('SELECT * FROM historicas WHERE id = ?', id);
  if (!h) falla('Ese registro ya no existe.');
  const motivo = texto(b.motivo, 300);
  if (!motivo || motivo.length < 5) falla('Escriba por qué se cambia (queda en el registro).');
  const numero = (v, nombre, decimales) => {
    if (v === '' || v == null) return null;
    const n = Number(String(v).replace(/\$|\s/g, '').replace(',', '.'));
    if (!Number.isFinite(n) || n < 0) falla(`${nombre} no es un número válido.`);
    return decimales ? Math.round(n * 100) / 100 : Math.round(n);
  };
  const dias = 'dias' in b ? numero(b.dias, 'Los días', true) : h.dias;
  if (dias != null && dias > 400) falla('Los días no pueden pasar de 400.');
  const valor = 'valor' in b ? numero(b.valor, 'El valor') : h.valor;
  if (valor == null) falla('Falta el valor.');
  const intereses = 'intereses' in b ? numero(b.intereses, 'Los intereses') : h.intereses;
  const neto = h.neto != null && h.concepto !== 'cesantias' ? h.neto + (valor - h.valor) : h.neto;
  if (dias === h.dias && valor === h.valor && intereses === h.intereses) falla('No cambió nada.');
  const obs = [h.observacion, `Cambiado el ${F.hoy()}${usuario ? ' por ' + usuario : ''}: ${motivo}`].filter(Boolean).join(' · ').slice(0, 1500);
  D.tx(() => {
    D.run('UPDATE historicas SET dias = ?, valor = ?, intereses = ?, neto = ?, observacion = ? WHERE id = ?', dias, valor, intereses, neto, obs, id);
    D.bitacora(usuario, `Cambió un pago de antes del programa (${CONCEPTOS_HIST[h.concepto]} de ${h.nombre || h.documento}, ${h.hasta})`, 'historica', id,
      { motivo, antes: { dias: h.dias, valor: h.valor, intereses: h.intereses, neto: h.neto }, despues: { dias, valor, intereses, neto } });
  });
}

function importarNomina(usuario, filas, guardar) {
  if (!Array.isArray(filas) || !filas.length) falla('El archivo no trae filas.');
  if (filas.length > 100000) falla('Máximo 100.000 filas por archivo.');
  const res = [];
  const porDoc = new Map(D.all('SELECT id, documento, nombres, apellidos FROM trabajadores ORDER BY (fecha_retiro IS NULL), fecha_ingreso').map((t) => [t.documento, t]));
  // Si la nómina viene por quincenas, cada planilla (corte) es su propia fila y las del mes se suman al
  // promediar. Las filas repetidas del mismo trabajador y la misma planilla se suman entre sí.
  const grupos = new Map();
  for (let i = 0; i < filas.length; i++) {
    const b = filas[i];
    const fila = b.__fila || i + 2;
    try {
      const doc = String(b.documento || '').replace(/[\s.]/g, '');
      const t = porDoc.get(doc);
      if (!t) falla('No hay ningún trabajador con ese documento. Impórtelo primero.');
      const periodo = String(b.periodo || '').slice(0, 7);
      if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(periodo)) falla('El periodo (mes) no es válido.');
      const corte = F.valida(b.corte) && b.corte.slice(0, 7) === periodo ? b.corte : '';
      const v = (k) => entero(b[k]) || 0;
      const reg = { basico: v('salario_basico'), extras: v('extras_recargos'), nocturno: v('recargo_nocturno'), comisiones: v('comisiones'), otros: v('otros_salariales'), aux: v('auxilio_transporte'), dias: entero(b.dias) || 0 };
      const clave = `${t.id}|${periodo}|${corte}`;
      const g = grupos.get(clave);
      let detalle = `${periodo}${corte ? ` · planilla del ${F.larga(corte)}` : ''}: variable ${C.pesos(reg.extras + reg.nocturno + reg.comisiones + reg.otros)}`;
      if (g) {
        for (const k of Object.keys(reg)) g.reg[k] += reg[k];
        detalle += ` (se suma con la fila ${g.fila})`;
      } else grupos.set(clave, { t, periodo, corte, reg, fila });
      res.push({ fila, documento: doc, nombre: nombreCompleto(t), accion: 'ok', detalle });
    } catch (e) {
      res.push({ fila, documento: b.documento || '', nombre: '', accion: 'error', detalle: e.message });
    }
  }
  if (guardar) {
    D.tx(() => {
      for (const { t, periodo, corte, reg } of grupos.values()) {
        // Un mes va o con su total (corte '') o por planillas: nunca las dos cosas, para no contarlo doble
        if (corte) D.run("DELETE FROM nomina WHERE trabajador_id = ? AND periodo = ? AND corte IN ('', ?)", t.id, periodo, corte);
        else D.run('DELETE FROM nomina WHERE trabajador_id = ? AND periodo = ?', t.id, periodo);
        D.run(`INSERT INTO nomina (trabajador_id, periodo, corte, salario_basico, extras_recargos, recargo_nocturno, comisiones, otros_salariales, auxilio_transporte, dias, fuente, creado)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'excel', ?)`,
        t.id, periodo, corte, reg.basico, reg.extras, reg.nocturno, reg.comisiones, reg.otros, reg.aux, reg.dias, D.ahora());
      }
    });
    D.bitacora(usuario, `Importó nómina desde Excel (${res.filter((r) => r.accion === 'ok').length} filas)`, 'importacion', null, null);
  }
  return res;
}

// ---------------------------------------------------------------- registros de la ficha

function agregarSalario(usuario, trabId, b) {
  const desde = fechaOpcional(b.vigente_desde, 'vigente desde');
  const salario = entero(b.salario);
  if (!desde) falla('Falta desde cuándo rige el salario.');
  if (!salario || salario <= 0) falla('El salario no es válido.');
  if (D.get('SELECT id FROM salarios WHERE trabajador_id = ? AND vigente_desde = ?', trabId, desde)) falla('Ya hay un salario registrado desde esa misma fecha.');
  const r = D.run('INSERT INTO salarios (trabajador_id, vigente_desde, salario, nota, creado) VALUES (?, ?, ?, ?, ?)', trabId, desde, salario, texto(b.nota, 200), D.ahora());
  D.bitacora(usuario, 'Registró cambio de salario', 'trabajador', trabId, { desde, salario });
  return Number(r.lastInsertRowid);
}

function agregarRango(usuario, tabla, trabId, b) {
  const desde = fechaOpcional(b.desde, 'desde');
  const hasta = fechaOpcional(b.hasta, 'hasta');
  if (!desde || !hasta) falla('Faltan las fechas.');
  if (hasta < desde) falla('La fecha final es anterior a la inicial.');
  if (tabla === 'novedades') {
    const tipo = ['licencia_no_remunerada', 'suspension'].includes(b.tipo) ? b.tipo : 'licencia_no_remunerada';
    const r = D.run('INSERT INTO novedades (trabajador_id, tipo, desde, hasta, nota, creado) VALUES (?, ?, ?, ?, ?, ?)', trabId, tipo, desde, hasta, texto(b.nota, 300), D.ahora());
    D.bitacora(usuario, 'Registró días no remunerados', 'trabajador', trabId, { tipo, desde, hasta });
    return Number(r.lastInsertRowid);
  }
  const dias = Number(String(b.dias_habiles || '').replace(',', '.'));
  if (!(dias > 0) || dias > 120) falla('Los días hábiles de vacaciones no son válidos.');
  const pagadas = D.get(`SELECT l.consecutivo FROM conceptos c JOIN liquidaciones l ON l.id = c.liquidacion_id
    WHERE c.trabajador_id = ? AND l.estado = 'vigente' AND c.concepto = 'vacaciones_disfrutadas' AND c.desde <= ? AND c.hasta >= ?`, trabId, hasta, desde);
  if (pagadas) falla(`Esas vacaciones ya están en el comprobante N.º ${pagadas.consecutivo}: no hace falta registrarlas otra vez.`);
  const r = D.run('INSERT INTO vacaciones (trabajador_id, desde, hasta, dias_habiles, nota, creado) VALUES (?, ?, ?, ?, ?, ?)', trabId, desde, hasta, dias, texto(b.nota, 300), D.ahora());
  D.bitacora(usuario, 'Registró vacaciones disfrutadas', 'trabajador', trabId, { desde, hasta, dias });
  return Number(r.lastInsertRowid);
}

function borrarRegistro(usuario, tabla, id) {
  const fila = D.get(`SELECT * FROM ${tabla} WHERE id = ?`, id);
  if (!fila) falla('Ese registro ya no existe.');
  if (tabla === 'salarios' && D.get('SELECT COUNT(*) n FROM salarios WHERE trabajador_id = ?', fila.trabajador_id).n <= 1) falla('Es el único salario del trabajador; edítelo agregando uno nuevo en vez de borrarlo.');
  D.run(`DELETE FROM ${tabla} WHERE id = ?`, id);
  D.bitacora(usuario, `Borró un registro de ${tabla}`, 'trabajador', fila.trabajador_id, fila);
}

// ---------------------------------------------------------------- sistema

let ultimaSenal = Date.now();
function senal() { ultimaSenal = Date.now(); }

function crearAccesoDirecto() {
  const exe = path.join(D.RAIZ, 'Liquidaciones.exe');
  if (!fs.existsSync(exe)) falla('Esta copia no tiene el archivo Liquidaciones.exe (está en modo de desarrollo).');
  const ps = `$s=(New-Object -ComObject WScript.Shell);$d=[Environment]::GetFolderPath('Desktop');$l=$s.CreateShortcut((Join-Path $d 'Liquidaciones.lnk'));$l.TargetPath='${exe.replace(/'/g, "''")}';$l.WorkingDirectory='${D.RAIZ.replace(/'/g, "''")}';$l.IconLocation='${exe.replace(/'/g, "''")},0';$l.Description='Liquidaciones de prestaciones sociales';$l.Save()`;
  return new Promise((ok, mal) => {
    const p = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true });
    p.on('exit', (c) => (c === 0 ? ok() : mal(new ErrorUsuario('No se pudo crear el acceso directo.'))));
    p.on('error', () => mal(new ErrorUsuario('No se pudo crear el acceso directo.')));
  });
}

function info() {
  let tam = 0;
  try { tam = fs.statSync(D.ARCHIVO).size; } catch {}
  let respaldos = [];
  try { respaldos = fs.readdirSync(D.RESPALDOS).filter((f) => f.endsWith('.db')).sort().reverse(); } catch {}
  return {
    version: VERSION, raiz: D.RAIZ, datos: D.DATOS, archivo: D.ARCHIVO, tamano: tam,
    respaldos: respaldos.slice(0, 10), total_respaldos: respaldos.length,
    equipo: os.hostname(), creada: D.get("SELECT valor FROM meta WHERE clave = 'creada'")?.valor,
    conteos: {
      trabajadores: D.get('SELECT COUNT(*) n FROM trabajadores').n,
      activos: D.get('SELECT COUNT(*) n FROM trabajadores WHERE fecha_retiro IS NULL').n,
      liquidaciones: D.get("SELECT COUNT(*) n FROM liquidaciones WHERE estado = 'vigente'").n,
      nomina: D.get('SELECT COUNT(*) n FROM nomina').n,
    },
    ultima: D.get('SELECT consecutivo, fecha, creado_en FROM liquidaciones ORDER BY consecutivo DESC LIMIT 1') || null,
    ultimo_cambio: D.get('SELECT fecha FROM bitacora ORDER BY id DESC LIMIT 1')?.fecha || null,
  };
}

// ---------------------------------------------------------------- HTTP

const TIPOS_MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json' };

// ---------------------------------------------------------------- documentos adjuntos (soportes)
// Van dentro de la base (la copia de respaldo y la mudanza los llevan). Las fotos llegan ya achicadas desde la pantalla.
const MAX_ADJUNTO = 10 * 1024 * 1024;
const TIPOS_ADJUNTO = {
  pdf: 'application/pdf', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif',
  doc: 'application/msword', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xls: 'application/vnd.ms-excel', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', txt: 'text/plain; charset=utf-8',
};
const ENTIDADES_ADJUNTO = { liquidacion: 'liquidaciones', historica: 'historicas', trabajador: 'trabajadores' };
function subirAdjunto(usuario, q, buf) {
  if (!buf.length) falla('El archivo está vacío.');
  if (buf.length > MAX_ADJUNTO) falla('El archivo pesa más de 10 MB. Si es un escaneo, guárdelo con menos calidad o en varias partes.');
  const nombre = (texto(q.nombre, 150) || 'documento').replace(/[\\/:*?"<>|\x00-\x1f]/g, '_');
  const ext = (nombre.match(/\.([a-z0-9]+)$/i)?.[1] || '').toLowerCase();
  const tipo = TIPOS_ADJUNTO[ext] || falla('Solo se pueden adjuntar PDF, fotos (JPG o PNG), Word, Excel o texto.');
  let entidad = null;
  let entidadId = null;
  if (q.entidad) {
    if (!ENTIDADES_ADJUNTO[q.entidad]) falla('No se sabe a qué va ese documento.');
    entidad = q.entidad;
    entidadId = entero(q.id);
    if (!entidadId || !D.get(`SELECT id FROM ${ENTIDADES_ADJUNTO[entidad]} WHERE id = ?`, entidadId)) falla('Ya no existe el registro al que va ese documento.');
  }
  const sha = crypto.createHash('sha256').update(buf).digest('hex');
  const r = D.run('INSERT INTO adjuntos (entidad, entidad_id, nombre, tipo, tamano, sha256, contenido, nota, creado_por, creado_en) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    entidad, entidadId, nombre, tipo, buf.length, sha, buf, texto(q.nota, 300), usuario || null, D.ahora());
  const id = Number(r.lastInsertRowid);
  if (entidad) D.bitacora(usuario, `Adjuntó el documento "${nombre}"`, entidad, entidadId, { adjunto: id, sha256: sha, tamano: buf.length });
  return { id, nombre, tipo, tamano: buf.length, sha256: sha };
}
function borrarAdjunto(usuario, id) {
  const a = D.get('SELECT id, entidad, entidad_id, nombre FROM adjuntos WHERE id = ?', id);
  if (!a) falla('Ese documento ya no está.');
  if (a.entidad === 'liquidacion') {
    const l = D.get('SELECT datos FROM liquidaciones WHERE id = ?', a.entidad_id);
    const sellados = l ? (JSON.parse(l.datos).adjuntos || []).map((x) => x.id) : [];
    if (sellados.includes(a.id)) falla('Este documento se guardó junto con la liquidación (entra en su código de control): no se puede quitar. Si sobra, corrija la liquidación.');
  }
  D.run('DELETE FROM adjuntos WHERE id = ?', id);
  if (a.entidad) D.bitacora(usuario, `Quitó el documento "${a.nombre}"`, a.entidad, a.entidad_id, null);
}

function leerCuerpo(req, limite) {
  return new Promise((ok, mal) => {
    const partes = [];
    let tam = 0;
    req.on('data', (c) => {
      tam += c.length;
      if (tam > limite) { mal(new ErrorUsuario('El archivo es demasiado grande.')); req.destroy(); return; }
      partes.push(c);
    });
    req.on('end', () => ok(Buffer.concat(partes)));
    req.on('error', mal);
  });
}

function enviar(res, codigo, obj) {
  const cuerpo = JSON.stringify(obj);
  res.writeHead(codigo, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(cuerpo);
}

const rutas = [];
const ruta = (metodo, patron, fn) => rutas.push({ metodo, re: new RegExp('^' + patron.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), fn });

ruta('GET', '/api/ping', () => ({ app: 'liquidaciones', version: VERSION, raiz: D.RAIZ, datos: D.DATOS }));
ruta('POST', '/api/senal', () => ({ ok: true }));
ruta('POST', '/api/adios', () => { ultimaSenal = Date.now() - AUTOAPAGADO_MS + 45000; return { ok: true }; });
ruta('POST', '/api/cerrar', ({ usuario }) => { D.bitacora(usuario, 'Cerró el programa', null, null, null); setTimeout(() => { D.cerrar(); process.exit(0); }, 300); return { ok: true }; });
ruta('POST', '/api/apagar', () => { setTimeout(() => { D.cerrar(); process.exit(0); }, 200); return { ok: true }; });
ruta('GET', '/api/info', () => info());

ruta('GET', '/api/empresa', () => D.get('SELECT * FROM empresa WHERE id = 1') || {});
ruta('PUT', '/api/empresa', ({ body, usuario }) => {
  const e = {};
  for (const k of ['razon_social', 'nit', 'direccion', 'ciudad', 'telefono', 'representante', 'cargo_representante']) e[k] = texto(body[k], 200);
  if (!e.razon_social) falla('Falta el nombre de la empresa.');
  D.run(`INSERT INTO empresa (id, razon_social, nit, direccion, ciudad, telefono, representante, cargo_representante) VALUES (1, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET razon_social = excluded.razon_social, nit = excluded.nit, direccion = excluded.direccion, ciudad = excluded.ciudad,
         telefono = excluded.telefono, representante = excluded.representante, cargo_representante = excluded.cargo_representante`,
  e.razon_social, e.nit, e.direccion, e.ciudad, e.telefono, e.representante, e.cargo_representante);
  D.bitacora(usuario, 'Actualizó los datos de la empresa', 'empresa', 1, e);
  return { ok: true };
});

ruta('GET', '/api/parametros', () => D.all('SELECT * FROM parametros ORDER BY anio DESC'));
ruta('PUT', '/api/parametros/:anio', ({ params, body, usuario }) => {
  const anio = Number(params.anio);
  const smmlv = entero(body.smmlv);
  const aux = entero(body.auxilio_transporte);
  if (!(anio > 1990 && anio < 2200)) falla('Año no válido.');
  if (!(smmlv > 0) || !(aux >= 0)) falla('Los valores no son válidos.');
  const antes = D.get('SELECT * FROM parametros WHERE anio = ?', anio);
  D.run('INSERT INTO parametros (anio, smmlv, auxilio_transporte, nota) VALUES (?, ?, ?, ?) ON CONFLICT(anio) DO UPDATE SET smmlv = excluded.smmlv, auxilio_transporte = excluded.auxilio_transporte, nota = excluded.nota',
    anio, smmlv, aux, texto(body.nota, 200));
  D.bitacora(usuario, `Cambió salario mínimo / auxilio de ${anio}`, 'parametros', anio, { antes, ahora: { smmlv, aux } });
  return { ok: true };
});

ruta('GET', '/api/usuarios', () => D.all('SELECT * FROM usuarios WHERE activo = 1 ORDER BY nombre'));
ruta('POST', '/api/usuarios', ({ body }) => {
  const nombre = texto(body.nombre, 60);
  if (!nombre) falla('Escriba el nombre.');
  const ya = D.get('SELECT * FROM usuarios WHERE nombre = ?', nombre);
  if (ya) { D.run('UPDATE usuarios SET activo = 1 WHERE id = ?', ya.id); return { id: ya.id }; }
  const r = D.run('INSERT INTO usuarios (nombre, creado) VALUES (?, ?)', nombre, D.ahora());
  D.bitacora(nombre, 'Se agregó como usuario', 'usuario', Number(r.lastInsertRowid), null);
  return { id: Number(r.lastInsertRowid) };
});
ruta('DELETE', '/api/usuarios/:id', ({ params, usuario }) => {
  D.run('UPDATE usuarios SET activo = 0 WHERE id = ?', Number(params.id));
  D.bitacora(usuario, 'Quitó un usuario de la lista', 'usuario', Number(params.id), null);
  return { ok: true };
});

ruta('GET', '/api/sedes', () => D.all("SELECT DISTINCT sede FROM trabajadores WHERE sede IS NOT NULL AND sede <> '' ORDER BY sede").map((x) => x.sede));
ruta('GET', '/api/trabajadores', ({ query }) => listaTrabajadores(query));
ruta('POST', '/api/trabajadores', ({ body, usuario }) => ({ id: crearTrabajador(usuario, body) }));
ruta('GET', '/api/trabajadores/:id', ({ params }) => fichaTrabajador(Number(params.id)));
// Volver a contratar a alguien que se retiró: contrato nuevo con la misma cédula; el anterior queda con su historia.
function reingresar(usuario, id, b) {
  const viejo = D.get('SELECT * FROM trabajadores WHERE id = ?', id);
  if (!viejo) falla('No existe ese trabajador.');
  if (!viejo.fecha_retiro) falla('Este trabajador está activo: no hace falta volver a contratarlo.');
  const ingreso = fechaOpcional(b.fecha_ingreso, 'ingreso');
  if (!ingreso) falla('Falta la fecha en que vuelve a entrar.');
  if (ingreso <= viejo.fecha_retiro) falla(`La fecha de ingreso tiene que ser después de su retiro (${F.larga(viejo.fecha_retiro)}).`);
  const datos = {};
  for (const k of ['tipo_documento', 'documento', 'nombres', 'apellidos', 'cargo', 'sede', 'telefono', 'correo', 'tipo_salario', 'auxilio_transporte', 'fondo_cesantias']) datos[k] = viejo[k];
  const nuevo = crearTrabajador(usuario, { ...datos, fecha_ingreso: ingreso, salario: b.salario, salario_minimo: b.salario_minimo, salario_desde: ingreso, notas: `Volvió a trabajar. Contrato anterior: del ${viejo.fecha_ingreso} al ${viejo.fecha_retiro}.` }, { reingresoDe: viejo.id });
  D.bitacora(usuario, 'Volvió a contratar (contrato nuevo con la misma cédula)', 'trabajador', nuevo, { anterior: viejo.id, ingreso });
  return nuevo;
}

// Certificado laboral (Art. 57 num. 7 CST): tiempo de servicio, labor y salario.
ruta('GET', '/api/trabajadores/:id/certificado', ({ params }) => {
  const ctx = contexto(Number(params.id));
  const t = ctx.trab;
  const fecha = t.fecha_retiro || F.hoy();
  const salario = C.salarioEn(ctx, fecha);
  return {
    trabajador: { ...t, nombre: nombreCompleto(t) }, empresa: D.get('SELECT * FROM empresa WHERE id = 1') || {},
    salario, salario_letras: pesosEnLetras(salario), hoy: F.hoy(), hoy_largo: F.larga(F.hoy()),
    ingreso_largo: F.larga(t.fecha_ingreso), retiro_largo: t.fecha_retiro ? F.larga(t.fecha_retiro) : null,
  };
});
// Alguien que ya no trabaja aquí y al que se le liquidó POR FUERA del programa: solo se marca como retirado.
// (Si no se le ha liquidado, lo correcto es hacerle la liquidación definitiva en el programa.)
function marcarRetiro(usuario, id, b) {
  const t = D.get('SELECT * FROM trabajadores WHERE id = ?', id);
  if (!t) falla('No existe ese trabajador.');
  if (t.fecha_retiro) falla(`Ya figura retirado desde el ${F.larga(t.fecha_retiro)}.`);
  const fecha = fechaOpcional(b.fecha_retiro, 'retiro');
  if (!fecha) falla('Falta la fecha en que se retiró (su último día de trabajo).');
  if (fecha < t.fecha_ingreso) falla(`La fecha de retiro no puede ser antes de su ingreso (${F.larga(t.fecha_ingreso)}).`);
  if (fecha > F.hoy()) falla('La fecha de retiro no puede ser en el futuro. Márquelo cuando ya se haya ido.');
  const motivo = C.MOTIVOS_RETIRO[b.motivo_retiro] ? b.motivo_retiro : falla('Escoja el motivo del retiro.');
  // Liquidaciones del programa que pagaron tiempo después del retiro (p. ej. "Liquidar a todos" lo incluyó):
  // quien sabe si eso se le pagó o no es quien lo retira.
  const despues = liquidacionesDespuesDe(id, fecha);
  if (despues.length && !['anular', 'dejar'].includes(b.despues)) {
    falla(`${despues.map((l) => `La N.º ${l.consecutivo} le liquidó hasta el ${F.larga(F.finLaboral(l.hasta))}`).join('; ')}, después de esa fecha de retiro. Diga si eso se le pagó o no.`);
  }
  const nota = texto(b.nota, 300);
  const sobre = despues.length ? ` ${despues.map((l) => `N.º ${l.consecutivo}`).join(', ')} (${b.despues === 'anular' ? 'no se le pagó: se anuló' : 'ya se le había pagado: se dejó así'}).` : '';
  const notas = [t.notas, `Retirado el ${fecha} sin liquidación en el programa (se le liquidó por fuera)${nota ? ': ' + nota : ''}.${sobre}`].filter(Boolean).join('\n');
  D.tx(() => {
    if (b.despues === 'anular') {
      for (const l of despues) {
        const completa = D.get('SELECT * FROM liquidaciones WHERE id = ?', l.id);
        validarAnulable(completa);
        marcarAnulada(usuario, completa, `Se retiró el ${F.larga(fecha)}: esta liquidación cubría tiempo después y no se le pagó.`);
      }
    }
    D.run('UPDATE trabajadores SET fecha_retiro = ?, motivo_retiro = ?, notas = ?, actualizado = ? WHERE id = ?', fecha, motivo, notas, D.ahora(), id);
    D.bitacora(usuario, 'Lo marcó como retirado (se le liquidó por fuera del programa)', 'trabajador', id, { fecha_retiro: fecha, motivo, nota, despues: despues.map((l) => l.consecutivo), que_se_hizo: despues.length ? b.despues : null });
  });
}

function liquidacionesDespuesDe(id, fecha) {
  return D.all(`SELECT l.id, l.consecutivo, l.tipo, MAX(c.hasta) hasta, GROUP_CONCAT(DISTINCT c.concepto) conceptos FROM conceptos c JOIN liquidaciones l ON l.id = c.liquidacion_id
    WHERE c.trabajador_id = ? AND l.estado = 'vigente' AND c.hasta IS NOT NULL AND c.hasta > ? AND c.concepto IN ('cesantias', 'prima')
    GROUP BY l.id ORDER BY l.consecutivo`, id, F.finComercial(fecha));
}

function deshacerRetiro(usuario, id) {
  const t = D.get('SELECT * FROM trabajadores WHERE id = ?', id);
  if (!t) falla('No existe ese trabajador.');
  if (!t.fecha_retiro) falla('No figura retirado.');
  const def = D.get("SELECT consecutivo FROM liquidaciones WHERE trabajador_id = ? AND estado = 'vigente' AND tipo = 'definitiva'", id);
  if (def) falla(`Se retiró con la liquidación definitiva N.º ${def.consecutivo}: para deshacerlo, anule esa liquidación.`);
  const otro = D.get('SELECT id FROM trabajadores WHERE documento = ? AND id <> ? AND fecha_retiro IS NULL', t.documento, id);
  if (otro) falla('Esta persona ya volvió a trabajar con otro contrato: no se puede deshacer el retiro de este.');
  D.tx(() => {
    D.run('UPDATE trabajadores SET fecha_retiro = NULL, motivo_retiro = NULL, actualizado = ? WHERE id = ?', D.ahora(), id);
    D.bitacora(usuario, 'Deshizo el retiro (vuelve a quedar activo)', 'trabajador', id, { fecha_retiro: t.fecha_retiro, motivo: t.motivo_retiro });
  });
}

// Borrar de verdad: solo para alguien que se cargó por error y no tiene liquidaciones en el programa.
// Los pagos de antes del programa (Excel) van por cédula y no se borran.
function borrarTrabajador(usuario, id) {
  const t = D.get('SELECT * FROM trabajadores WHERE id = ?', id);
  if (!t) falla('No existe ese trabajador.');
  const liq = D.get('SELECT COUNT(*) n FROM liquidaciones WHERE trabajador_id = ?', id).n;
  if (liq) falla(`Tiene ${liq} ${liq === 1 ? 'liquidación' : 'liquidaciones'} en el programa: no se puede borrar (las liquidaciones son el historial legal). Si ya no trabaja aquí, use "Eliminar" → "Ya no trabaja aquí…".`);
  const copia = { ...t, salarios: D.all('SELECT * FROM salarios WHERE trabajador_id = ?', id), novedades: D.all('SELECT * FROM novedades WHERE trabajador_id = ?', id), vacaciones: D.all('SELECT * FROM vacaciones WHERE trabajador_id = ?', id), filas_nomina: D.get('SELECT COUNT(*) n FROM nomina WHERE trabajador_id = ?', id).n };
  D.tx(() => {
    for (const tabla of ['nomina', 'salarios', 'novedades', 'vacaciones']) D.run(`DELETE FROM ${tabla} WHERE trabajador_id = ?`, id);
    D.run('UPDATE trabajadores SET reingreso_de = NULL WHERE reingreso_de = ?', id);
    D.run('DELETE FROM trabajadores WHERE id = ?', id);
    D.bitacora(usuario, `Borró al trabajador ${nombreCompleto(t)} (${t.documento})`, 'trabajador', id, copia);
  });
}

ruta('POST', '/api/trabajadores/:id/retiro', ({ params, body, usuario }) => { marcarRetiro(usuario, Number(params.id), body); return { ok: true }; });
ruta('GET', '/api/trabajadores/:id/retiro-revisar', ({ params, query }) => {
  const f = F.valida(query.fecha) ? query.fecha : null;
  return { despues: f ? liquidacionesDespuesDe(Number(params.id), f).map((l) => ({ ...l, hasta_txt: F.larga(F.finLaboral(l.hasta)) })) : [] };
});
ruta('POST', '/api/trabajadores/:id/deshacer-retiro', ({ params, usuario }) => { deshacerRetiro(usuario, Number(params.id)); return { ok: true }; });
ruta('DELETE', '/api/trabajadores/:id', ({ params, usuario }) => { borrarTrabajador(usuario, Number(params.id)); return { ok: true }; });
ruta('POST', '/api/trabajadores/:id/reingreso', ({ params, body, usuario }) => ({ id: reingresar(usuario, Number(params.id), body) }));
ruta('PUT', '/api/trabajadores/:id', ({ params, body, usuario }) => { editarTrabajador(usuario, Number(params.id), body); return { ok: true }; });
ruta('POST', '/api/trabajadores/:id/salarios', ({ params, body, usuario }) => ({ id: agregarSalario(usuario, Number(params.id), body) }));
ruta('POST', '/api/trabajadores/:id/novedades', ({ params, body, usuario }) => ({ id: agregarRango(usuario, 'novedades', Number(params.id), body) }));
ruta('POST', '/api/trabajadores/:id/vacaciones', ({ params, body, usuario }) => ({ id: agregarRango(usuario, 'vacaciones', Number(params.id), body) }));
ruta('DELETE', '/api/salarios/:id', ({ params, usuario }) => { borrarRegistro(usuario, 'salarios', Number(params.id)); return { ok: true }; });
ruta('DELETE', '/api/novedades/:id', ({ params, usuario }) => { borrarRegistro(usuario, 'novedades', Number(params.id)); return { ok: true }; });
ruta('DELETE', '/api/vacaciones/:id', ({ params, usuario }) => { borrarRegistro(usuario, 'vacaciones', Number(params.id)); return { ok: true }; });

ruta('POST', '/api/calcular', ({ body }) => calcular(body));
ruta('POST', '/api/liquidaciones', ({ body, usuario }) => D.tx(() => guardarLiquidacion(usuario, body)));
ruta('GET', '/api/liquidaciones', ({ query }) => historial(query));
ruta('GET', '/api/liquidaciones/:id', ({ params }) => verLiquidacion(Number(params.id)));
ruta('POST', '/api/liquidaciones/:id/anular', ({ params, body, usuario }) => { anular(usuario, Number(params.id), body.motivo); return { ok: true }; });
ruta('POST', '/api/masiva/calcular', ({ body }) => masivaCalcular(body));
ruta('POST', '/api/masiva/guardar', ({ body, usuario }) => masivaGuardar(usuario, body));
ruta('GET', '/api/pendientes', () => pendientes());

ruta('POST', '/api/importar/trabajadores', ({ body, usuario }) => importarTrabajadores(usuario, body.filas, !!body.guardar));
ruta('POST', '/api/importar/historicas', ({ body, usuario }) => importarHistoricas(usuario, body));
ruta('GET', '/api/historicas', ({ query }) => listaHistoricas(query));
ruta('GET', '/api/adjuntos', ({ query }) => {
  if (!ENTIDADES_ADJUNTO[query.entidad]) falla('No se sabe de qué registro.');
  return D.all('SELECT id, nombre, tipo, tamano, sha256, nota, creado_por, creado_en FROM adjuntos WHERE entidad = ? AND entidad_id = ? ORDER BY id', query.entidad, Number(query.id) || 0);
});
ruta('PUT', '/api/historicas/:id', ({ params, body, usuario }) => { editarHistorica(usuario, Number(params.id), body); return { ok: true }; });
ruta('DELETE', '/api/historicas/:id', ({ params, usuario }) => {
  const h = D.get('SELECT * FROM historicas WHERE id = ?', Number(params.id));
  if (!h) falla('Ese registro ya no existe.');
  D.run("DELETE FROM adjuntos WHERE entidad = 'historica' AND entidad_id = ?", h.id);
  D.run('DELETE FROM historicas WHERE id = ?', h.id);
  D.bitacora(usuario, 'Borró un pago de antes del programa', 'historica', h.id, h);
  return { ok: true };
});
ruta('POST', '/api/importar/nomina', ({ body, usuario }) => importarNomina(usuario, body.filas, !!body.guardar));

ruta('GET', '/api/bitacora', ({ query }) => {
  const lim = Math.min(Number(query.limite) || 300, 2000);
  if (query.trabajador_id) return D.all("SELECT * FROM bitacora WHERE (entidad = 'trabajador' AND entidad_id = ?) OR (entidad = 'liquidacion' AND entidad_id IN (SELECT id FROM liquidaciones WHERE trabajador_id = ?)) ORDER BY id DESC LIMIT ?", Number(query.trabajador_id), Number(query.trabajador_id), lim);
  return D.all('SELECT * FROM bitacora ORDER BY id DESC LIMIT ?', lim);
});

// Actualizaciones a distancia (solo cambia el programa; los datos se quedan)
ruta('GET', '/api/actualizacion', async () => ({ ...(await ACT.buscar()), auto: autoActiva() }));
ruta('GET', '/api/auto-actualizacion', () => ({ ...AUTO, activa: autoActiva(), instalada: ACT.instalada(), version: VERSION }));
ruta('PUT', '/api/auto-actualizacion', ({ body, usuario }) => {
  const activa = body.activa ? '1' : '0';
  D.run("INSERT INTO meta (clave, valor) VALUES ('actualizar_solo', ?) ON CONFLICT(clave) DO UPDATE SET valor = excluded.valor", activa);
  D.bitacora(usuario, activa === '1' ? 'Prendió la actualización automática' : 'Apagó la actualización automática', null, null, null);
  return { ok: true, activa: activa === '1' };
});
ruta('POST', '/api/actualizar', async ({ usuario }) => {
  const r = await ACT.aplicar(usuario);
  setTimeout(() => ACT.reiniciar(), 700);
  return r;
});

ruta('POST', '/api/abrir-carpeta', () => {
  spawn('explorer.exe', [D.DATOS], { detached: true, stdio: 'ignore' }).unref();
  return { ok: true };
});
ruta('POST', '/api/acceso-directo', async ({ usuario }) => { await crearAccesoDirecto(); D.bitacora(usuario, 'Creó el acceso directo en el escritorio', null, null, null); return { ok: true }; });

const NO_ES_TRABAJO = ['/api/senal', '/api/adios', '/api/usuarios', '/api/actualizar', '/api/auto-actualizacion', '/api/calcular', '/api/masiva/calcular'];
async function manejarApi(req, res, url) {
  const usuario = req.headers['x-usuario'] ? decodeURIComponent(String(req.headers['x-usuario'])).slice(0, 60) : null;
  if (req.method !== 'GET' && !NO_ES_TRABAJO.includes(url.pathname)) trabajoDesdeArranque = true;
  if (url.pathname === '/api/respaldo' && req.method === 'GET') {
    const marca = D.ahora().replace(/[: ]/g, '-');
    const destino = path.join(D.RESPALDOS, `manual-${marca}.db`);
    D.respaldarEn(destino);
    D.bitacora(usuario, 'Descargó una copia de respaldo', null, null, null);
    res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Disposition': `attachment; filename="respaldo-liquidaciones-${marca.slice(0, 10)}.db"` });
    fs.createReadStream(destino).pipe(res);
    return;
  }
  if (url.pathname === '/api/restaurar' && req.method === 'POST') {
    const buf = await leerCuerpo(req, 500 * 1024 * 1024);
    const tmp = path.join(os.tmpdir(), `liq-restaurar-${Date.now()}.db`);
    fs.writeFileSync(tmp, buf);
    try {
      if (!D.esBaseValida(tmp)) falla('Ese archivo no es una copia de este programa.');
      const marca = D.ahora().replace(/[: ]/g, '-');
      D.respaldarEn(path.join(D.RESPALDOS, `antes-de-restaurar-${marca}.db`));
      D.reemplazarCon(tmp);
      // Quien restaura en un computador nuevo sigue apareciendo en la lista de usuarios de la copia.
      if (usuario && usuario !== 'Sin nombre') {
        try {
          const ya = D.get('SELECT id FROM usuarios WHERE nombre = ?', usuario);
          if (ya) D.run('UPDATE usuarios SET activo = 1 WHERE id = ?', ya.id);
          else D.run('INSERT INTO usuarios (nombre, creado) VALUES (?, ?)', usuario, D.ahora());
        } catch {}
      }
      D.bitacora(usuario, 'Restauró los datos desde una copia de respaldo', null, null, null);
    } finally {
      try { fs.unlinkSync(tmp); } catch {}
    }
    return enviar(res, 200, { ok: true });
  }
  if (url.pathname === '/api/adjuntos' && req.method === 'POST') {
    const buf = await leerCuerpo(req, MAX_ADJUNTO + 1024);
    return enviar(res, 200, subirAdjunto(usuario, Object.fromEntries(url.searchParams), buf));
  }
  const mAdj = url.pathname.match(/^\/api\/adjuntos\/(\d+)$/);
  if (mAdj && req.method === 'GET') {
    const a = D.get('SELECT nombre, tipo, contenido FROM adjuntos WHERE id = ?', Number(mAdj[1]));
    if (!a) falla('Ese documento ya no está.');
    const buf = Buffer.from(a.contenido);
    res.writeHead(200, { 'Content-Type': a.tipo || 'application/octet-stream', 'Content-Length': buf.length, 'Content-Disposition': `inline; filename*=UTF-8''${encodeURIComponent(a.nombre)}`, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
    res.end(buf);
    return;
  }
  if (mAdj && req.method === 'DELETE') {
    borrarAdjunto(usuario, Number(mAdj[1]));
    return enviar(res, 200, { ok: true });
  }
  const r = rutas.find((x) => x.metodo === req.method && x.re.test(url.pathname));
  if (!r) return enviar(res, 404, { error: 'No encontrado' });
  const params = url.pathname.match(r.re).groups || {};
  let body = {};
  if (req.method === 'POST' || req.method === 'PUT') {
    const buf = await leerCuerpo(req, 50 * 1024 * 1024);
    if (buf.length) {
      try { body = JSON.parse(buf.toString('utf8')); } catch { falla('Datos mal formados.'); }
    }
  }
  const query = Object.fromEntries(url.searchParams);
  const out = await r.fn({ params, body, query, usuario });
  enviar(res, 200, out ?? { ok: true });
}

const servidor = http.createServer(async (req, res) => {
  try {
    // Solo este computador; protege contra páginas web que intenten hablarle al programa.
    const host = String(req.headers.host || '');
    if (!/^(127\.0\.0\.1|localhost)(:\d+)?$/.test(host)) { res.writeHead(403); res.end(); return; }
    const url = new URL(req.url, 'http://127.0.0.1');
    if (url.pathname.startsWith('/api/')) {
      senal();
      if (url.pathname !== '/api/ping' && url.pathname !== '/api/adios' && req.headers['x-liq'] !== '1') { res.writeHead(403); res.end(); return; }
      await manejarApi(req, res, url);
      return;
    }
    let rel = decodeURIComponent(url.pathname);
    if (rel === '/' || !path.extname(rel)) rel = '/index.html';
    const archivo = path.normalize(path.join(PUBLICO, rel));
    if (!archivo.startsWith(PUBLICO) || !fs.existsSync(archivo)) { res.writeHead(404); res.end('No encontrado'); return; }
    res.writeHead(200, { 'Content-Type': TIPOS_MIME[path.extname(archivo)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    fs.createReadStream(archivo).pipe(res);
  } catch (e) {
    if (!res.headersSent) {
      if (e instanceof ErrorUsuario) enviar(res, 400, { error: e.message });
      else {
        console.error(e);
        const msg = /UNIQUE constraint/.test(e.message) ? 'Ese registro ya existe.' : 'Ocurrió un error inesperado: ' + e.message;
        enviar(res, 500, { error: msg });
      }
    }
  }
});

// Después de una actualización, el programa nuevo espera a que el viejo suelte el puerto.
let intentosPuerto = 0;
servidor.on('error', (e) => {
  if (e.code === 'EADDRINUSE' && process.env.LIQ_ESPERAR_PUERTO && intentosPuerto++ < 80) { setTimeout(() => servidor.listen(PUERTO, '127.0.0.1'), 250); return; }
  console.error('No se pudo abrir el puerto', PUERTO, e.message);
  process.exit(2);
});
servidor.listen(PUERTO, '127.0.0.1', () => {
  console.log(`Liquidaciones ${VERSION} en http://127.0.0.1:${PUERTO}/  ·  datos: ${D.DATOS}`);
});

// ---------------------------------------------------------------- actualización automática
// Sin que nadie tenga que darle "Actualizar": (1) al ABRIR el programa, antes de que se empiece a trabajar (la pantalla
// muestra "Actualizando…" unos segundos y vuelve sola); (2) al CERRAR la ventana, si salió una versión mientras estaba abierto.
// Nunca en medio del trabajo: si al abrir ya se guardó algo, espera al cierre. Siempre guarda antes una copia de los datos.
const AUTO = { estado: 'nada', nueva: null, error: null, revisado: null };
let trabajoDesdeArranque = false;
function autoActiva() {
  return (D.get("SELECT valor FROM meta WHERE clave = 'actualizar_solo'")?.valor ?? '1') === '1';
}
async function autoRevisar(momento) {
  if (!ACT.instalada()) { AUTO.estado = 'no_instalada'; return false; }
  if (!autoActiva()) { AUTO.estado = 'apagada'; return false; }
  if (AUTO.estado === 'buscando' || AUTO.estado === 'aplicando') return false;
  AUTO.estado = 'buscando';
  try {
    const b = await ACT.buscar();
    AUTO.revisado = D.ahora();
    if (!b.hay) { AUTO.estado = 'al_dia'; return false; }
    AUTO.nueva = b.nueva;
    // Si al abrir ya alguien guardó algo, o es la revisión de mientras está abierto, se deja para el cierre.
    if (momento === 'abierto' || (momento === 'arranque' && trabajoDesdeArranque)) { AUTO.estado = 'pendiente'; return false; }
    // Freno: si ya se intentó esta misma versión hace poco y no quedó, no se insiste (no queda dando vueltas).
    const previo = D.get("SELECT valor FROM meta WHERE clave = 'auto_ultimo_intento'")?.valor || '';
    const [vPrev, tPrev] = previo.split('|');
    if (vPrev === b.nueva && Date.now() - Number(tPrev || 0) < 6 * 3600 * 1000) { AUTO.estado = 'pendiente'; AUTO.error = 'Ya se intentó hace poco; se vuelve a intentar más tarde.'; return false; }
    D.run("INSERT INTO meta (clave, valor) VALUES ('auto_ultimo_intento', ?) ON CONFLICT(clave) DO UPDATE SET valor = excluded.valor", `${b.nueva}|${Date.now()}`);
    AUTO.estado = 'aplicando';
    await ACT.aplicar(AUTOMATICA);
    AUTO.estado = 'lista';
    return true;
  } catch (e) {
    AUTO.estado = 'error';
    AUTO.error = e.message;
    console.error('Actualización automática:', e.message);
    return false;
  }
}
if (!process.env.LIQ_SIN_AUTOACTUALIZAR) {
  // Al abrir: un momento después de arrancar (sin internet, simplemente no pasa nada).
  setTimeout(() => { autoRevisar('arranque').then((ok) => { if (ok) setTimeout(() => ACT.reiniciar(), 1500); }); }, 1500);
  // Mientras está abierto, cada 4 horas se mira si hay algo nuevo (se instala al cerrar).
  setInterval(() => { if (AUTO.estado !== 'pendiente') autoRevisar('abierto'); }, 4 * 3600 * 1000).unref();
}

// Se apaga solo cuando nadie lo está usando (la ventana se cerró). Antes, si hay versión nueva, se actualiza.
let cerrando = false;
if (!process.env.LIQ_SIN_AUTOAPAGADO) {
  setInterval(() => {
    if (cerrando || Date.now() - ultimaSenal <= AUTOAPAGADO_MS) return;
    cerrando = true;
    const salir = () => { try { D.cerrar(); } catch {} process.exit(0); };
    if (process.env.LIQ_SIN_AUTOACTUALIZAR || AUTO.estado === 'error') { salir(); return; }
    const limite = setTimeout(salir, 4 * 60 * 1000);
    autoRevisar('cierre').then((ok) => {
      clearTimeout(limite);
      // Si alguien volvió a abrir la ventana mientras tanto, arranca la versión nueva en vez de apagarse.
      if (ok && Date.now() - ultimaSenal <= AUTOAPAGADO_MS) ACT.reiniciar();
      else if (!ok && Date.now() - ultimaSenal <= AUTOAPAGADO_MS) cerrando = false;
      else salir();
    }, salir);
  }, 10000).unref();
}
for (const s of ['SIGINT', 'SIGTERM']) process.on(s, () => { D.cerrar(); process.exit(0); });
