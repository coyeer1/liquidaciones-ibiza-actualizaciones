// Actualizaciones a distancia. El programa pregunta si hay una versión nueva, la baja, comprueba que la firmó
// quien la hizo (llave pública de abajo) y que llegó entera, y cambia SOLO la carpeta "app". Los datos no salen
// del computador ni se tocan (antes se guarda una copia por si acaso).
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFileSync, spawn } = require('child_process');

// Dónde se publican las versiones nuevas. Una versión firmada puede cambiarla (campo "url_nueva").
const URL_POR_DEFECTO = 'https://raw.githubusercontent.com/coyeer1/liquidaciones-ibiza-actualizaciones/main/version.json';
// Solo las versiones firmadas con la llave privada que corresponde a esta pública se instalan.
const LLAVE_PUBLICA = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAlFSqka2KaOf2AJUMUOGdViw5Z0HEJq8LgOBbpm47vbg=
-----END PUBLIC KEY-----`;

// Texto exacto que se firma (el publicador arma el mismo).
function textoFirmado(m) {
  return ['liquidaciones', m.version, m.archivo, m.sha256, m.fecha, JSON.stringify(m.notas || []), m.url_nueva || ''].join('|');
}

function compararVersiones(a, b) {
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
  return 0;
}

const AUTOMATICA = 'Actualización automática';

function crear({ D, VERSION, falla }) {
  const urlManifiesto = () => process.env.LIQ_URL_ACTUALIZACIONES || D.get("SELECT valor FROM meta WHERE clave = 'url_actualizaciones'")?.valor || URL_POR_DEFECTO;
  // Solo se actualiza la copia INSTALADA (la que tiene Liquidaciones.exe), nunca la carpeta de trabajo del programador.
  const instalada = () => fs.existsSync(path.join(D.RAIZ, 'Liquidaciones.exe')) && fs.existsSync(path.join(D.RAIZ, 'runtime', 'node.exe'));

  async function bajar(url, ms) {
    let r;
    try { r = await fetch(url, { signal: AbortSignal.timeout(ms), headers: { 'Cache-Control': 'no-cache' } }); }
    catch { falla('No hay conexión a internet (o la página de actualizaciones no responde). Intente más tarde.'); }
    if (!r.ok) falla(`La página de actualizaciones respondió con un error (${r.status}). Intente más tarde.`);
    return Buffer.from(await r.arrayBuffer());
  }

  async function manifiesto() {
    const url = urlManifiesto();
    const crudo = await bajar(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), 12000);
    let m;
    try { m = JSON.parse(crudo.toString('utf8')); } catch { falla('La información de la versión nueva llegó dañada.'); }
    if (!m || !m.version || !m.archivo || !m.sha256 || !m.firma) falla('La información de la versión nueva está incompleta.');
    let valida = false;
    try { valida = crypto.verify(null, Buffer.from(textoFirmado(m)), LLAVE_PUBLICA, Buffer.from(m.firma, 'base64')); } catch {}
    if (!valida) falla('La versión publicada no tiene una firma válida: no se instala.');
    return { ...m, url };
  }

  async function buscar() {
    const m = await manifiesto();
    return { actual: VERSION, nueva: m.version, hay: compararVersiones(m.version, VERSION) > 0, notas: m.notas || [], fecha: m.fecha, instalada: instalada() };
  }

  async function aplicar(usuario) {
    if (!instalada()) falla('Esta copia del programa no está instalada (es la de pruebas): no se actualiza sola.');
    const m = await manifiesto();
    if (compararVersiones(m.version, VERSION) <= 0) falla(`Ya tiene la última versión (${VERSION}).`);
    const zip = await bajar(new URL(m.archivo, m.url).toString(), 120000);
    if (crypto.createHash('sha256').update(zip).digest('hex') !== m.sha256) falla('La descarga llegó incompleta o dañada. Intente de nuevo.');

    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'liq-actualizacion-'));
    const archivoZip = path.join(tmp, 'app.zip');
    const destino = path.join(tmp, 'nuevo');
    fs.writeFileSync(archivoZip, zip);
    const q = (s) => s.replace(/'/g, "''");
    execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command',
      `Add-Type -A System.IO.Compression.FileSystem; [IO.Compression.ZipFile]::ExtractToDirectory('${q(archivoZip)}', '${q(destino)}')`], { windowsHide: true, timeout: 120000 });
    const nuevaApp = path.join(destino, 'app');
    for (const f of ['server.js', 'calc.js', 'db.js', 'fechas.js', path.join('public', 'index.html')]) {
      if (!fs.existsSync(path.join(nuevaApp, f))) falla('A la versión nueva le falta un archivo: no se instala.');
    }
    // Prueba rápida: que el código nuevo se pueda leer y que el motor de cálculo cargue
    try {
      execFileSync(process.execPath, ['--check', path.join(nuevaApp, 'server.js')], { windowsHide: true, timeout: 30000 });
      execFileSync(process.execPath, ['-e', `require(${JSON.stringify(path.join(nuevaApp, 'calc.js'))})`], { windowsHide: true, timeout: 30000 });
    } catch { falla('La versión nueva no pasó la revisión: no se instala. El programa sigue como estaba.'); }

    // La versión nueva se deja lista al lado (misma unidad) para que el cambio sea de un instante:
    // si el computador se apaga justo en ese momento, el programa no queda a medias.
    const APP = path.join(D.RAIZ, 'app');
    const ANTERIOR = path.join(D.RAIZ, 'app-anterior');
    const NUEVA = path.join(D.RAIZ, 'app-nueva');
    fs.rmSync(NUEVA, { recursive: true, force: true });
    fs.cpSync(nuevaApp, NUEVA, { recursive: true });
    // Copia de los datos antes de cambiar nada
    D.respaldarEn(path.join(D.RESPALDOS, `antes-de-actualizar-a-${m.version}.db`));
    fs.rmSync(ANTERIOR, { recursive: true, force: true });
    let cambiado = false;
    let forma = 'renombrar';
    try {
      fs.renameSync(APP, ANTERIOR);
      try { fs.renameSync(NUEVA, APP); cambiado = true; } catch (e) { fs.renameSync(ANTERIOR, APP); throw e; }
    } catch {
      // Si Windows no deja renombrar la carpeta (algo la tiene abierta), se copia archivo por archivo como antes.
      try {
        forma = 'copiar';
        if (!fs.existsSync(ANTERIOR)) fs.cpSync(APP, ANTERIOR, { recursive: true });
        for (const f of fs.readdirSync(APP)) fs.rmSync(path.join(APP, f), { recursive: true, force: true });
        fs.cpSync(NUEVA, APP, { recursive: true });
        cambiado = true;
      } catch (e) {
        try { fs.cpSync(ANTERIOR, APP, { recursive: true, force: true }); } catch {}
        falla('No se pudo cambiar el programa (' + e.message + '). Quedó como estaba.');
      }
    } finally {
      try { fs.rmSync(NUEVA, { recursive: true, force: true }); } catch {}
    }
    if (!cambiado) falla('No se pudo cambiar el programa. Quedó como estaba.');
    if (m.url_nueva) D.run("INSERT INTO meta (clave, valor) VALUES ('url_actualizaciones', ?) ON CONFLICT(clave) DO UPDATE SET valor = excluded.valor", m.url_nueva);
    D.bitacora(usuario, `${usuario === AUTOMATICA ? 'Se actualizó solo' : 'Actualizó el programa'} de la versión ${VERSION} a la ${m.version}`, null, null, { notas: m.notas || [], forma });
    try { fs.rmSync(tmp, { recursive: true, force: true }); } catch {}
    return { ok: true, anterior: VERSION, nueva: m.version };
  }

  // Arranca el programa nuevo en el mismo puerto y cierra este. El nuevo espera a que el puerto quede libre.
  function reiniciar() {
    const hijo = spawn(process.execPath, process.argv.slice(1), {
      cwd: process.cwd(), env: { ...process.env, LIQ_ESPERAR_PUERTO: '1' }, detached: true, stdio: 'ignore', windowsHide: true,
    });
    hijo.unref();
    try { D.cerrar(); } catch {}
    process.exit(0);
  }

  return { buscar, aplicar, reiniciar, instalada, textoFirmado, compararVersiones, urlManifiesto };
}

module.exports = { crear, textoFirmado, compararVersiones, URL_POR_DEFECTO, AUTOMATICA };
