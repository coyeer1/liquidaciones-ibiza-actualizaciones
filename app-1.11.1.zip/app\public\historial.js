import { html, useState } from './vendor/preact-htm.js';
import { api } from './util.js';
import { pesos, fCorta, hoy, ir, qs, TIPOS, etiquetaTipo, descargarExcel, millones } from './util.js';
import { Icono, Cargando, Aviso, Modal, Campo, InputPesos, useDatos, avisar, confirmar } from './comp.js';
import { Adjuntos } from './adjuntos.js';

// Dos historiales: lo hecho con el programa y lo que se pagó antes (los Excel de la empresa).
export function Historial({ query }) {
  const [vista, setVista] = useState(query.antes ? 'antes' : 'programa');
  return html`<div class="pila">
    <div class="segmentado" role="group" aria-label="Cuál historial" style="width:fit-content">
      <button class=${vista === 'programa' ? 'activo' : ''} aria-pressed=${vista === 'programa'} onClick=${() => setVista('programa')}>Hechas en el programa</button>
      <button class=${vista === 'antes' ? 'activo' : ''} aria-pressed=${vista === 'antes'} onClick=${() => setVista('antes')}>Antes del programa (Excel)</button>
    </div>
    ${vista === 'programa' ? html`<${HistorialPrograma} query=${query} />` : html`<${HistorialAntes} />`}
  </div>`;
}

// En cada fila: ver el comprobante o corregirlo (descontar días, cambiar fechas…) sin tener que abrirlo primero.
export function BotonesLiquidacion({ l }) {
  const parar = (ev) => ev.stopPropagation();
  return html`<span class="fila" style="gap:6px;flex-wrap:nowrap;justify-content:flex-end" onClick=${parar} onKeyDown=${parar}>
    <a class="btn chico" href=${'#/liquidacion/' + l.id} aria-label=${'Ver el comprobante N.º ' + l.consecutivo}><${Icono} n="documento" />Ver</a>
    ${l.estado === 'vigente' && html`<a class="btn chico" href=${'#/liquidar?corrige=' + l.id} aria-label=${'Corregir la N.º ' + l.consecutivo} title="Descontar días, cambiar fechas o lo que haya quedado mal"><${Icono} n="lapiz" />Corregir</a>`}
  </span>`;
}

const QUE_ANTES = { prima: 'Prima', cesantias: 'Cesantías e intereses', vacaciones: 'Vacaciones', otro: 'Otro pago' };

// Cambiar un pago de antes del programa (p. ej. se le descontaron días) y adjuntar el soporte.
// Es historia de lo que se pagó: no cambia ningún cálculo, pero queda el motivo y lo que había antes.
export function EditarHistorica({ h, onCerrar, onListo }) {
  const [f, setF] = useState({ dias: h.dias != null ? String(h.dias).replace('.', ',') : '', valor: h.valor, intereses: h.intereses ?? null, motivo: '' });
  const adj = useDatos(`/api/adjuntos?entidad=historica&id=${h.id}`);
  const [cambioDoc, setCambioDoc] = useState(false);
  const diasNum = Number(String(f.dias).replace(',', '.'));
  const puedeRecalcular = h.dias > 0 && f.dias !== '' && Number.isFinite(diasNum) && diasNum !== h.dias;
  const cambio = String(f.dias).replace(',', '.') !== String(h.dias ?? '') || f.valor !== h.valor || (f.intereses ?? null) !== (h.intereses ?? null);
  const salir = () => (cambioDoc ? onListo() : onCerrar());
  const guardar = async () => {
    try {
      await api('/api/historicas/' + h.id, { metodo: 'PUT', cuerpo: { dias: String(f.dias).replace(',', '.'), valor: f.valor, intereses: f.intereses, motivo: f.motivo } });
      avisar('Cambio guardado', 'ok'); onListo();
    } catch (e) { avisar(e.message, 'error'); }
  };
  const recalculado = puedeRecalcular ? Math.round((h.valor * diasNum) / h.dias) : null;
  return html`<${Modal} titulo=${'Cambiar: ' + QUE_ANTES[h.concepto] + ' de ' + (h.nombre_programa || h.nombre || h.documento)}
    sub=${`Pago de antes del programa · ${h.desde ? fCorta(h.desde) : '¿?'} → ${fCorta(h.hasta)}. Queda anotado qué había antes y por qué se cambió.`}
    onCerrar=${salir} pie=${html`<button class="btn" onClick=${salir}>${cambio ? 'Cancelar' : 'Cerrar'}</button>${cambio && html`<button class="btn primario" id="he-guardar" disabled=${f.motivo.trim().length < 5 || f.valor == null} onClick=${guardar}>Guardar el cambio</button>`}`}>
    <div class="pila">
      <div class="campos">
        <${Campo} etiqueta="Días" id="he-dias" ayuda=${h.dias != null ? `Antes: ${String(h.dias).replace('.', ',')}` : ''}><input id="he-dias" inputmode="decimal" value=${f.dias} onInput=${(e) => setF({ ...f, dias: e.target.value.replace(/[^\d,.]/g, '') })} /></${Campo}>
        <${Campo} etiqueta="Valor" id="he-valor" ayuda=${html`Antes: ${pesos(h.valor)}${recalculado != null ? html` · <button type="button" class="btn link small" id="he-recalcular" onClick=${() => setF({ ...f, valor: recalculado })}>Calcularlo con ${String(diasNum).replace('.', ',')} días (${pesos(recalculado)})</button>` : ''}`}>
          <${InputPesos} id="he-valor" valor=${f.valor} onCambio=${(v) => setF({ ...f, valor: v })} /></${Campo}>
        ${h.concepto === 'cesantias' && html`<${Campo} etiqueta="Intereses" id="he-int" ayuda=${`Antes: ${pesos(h.intereses)}`}><${InputPesos} id="he-int" valor=${f.intereses} onCambio=${(v) => setF({ ...f, intereses: v })} /></${Campo}>`}
        ${cambio && html`<${Campo} etiqueta="¿Por qué se cambia?" requerido id="he-motivo" ancho><input id="he-motivo" value=${f.motivo} placeholder="Ej.: se le descontaron 2 días por faltas del 3 y 4 de junio (memorando adjunto)" onInput=${(e) => setF({ ...f, motivo: e.target.value })} /></${Campo}>`}
      </div>
      <${Adjuntos} entidad="historica" id=${h.id} lista=${adj.datos || []} onCambio=${() => { setCambioDoc(true); adj.recargar(); }} idBoton="he-adjuntar" vacio="Sin documentos. Puede adjuntar el soporte del descuento (memorando, permiso, sanción…)." />
      ${h.observacion && html`<p class="small muted">Nota: ${h.observacion}</p>`}
    </div>
  </${Modal}>`;
}
function HistorialAntes() {
  const y = Number(hoy().slice(0, 4));
  const [anio, setAnio] = useState('');
  const [concepto, setConcepto] = useState('');
  const [q, setQ] = useState('');
  const { datos, cargando, error, recargar } = useDatos('/api/historicas?' + qs({ anio, concepto, q }));
  const filas = datos || [];
  const suma = (k) => filas.reduce((a, f) => a + (f[k] || 0), 0);
  const alTrabajador = (f) => (f.concepto === 'cesantias' ? (f.intereses || 0) : f.neto != null ? f.neto : f.valor - (f.descuentos || 0));
  const anios = [];
  for (let a = y; a >= y - 10; a--) anios.push(a);
  const nombre = (f) => f.nombre_programa || f.nombre || '—';
  const excel = () => {
    const cab = ['Documento', 'Nombre', 'Qué se pagó', 'Desde', 'Hasta', 'Días', 'Salario', 'Auxilio', 'Base', 'Valor', 'Intereses', 'Descuentos', 'Pagado al trabajador', 'Fondo', 'Observación', 'De dónde salió'];
    const cuerpo = filas.map((f) => [f.documento, nombre(f), QUE_ANTES[f.concepto], f.desde || '', f.hasta, f.dias ?? '', f.salario ?? '', f.auxilio ?? '', f.base ?? '', f.valor, f.intereses ?? '', f.descuentos ?? '', alTrabajador(f), f.fondo || '', f.observacion || '', f.fuente || '']);
    const todas = [['Pagos de antes del programa (de los Excel de la empresa)'], [`Descargado el ${hoy()}`], [], cab, ...cuerpo, ['', 'TOTAL', '', '', '', '', '', '', '', suma('valor'), suma('intereses'), suma('descuentos'), filas.reduce((a, f) => a + alTrabajador(f), 0), '', '', '']];
    descargarExcel(`pagos-antes-del-programa-${anio || 'todos'}.xlsx`, [{ nombre: 'Antes del programa', filas: todas, filaEncabezado: 3, dinero: [6, 7, 8, 9, 10, 11, 12], anchos: [13, 30, 20, 11, 11, 6, 13, 12, 13, 13, 12, 12, 14, 14, 30, 36], negrita: (r) => r === todas.length - 1, finFiltro: todas.length - 2 }]);
  };
  const [editar, setEditar] = useState(null);
  const borrar = async (f) => {
    if (!(await confirmar({ titulo: 'Borrar este pago de antes del programa', texto: `${QUE_ANTES[f.concepto]} de ${nombre(f)} (${fCorta(f.hasta)}, ${pesos(f.valor)}). Solo borra este registro de historia; queda anotado en el registro de cambios.`, boton: 'Borrar', peligro: true }))) return;
    try { await api('/api/historicas/' + f.id, { metodo: 'DELETE' }); avisar('Borrado'); recargar(); } catch (e) { avisar(e.message, 'error'); }
  };
  return html`<div class="pila">
    <div class="encabezado">
      <div><h1>Pagado antes del programa</h1><p class="sub">Lo que salió de los Excel de la empresa, tal cual. Es historia: no se recalcula. Se suben en Importar de Excel.</p></div>
      <button class="btn" onClick=${excel} disabled=${!filas.length}><${Icono} n="excel" />Descargar en Excel</button>
    </div>
    <div class="panel"><div class="panel-cuerpo fila">
      <select style="width:auto" value=${anio} onChange=${(e) => setAnio(e.target.value)} aria-label="Año"><option value="">Todos los años</option>${anios.map((a) => html`<option value=${a}>${a}</option>`)}</select>
      <select style="width:auto" value=${concepto} onChange=${(e) => setConcepto(e.target.value)} aria-label="Qué"><option value="">Todo</option>${Object.entries(QUE_ANTES).map(([k, v]) => html`<option value=${k}>${v}</option>`)}</select>
      <input type="search" style="max-width:300px" placeholder="Nombre o cédula…" value=${q} onInput=${(e) => setQ(e.target.value)} aria-label="Buscar" />
    </div></div>
    ${filas.length > 0 && html`<div class="tarjetas">
      <div class="tarjeta"><div class="t">Pagos</div><div class="v">${filas.length}</div><div class="d">${new Set(filas.map((f) => f.documento)).size} personas</div></div>
      <div class="tarjeta"><div class="t">Primas</div><div class="v">${millones(filas.filter((f) => f.concepto === 'prima').reduce((a, f) => a + f.valor, 0))}</div></div>
      <div class="tarjeta"><div class="t">Cesantías</div><div class="v">${millones(filas.filter((f) => f.concepto === 'cesantias').reduce((a, f) => a + f.valor, 0))}</div><div class="d">más ${pesos(suma('intereses'))} de intereses</div></div>
    </div>`}
    <div class="panel">
      ${error ? html`<div class="panel-cuerpo"><${Aviso} tipo="bad">${error}</${Aviso}></div>` : cargando && !datos ? html`<${Cargando} />` : filas.length === 0
        ? html`<div class="vacio"><b>No hay pagos de antes del programa${anio ? ' en ' + anio : ''}</b>Se suben en <a href="#/importar">Importar de Excel</a> → Liquidaciones de antes del programa.</div>`
        : html`<div class="tabla-scroll" style="max-height:none"><table class="tabla">
        <thead><tr><th>Periodo</th><th>Trabajador</th><th>Qué</th><th class="num">Días</th><th class="num">Base</th><th class="num">Valor</th><th class="num">Al trabajador</th><th></th></tr></thead>
        <tbody>${filas.map((f) => html`<tr key=${f.id} class="fila-click" tabindex="0" title="Ver, cambiar o adjuntar un documento" onClick=${() => setEditar(f)} onKeyDown=${(e) => e.key === 'Enter' && e.target === e.currentTarget && setEditar(f)}>
          <td class="nowrap">${f.desde ? fCorta(f.desde) : '¿?'} → ${fCorta(f.hasta)}</td>
          <td>${f.trabajador_id ? html`<a href=${'#/trabajador/' + f.trabajador_id} onClick=${(e) => e.stopPropagation()}><b>${nombre(f)}</b></a>` : html`<b>${nombre(f)}</b>`}<div class="doc">${f.documento}${f.trabajador_id ? '' : ' · no está en el programa'}</div></td>
          <td>${QUE_ANTES[f.concepto]}${f.adjuntos ? html` <span class="chip" title="Documentos adjuntos"><${Icono} n="clip" />${f.adjuntos}</span>` : ''}${f.observacion ? html`<div class="doc">${f.observacion}</div>` : ''}</td>
          <td class="num">${f.dias ?? ''}</td><td class="num">${f.base != null ? pesos(f.base) : ''}</td>
          <td class="num">${pesos(f.valor)}${f.intereses ? html`<div class="doc">+ ${pesos(f.intereses)} intereses</div>` : ''}${f.fondo ? html`<div class="doc">al fondo ${f.fondo}</div>` : ''}</td>
          <td class="num"><b>${pesos(alTrabajador(f))}</b></td>
          <td class="nowrap" onClick=${(e) => e.stopPropagation()} onKeyDown=${(e) => e.stopPropagation()}><button class="btn chico" title="Cambiar o adjuntar un documento" aria-label=${'Cambiar pago de ' + nombre(f)} onClick=${() => setEditar(f)}><${Icono} n="lapiz" /></button>
            <button class="btn chico" title="Borrar este registro" aria-label=${'Borrar pago de ' + nombre(f)} onClick=${() => borrar(f)}><${Icono} n="x" /></button></td>
        </tr>`)}</tbody></table></div>`}
    </div>
    ${editar && html`<${EditarHistorica} h=${editar} onCerrar=${() => setEditar(null)} onListo=${() => { setEditar(null); recargar(); }} />`}
  </div>`;
}

function HistorialPrograma({ query }) {
  const y = Number(hoy().slice(0, 4));
  const [modo, setModo] = useState(query.lote ? 'todo' : query.anio ? 'anio' : 'anio');
  const [anio, setAnio] = useState(Number(query.anio) || y);
  const [desde, setDesde] = useState(`${y}-01-01`);
  const [hasta, setHasta] = useState(hoy());
  const [campo, setCampo] = useState('fecha');
  const [tipo, setTipo] = useState('');
  const [sede, setSede] = useState('');
  const [q, setQ] = useState('');
  const [anuladas, setAnuladas] = useState(false);
  const lote = query.lote || '';
  const sedes = useDatos('/api/sedes');

  const rango = modo === 'anio' ? [`${anio}-01-01`, `${anio}-12-31`] : modo === 'rango' ? [desde, hasta] : ['', ''];
  const ruta = '/api/liquidaciones?' + qs({ desde: rango[0], hasta: rango[1], campo, tipo, sede, q, lote, estado: anuladas ? 'todas' : '' });
  const { datos, cargando, error } = useDatos(ruta);
  const filas = datos?.filas || [];
  const tot = datos?.totales;
  const anios = [];
  for (let a = y + 1; a >= y - 10; a--) anios.push(a);

  const descripcion = modo === 'anio' ? `año ${anio}` : modo === 'rango' ? `del ${fCorta(desde)} al ${fCorta(hasta)}` : 'todas las fechas';
  const excel = () => {
    const cab = ['N.º', 'Fecha', 'Estado', 'Documento', 'Trabajador', 'Sede', 'Cargo', 'Tipo', 'Desde', 'Hasta', 'Cesantías', 'Intereses', 'Prima', 'Vacaciones', 'Indemnización', 'Otros pagos', 'Descuentos', 'Al fondo', 'Al trabajador', 'Elaboró', 'Motivo de anulación'];
    const cuerpo = filas.map((f) => [f.consecutivo, f.fecha, f.estado === 'anulada' ? 'ANULADA' : 'Vigente', f.documento, f.nombre, f.sede || '', f.cargo || '', etiquetaTipo(f.tipo, f.conceptos_lista), f.desde || '', f.hasta, f.cesantias, f.intereses, f.prima, f.vacaciones, f.indemnizacion, f.otros, f.deducciones, f.a_fondo, f.neto, f.creado_por || '', f.anulada_motivo || '']);
    const total = ['', '', '', '', 'TOTAL (sin anuladas)', '', '', '', '', '', tot.cesantias, tot.intereses, tot.prima, tot.vacaciones, tot.indemnizacion, tot.otros, tot.deducciones, tot.a_fondo, tot.neto, '', ''];
    const titulo = [[`Historial de liquidaciones — ${descripcion}${campo === 'periodo' ? ' (por periodo liquidado)' : ''}`], [`Descargado el ${hoy()}`], []];
    const todas = [...titulo, cab, ...cuerpo, total];
    descargarExcel(`liquidaciones-${modo === 'anio' ? anio : hoy()}.xlsx`, [{
      nombre: 'Liquidaciones', filas: todas, filaEncabezado: 3, dinero: [10, 11, 12, 13, 14, 15, 16, 17, 18],
      anchos: [7, 11, 10, 13, 30, 16, 18, 24, 11, 11, 13, 12, 13, 13, 13, 12, 12, 13, 14, 14, 30],
      negrita: (r) => r === todas.length - 1, finFiltro: todas.length - 2,
    }]);
  };

  return html`<div class="pila">
    <div class="encabezado">
      <div><h1>Historial</h1><p class="sub">Todo lo liquidado queda aquí. Filtre por año o entre dos fechas.</p></div>
      <button class="btn" onClick=${excel} disabled=${!filas.length}><${Icono} n="excel" />Descargar en Excel</button>
    </div>
    ${lote && html`<${Aviso} tipo="info">Mostrando solo un grupo liquidado a la vez. <a href="#/historial">Ver todo el historial</a></${Aviso}>`}
    <div class="panel"><div class="panel-cuerpo pila">
      <div class="fila">
        <div class="segmentado" role="group" aria-label="Periodo">
          <button class=${modo === 'anio' ? 'activo' : ''} onClick=${() => setModo('anio')}>Por año</button>
          <button class=${modo === 'rango' ? 'activo' : ''} onClick=${() => setModo('rango')}>Entre fechas</button>
          <button class=${modo === 'todo' ? 'activo' : ''} onClick=${() => setModo('todo')}>Todo</button>
        </div>
        ${modo === 'anio' && html`<select style="width:auto" value=${anio} onChange=${(e) => setAnio(Number(e.target.value))} aria-label="Año">${anios.map((a) => html`<option value=${a}>${a}</option>`)}</select>`}
        ${modo === 'rango' && html`<label class="fila small" style="gap:6px">Del <input type="date" style="width:auto" value=${desde} onInput=${(e) => setDesde(e.target.value)} /></label>
          <label class="fila small" style="gap:6px">al <input type="date" style="width:auto" value=${hasta} onInput=${(e) => setHasta(e.target.value)} /></label>`}
        ${modo !== 'todo' && html`<select style="width:auto" value=${campo} onChange=${(e) => setCampo(e.target.value)} aria-label="Qué fecha mirar">
          <option value="fecha">según la fecha en que se hizo</option><option value="periodo">según el periodo que se pagó</option></select>`}
      </div>
      <div class="fila">
        <input type="search" style="max-width:300px" placeholder="Nombre, cédula o N.º…" value=${q} onInput=${(e) => setQ(e.target.value)} aria-label="Buscar" />
        <select style="width:auto" value=${tipo} onChange=${(e) => setTipo(e.target.value)} aria-label="Tipo"><option value="">Todos los tipos</option>${Object.entries(TIPOS).map(([k, v]) => html`<option value=${k}>${v}</option>`)}<option value="varios">Varias a la vez</option></select>
        ${sedes.datos?.length > 0 && html`<select style="width:auto" value=${sede} onChange=${(e) => setSede(e.target.value)} aria-label="Sede"><option value="">Todas las sedes</option>${sedes.datos.map((s) => html`<option>${s}</option>`)}</select>`}
        <label class="check small"><input type="checkbox" checked=${anuladas} onChange=${(e) => setAnuladas(e.target.checked)} />Mostrar anuladas</label>
      </div>
    </div></div>

    ${tot && filas.length > 0 && html`<div class="tarjetas">
      <div class="tarjeta"><div class="t">Liquidaciones</div><div class="v">${filas.filter((f) => f.estado === 'vigente').length}</div><div class="d">${descripcion}</div></div>
      <div class="tarjeta"><div class="t">Liquidado para los trabajadores</div><div class="v">${millones(tot.neto)}</div><div class="d">${pesos(tot.neto)}</div></div>
      <div class="tarjeta"><div class="t">Liquidado para los fondos</div><div class="v">${millones(tot.a_fondo)}</div><div class="d">${pesos(tot.a_fondo)}</div></div>
      <div class="tarjeta"><div class="t">Por concepto</div><div class="d" style="margin-top:6px;line-height:1.6">
        ${tot.cesantias ? html`Cesantías ${pesos(tot.cesantias)}<br />` : ''}${tot.intereses ? html`Intereses ${pesos(tot.intereses)}<br />` : ''}${tot.prima ? html`Prima ${pesos(tot.prima)}<br />` : ''}${tot.vacaciones ? html`Vacaciones ${pesos(tot.vacaciones)}<br />` : ''}${tot.indemnizacion ? html`Indemnizaciones ${pesos(tot.indemnizacion)}` : ''}
      </div></div>
    </div>`}

    <div class="panel">
      ${error ? html`<div class="panel-cuerpo"><${Aviso} tipo="bad">${error}</${Aviso}></div>` : cargando && !datos ? html`<${Cargando} />` : filas.length === 0 ? html`<div class="vacio"><b>No hay liquidaciones ${descripcion !== 'todas las fechas' ? 'en ' + descripcion : ''}</b>Pruebe con otro año u otras fechas.</div>` : html`<div class="tabla-scroll" style="max-height:none"><table class="tabla">
        <thead><tr><th>N.º</th><th>Fecha</th><th>Trabajador</th><th>Qué se liquidó</th><th>Periodo</th><th class="num">Al fondo</th><th class="num">Al trabajador</th><th><span class="sr-solo">Ver o corregir</span></th></tr></thead>
        <tbody>${filas.map((f) => html`<tr key=${f.id} class=${'fila-click' + (f.estado === 'anulada' ? ' anulada' : '')} tabindex="0" onClick=${() => ir('/liquidacion/' + f.id)} onKeyDown=${(e) => e.key === 'Enter' && ir('/liquidacion/' + f.id)}>
          <td>${f.consecutivo}</td><td class="nowrap">${fCorta(f.fecha)}</td>
          <td><b>${f.nombre}</b><div class="doc">${f.documento}${f.sede ? ' · ' + f.sede : ''}</div></td>
          <td>${etiquetaTipo(f.tipo, f.conceptos_lista)} ${f.estado === 'anulada' && html`<span class="chip bad">Anulada</span>`}</td>
          <td class="nowrap">${f.tipo === 'vacaciones' ? 'Corte ' + fCorta(f.hasta) : `${fCorta(f.desde)} → ${fCorta(f.hasta)}`}</td>
          <td class="num">${f.a_fondo ? pesos(f.a_fondo) : '—'}</td><td class="num"><b>${pesos(f.neto)}</b></td>
          <td><${BotonesLiquidacion} l=${f} /></td>
        </tr>`)}</tbody></table></div>`}
    </div>
  </div>`;
}
