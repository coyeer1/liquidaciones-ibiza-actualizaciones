import { html, useState, useEffect } from './vendor/preact-htm.js';
import { api, pesos, num, fCorta, fLarga, hoy, ir, sumarDias, dias360, diasAusencia, finLaboral, estadoPeriodo, tiempoServicio, TIPOS, etiquetaTipo, MOTIVOS, descargarExcel } from './util.js';
import { Icono, Modal, Campo, InputPesos, Aviso, Cargando, useDatos, avisar, confirmar } from './comp.js';

const FONDOS = ['Porvenir', 'Protección', 'Colfondos', 'Skandia', 'Fondo Nacional del Ahorro'];
const TIPOS_DOC = { CC: 'Cédula de ciudadanía', CE: 'Cédula de extranjería', PPT: 'Permiso por protección temporal', PA: 'Pasaporte', TI: 'Tarjeta de identidad' };
const finAnioPasado = () => `${Number(hoy().slice(0, 4)) - 1}-12-30`; // mes de 30: el 30 de diciembre cierra el año

// ---------------------------------------------------------------- formulario

export function FormTrabajador({ inicial, onCerrar, onGuardado }) {
  const nuevo = !inicial?.id;
  const [t, setT] = useState(inicial || { tipo_documento: 'CC', tipo_salario: 'fijo', auxilio_transporte: 'auto' });
  const [guardando, setGuardando] = useState(false);
  const [sedes, setSedes] = useState([]);
  const [minimo, setMinimo] = useState(null);
  useEffect(() => {
    api('/api/sedes').then(setSedes).catch(() => {});
    api('/api/parametros').then((ps) => setMinimo(ps.find((p) => p.anio === Number(hoy().slice(0, 4)))?.smmlv ?? null)).catch(() => {});
  }, []);
  const ganaMinimo = !!Number(t.salario_minimo);
  const c = (k) => ({ id: 'tr-' + k, value: t[k] ?? '', onInput: (e) => setT({ ...t, [k]: e.target.value }) });
  const guardar = async (e) => {
    e?.preventDefault();
    setGuardando(true);
    try {
      if (nuevo) {
        const r = await api('/api/trabajadores', { metodo: 'POST', cuerpo: t });
        avisar('Trabajador agregado', 'ok');
        onGuardado(r.id);
      } else {
        await api('/api/trabajadores/' + t.id, { metodo: 'PUT', cuerpo: t });
        avisar('Cambios guardados', 'ok');
        onGuardado(t.id);
      }
    } catch (err) { avisar(err.message, 'error'); }
    setGuardando(false);
  };
  return html`<${Modal} ancho titulo=${nuevo ? 'Agregar trabajador' : 'Editar datos de ' + (inicial.nombre || '')} onCerrar=${onCerrar}
    pie=${html`<button class="btn" onClick=${onCerrar}>Cancelar</button><button class="btn primario" disabled=${guardando} onClick=${guardar}>${nuevo ? 'Agregar' : 'Guardar cambios'}</button>`}>
    <form onSubmit=${guardar} class="pila">
      <h3>Datos personales</h3>
      <div class="campos">
        <${Campo} etiqueta="Tipo de documento" id="tr-tipo_documento"><select ...${c('tipo_documento')} onChange=${(e) => setT({ ...t, tipo_documento: e.target.value })}>${Object.entries(TIPOS_DOC).map(([k, v]) => html`<option value=${k}>${v}</option>`)}</select></${Campo}>
        <${Campo} etiqueta="Número de documento" requerido id="tr-documento"><input ...${c('documento')} inputmode="numeric" /></${Campo}>
        <${Campo} etiqueta="Nombres" requerido id="tr-nombres"><input ...${c('nombres')} /></${Campo}>
        <${Campo} etiqueta="Apellidos" id="tr-apellidos"><input ...${c('apellidos')} /></${Campo}>
        <${Campo} etiqueta="Cargo" id="tr-cargo"><input ...${c('cargo')} /></${Campo}>
        <${Campo} etiqueta="Sede" id="tr-sede"><input ...${c('sede')} list="lista-sedes" /><datalist id="lista-sedes">${sedes.map((s) => html`<option value=${s} />`)}</datalist></${Campo}>
        <${Campo} etiqueta="Teléfono" id="tr-telefono"><input ...${c('telefono')} /></${Campo}>
        <${Campo} etiqueta="Correo" id="tr-correo"><input ...${c('correo')} type="text" /></${Campo}>
      </div>
      <h3 style="margin-top:22px">Contrato <span class="chip brand" style="margin-left:6px">Término indefinido</span></h3>
      <div class="campos">
        <${Campo} etiqueta="Fecha de ingreso" requerido id="tr-fecha_ingreso"><input type="date" ...${c('fecha_ingreso')} /></${Campo}>
        ${nuevo && html`<${Campo} etiqueta="Salario mensual" requerido id="tr-salario" ayuda=${ganaMinimo ? 'Es el mínimo de este año.' : 'Si después le suben el sueldo, se registra en su ficha.'}><${InputPesos} id="tr-salario" valor=${t.salario} onCambio=${(v) => setT({ ...t, salario: v, salario_minimo: minimo && v === minimo ? 1 : 0 })} /></${Campo}>`}
        ${t.tipo_salario !== 'integral' && html`<div class="campo" style="align-self:end"><label class="check"><input type="checkbox" checked=${ganaMinimo} onChange=${(e) => setT({ ...t, salario_minimo: e.target.checked ? 1 : 0, ...(nuevo && e.target.checked && minimo ? { salario: minimo } : {}) })} /><span>Gana el salario mínimo<br /><span class="small muted">Se ajusta solo cada año, sin registrar el aumento.</span></span></label></div>`}
        <${Campo} etiqueta="Tipo de salario" id="tr-tipo_salario" ayuda=${t.tipo_salario === 'variable' ? 'Gana comisiones u horas extra que cambian cada mes: se promedia.' : t.tipo_salario === 'integral' ? 'Mínimo 13 salarios mínimos; ya incluye prestaciones.' : 'Gana lo mismo todos los meses.'}>
          <select ...${c('tipo_salario')} onChange=${(e) => setT({ ...t, tipo_salario: e.target.value })}><option value="fijo">Fijo</option><option value="variable">Variable (comisiones, horas extra)</option><option value="integral">Integral</option></select>
        </${Campo}>
        <${Campo} etiqueta="Auxilio de transporte" id="tr-auxilio_transporte" ayuda="Lo da la ley a quien gana hasta 2 salarios mínimos.">
          <select ...${c('auxilio_transporte')} onChange=${(e) => setT({ ...t, auxilio_transporte: e.target.value })}><option value="auto">Sí, si gana hasta 2 mínimos</option><option value="no">No aplica (la empresa le da el transporte o trabaja en casa)</option></select>
        </${Campo}>
        <${Campo} etiqueta="Fondo de cesantías" id="tr-fondo_cesantias"><input ...${c('fondo_cesantias')} list="lista-fondos" /><datalist id="lista-fondos">${FONDOS.map((s) => html`<option value=${s} />`)}</datalist></${Campo}>
      </div>
      <h3 style="margin-top:22px">Lo que ya se le liquidó antes de usar este programa</h3>
      <p class="small muted" style="margin-top:-6px">Si viene de antes, ponga hasta qué fecha ya se le pagó. El programa arranca desde el día siguiente y no le vuelve a liquidar lo que ya está pago. Si es nuevo, déjelo en blanco.</p>
      <div class="campos">
        <${Campo} etiqueta="Cesantías liquidadas hasta" id="tr-cesantias_hasta_inicial" ayuda=${html`Lo normal: <button type="button" class="btn link" onClick=${() => setT({ ...t, cesantias_hasta_inicial: finAnioPasado() })}>31 dic ${finAnioPasado().slice(0, 4)}</button>`}><input type="date" ...${c('cesantias_hasta_inicial')} /></${Campo}>
        <${Campo} etiqueta="Prima liquidada hasta" id="tr-prima_hasta_inicial" ayuda="Normalmente 30 de junio o 30 de diciembre."><input type="date" ...${c('prima_hasta_inicial')} /></${Campo}>
        <${Campo} etiqueta="Días de vacaciones pendientes" id="tr-vac_saldo_dias" ayuda="Días hábiles que le quedan por disfrutar."><input ...${c('vac_saldo_dias')} inputmode="decimal" placeholder="Ej.: 7,5" /></${Campo}>
        <${Campo} etiqueta="…contados hasta el" id="tr-vac_saldo_fecha" ayuda="La fecha en que se sacó esa cuenta."><input type="date" ...${c('vac_saldo_fecha')} /></${Campo}>
      </div>
      <${Campo} etiqueta="Notas" id="tr-notas" ancho><textarea ...${c('notas')} /></${Campo}>
      <button type="submit" class="sr">Guardar</button>
    </form>
  </${Modal}>`;
}

// ---------------------------------------------------------------- lista

export function ListaTrabajadores({ query }) {
  const [q, setQ] = useState('');
  const [estado, setEstado] = useState('activos');
  const [sede, setSede] = useState('');
  const [nuevo, setNuevo] = useState(!!query.nuevo);
  const [eliminar, setEliminar] = useState(null);
  const sedes = useDatos('/api/sedes');
  const ruta = '/api/trabajadores?' + new URLSearchParams({ q, estado: estado === 'todos' ? '' : estado, sede });
  const lista = useDatos(ruta);
  const filas = lista.datos || [];
  const corteCes = finAnioPasado();

  const exportar = () => {
    descargarExcel(`trabajadores-${hoy()}.xlsx`, [{
      nombre: 'Trabajadores',
      filas: [['Documento', 'Nombre', 'Cargo', 'Sede', 'Ingreso', 'Retiro', 'Salario', 'Cesantías liquidadas hasta', 'Prima liquidada hasta', 'Vacaciones pendientes (días)'],
        ...filas.map((t) => [t.documento, t.nombre, t.cargo || '', t.sede || '', t.fecha_ingreso, t.fecha_retiro || '', t.salario,
          estadoPeriodo('cesantias', t.cesantias_hasta, t.fecha_ingreso).txt, estadoPeriodo('prima', t.prima_hasta, t.fecha_ingreso).txt, t.vacaciones_pendientes])],
      anchos: [14, 32, 22, 18, 12, 12, 14, 16, 16, 14], dinero: [6],
    }]);
  };

  return html`<div class="pila">
    <div class="encabezado">
      <div><h1>Trabajadores</h1><p class="sub">Todos con contrato a término indefinido. Haga clic en uno para ver su historial.</p></div>
      <div class="fila">
        <a class="btn" href="#/importar"><${Icono} n="importar" />Importar de Excel</a>
        <button class="btn primario" onClick=${() => setNuevo(true)}><${Icono} n="mas" />Agregar trabajador</button>
      </div>
    </div>
    <div class="panel">
      <div class="panel-cab">
        <div class="fila" style="flex:1">
          <input type="search" style="max-width:320px" placeholder="Buscar por nombre, cédula o cargo…" value=${q} onInput=${(e) => setQ(e.target.value)} aria-label="Buscar" />
          <div class="segmentado" role="group" aria-label="Estado">
            ${[['activos', 'Activos'], ['retirados', 'Retirados'], ['todos', 'Todos']].map(([k, v]) => html`<button class=${estado === k ? 'activo' : ''} aria-pressed=${estado === k} onClick=${() => setEstado(k)}>${v}</button>`)}
          </div>
          ${sedes.datos?.length > 0 && html`<select style="max-width:200px" value=${sede} onChange=${(e) => setSede(e.target.value)} aria-label="Sede"><option value="">Todas las sedes</option>${sedes.datos.map((s) => html`<option>${s}</option>`)}</select>`}
        </div>
        <div class="acciones"><button class="btn chico" onClick=${exportar} disabled=${!filas.length}><${Icono} n="excel" />Excel</button></div>
      </div>
      ${lista.cargando && !lista.datos ? html`<${Cargando} />` : filas.length === 0 ? html`<div class="vacio">
          <b>${q || sede ? 'Nadie coincide con la búsqueda' : estado === 'retirados' ? 'No hay trabajadores retirados' : 'Todavía no hay trabajadores'}</b>
          ${!q && !sede && estado !== 'retirados' && html`<span>Súbalos desde Excel o agréguelos uno por uno.</span>`}
        </div>` : html`<div class="tabla-scroll"><table class="tabla">
        <thead><tr><th>Trabajador</th><th>Sede / cargo</th><th>Ingreso</th><th class="num">Salario</th><th>Cesantías hasta</th><th>Prima hasta</th><th class="num">Vacaciones</th><th><span class="sr-solo">Eliminar</span></th></tr></thead>
        <tbody>${filas.map((t) => html`<tr class="fila-click" key=${t.id} tabindex="0" onClick=${() => ir('/trabajador/' + t.id)} onKeyDown=${(e) => e.key === 'Enter' && ir('/trabajador/' + t.id)}>
          <td><b>${t.nombre}</b><div class="doc">${t.tipo_documento} ${t.documento}${t.fecha_retiro ? html` · <span class="chip">Retirado ${fCorta(t.fecha_retiro)}</span>` : ''}</div></td>
          <td>${t.sede || '—'}<div class="doc">${t.cargo || ''}</div></td>
          <td class="nowrap">${fCorta(t.fecha_ingreso)}</td>
          <td class="num">${pesos(t.salario)}</td>
          ${['cesantias', 'prima'].map((k) => {
            if (t.tipo_salario === 'integral') return html`<td class="nowrap"><span class="faint">No aplica</span></td>`;
            const e = estadoPeriodo(k, k === 'cesantias' ? t.cesantias_hasta : t.prima_hasta, t.fecha_ingreso);
            const atrasada = !t.fecha_retiro && (e.pendiente || (k === 'cesantias' && t.cesantias_hasta && t.cesantias_hasta < corteCes && t.fecha_ingreso <= corteCes));
            return html`<td class="nowrap" title=${e.sub || ''}><span class=${atrasada ? 'chip warn' : e.nunca ? 'faint' : ''}>${e.txt}</span>${e.nunca && !e.pendiente ? html`<div class="doc">1.er corte: ${e.sub.split('es el ')[1].replace('.', '')}</div>` : ''}</td>`;
          })}
          <td class="num" title=${t.vacaciones_sin_historia ? 'Contadas desde su ingreso: no hay anotadas vacaciones que ya tomó. Corríjalo en su ficha antes de pagarlas.' : ''}>${t.vacaciones_pendientes == null ? '—' : html`<span class=${t.vacaciones_pendientes >= 30 ? 'chip warn' : ''}>${num(t.vacaciones_pendientes, 1)} días</span>`}${t.vacaciones_sin_historia && t.vacaciones_pendientes >= 15 ? html`<div class="doc">sin confirmar</div>` : ''}</td>
          <td class="nowrap"><button class="btn chico basura-fila" title="Eliminar" aria-label=${'Eliminar a ' + t.nombre} onClick=${(ev) => { ev.stopPropagation(); setEliminar(t); }} onKeyDown=${(ev) => ev.stopPropagation()}><${Icono} n="basura" /></button></td>
        </tr>`)}</tbody>
      </table></div>`}
    </div>
    ${filas.length > 0 && html`<p class="small muted">${filas.length} ${filas.length === 1 ? 'trabajador' : 'trabajadores'}. En naranja: cesantías del año pasado sin liquidar o vacaciones acumuladas de más de 2 periodos. "Sin confirmar": no hay anotadas las vacaciones que ya tomó, así que se cuentan desde su ingreso.</p>`}
    ${nuevo && html`<${FormTrabajador} onCerrar=${() => setNuevo(false)} onGuardado=${(id) => { setNuevo(false); ir('/trabajador/' + id); }} />`}
    ${eliminar && html`<${EliminarTrabajador} trab=${eliminar} onCerrar=${() => setEliminar(null)} onListo=${() => { setEliminar(null); lista.recargar(); }} onBorrado=${() => { setEliminar(null); lista.recargar(); }} />`}
  </div>`;
}

// ---------------------------------------------------------------- ficha

function LineaTiempo({ ingreso, fin, inicial, periodos }) {
  const ms = (f) => Date.parse(f + 'T00:00:00Z');
  const a = ms(ingreso);
  const b = ms(fin) + 86400000;
  const total = Math.max(1, b - a);
  const pos = (d, h) => {
    const x = Math.max(a, ms(d));
    const y = Math.min(b, ms(h) + 86400000);
    return y > x ? { left: ((x - a) / total) * 100 + '%', width: ((y - x) / total) * 100 + '%' } : null;
  };
  const ini = inicial && inicial >= ingreso ? pos(ingreso, inicial) : null;
  return html`<div>
    <div class="linea" role="img" aria-label="Periodos liquidados">
      ${ini && html`<i class="inicial" style=${ini} title=${'Liquidado antes del programa hasta ' + fCorta(inicial)} />`}
      ${periodos.map((p) => { const s = pos(p.desde, p.hasta); return s && html`<i style=${s} title=${`N.º ${p.consecutivo}: ${fCorta(p.desde)} a ${fCorta(p.hasta)}`} />`; })}
    </div>
    <div class="linea-eje"><span>${fCorta(ingreso)}</span><span>${fCorta(fin)}</span></div>
  </div>`;
}

function TarjetaPeriodo({ tipo, titulo, hasta, origen, diasPend, ingreso, corte, periodos, noAplica, huecos = [], liquidar }) {
  if (noAplica) return html`<div class="estado"><div class="t">${titulo}</div><div class="v faint">No aplica</div><div class="d">Salario integral.</div></div>`;
  const nunca = !hasta || hasta < ingreso;
  const ep = estadoPeriodo(tipo, hasta, ingreso);
  const atrasada = diasPend > 180 || huecos.length > 0;
  const desdeFinal = nunca ? ingreso : sumarDias(hasta, 1);
  return html`<div class=${'estado' + (atrasada ? ' alerta' : '')}>
    <div class="t">${titulo}</div>
    <div class="v">${!nunca ? 'Liquidada hasta el ' + fCorta(finLaboral(hasta)) : ep.pendiente ? 'Nunca liquidada' : html`Todavía no le toca <span class="small muted" style="font-weight:400">(${ep.sub})</span>`}</div>
    <div class="d">${diasPend > 0 ? html`Faltan <b>${diasPend} días</b>${desdeFinal <= corte ? ` (del ${fCorta(desdeFinal)} al ${fCorta(corte)}${huecos.length ? ', más lo que quedó atrás' : ''})` : huecos.length ? ', de lo que quedó atrás' : ''}` : 'Al día'}
      ${origen === 'saldo_inicial' && html`<br /><span class="faint">Dato inicial cargado a mano.</span>`}
      ${huecos.map((h) => html`<div class="hueco"><span>Quedó sin liquidar del ${fCorta(h.desde)} al ${fCorta(h.hasta)}</span>${liquidar && html`<a class="btn chico" href=${`${liquidar}&desde=${h.desde}&hasta=${h.hasta}`}>Liquidarlo</a>`}</div>`)}</div>
    <${LineaTiempo} ingreso=${ingreso} fin=${corte} inicial=${origen === 'saldo_inicial' ? hasta : null} periodos=${periodos} />
  </div>`;
}

function FormSalario({ trab, onCerrar, onListo }) {
  const [f, setF] = useState({ vigente_desde: hoy(), salario: null, nota: '' });
  const guardar = async () => {
    try { await api(`/api/trabajadores/${trab.id}/salarios`, { metodo: 'POST', cuerpo: f }); avisar('Salario registrado', 'ok'); onListo(); } catch (e) { avisar(e.message, 'error'); }
  };
  return html`<${Modal} titulo="Registrar cambio de salario" sub="El salario anterior queda guardado: el programa sabe cuánto ganaba en cada fecha." onCerrar=${onCerrar}
    pie=${html`<button class="btn" onClick=${onCerrar}>Cancelar</button><button class="btn primario" disabled=${!f.salario} onClick=${guardar}>Guardar</button>`}>
    <div class="campos">
      <${Campo} etiqueta="Nuevo salario mensual" requerido id="sal-v"><${InputPesos} id="sal-v" valor=${f.salario} onCambio=${(v) => setF({ ...f, salario: v })} /></${Campo}>
      <${Campo} etiqueta="Desde cuándo" requerido id="sal-d"><input id="sal-d" type="date" value=${f.vigente_desde} onInput=${(e) => setF({ ...f, vigente_desde: e.target.value })} /></${Campo}>
      <${Campo} etiqueta="Nota (opcional)" id="sal-n" ancho><input id="sal-n" value=${f.nota} placeholder="Ej.: aumento anual, ascenso" onInput=${(e) => setF({ ...f, nota: e.target.value })} /></${Campo}>
    </div>
  </${Modal}>`;
}

// Ya no trabaja aquí: o se le hace la liquidación definitiva en el programa, o (si ya se le pagó por fuera) solo se marca retirado.
function FormRetiro({ trab, onCerrar, onListo }) {
  const [f, setF] = useState({ fecha_retiro: '', motivo_retiro: '', nota: '' });
  const guardar = async () => {
    try { await api(`/api/trabajadores/${trab.id}/retiro`, { metodo: 'POST', cuerpo: f }); avisar('Quedó como retirado', 'ok'); onListo(); } catch (e) { avisar(e.message, 'error'); }
  };
  return html`<${Modal} titulo=${trab.nombre + ' ya no trabaja aquí'} onCerrar=${onCerrar}
    pie=${html`<button class="btn" onClick=${onCerrar}>Cancelar</button><button class="btn primario" disabled=${!f.fecha_retiro || !f.motivo_retiro} onClick=${guardar}>Marcarlo como retirado</button>`}>
    <div class="pila">
      <div class="aviso info"><div><b>¿Todavía no se le ha pagado su liquidación?</b> Hágala en el programa: calcula todo lo pendiente y lo deja retirado.
        <div style="margin-top:8px"><a class="btn primario chico" href=${`#/liquidar?t=${trab.id}&tipo=definitiva`}>Hacerle la liquidación definitiva</a></div></div></div>
      <h3 style="margin-top:6px">Si ya se le liquidó por fuera del programa</h3>
      <p class="small muted" style="margin-top:-6px">Solo se marca como retirado: sale de los activos, de "Liquidar a todos" y de los pendientes. Su ficha y su historia se conservan, y si vuelve se puede "Volver a contratar".</p>
      <div class="campos">
        <${Campo} etiqueta="Último día de trabajo" requerido id="rt-f"><input id="rt-f" type="date" min=${trab.fecha_ingreso} max=${hoy()} value=${f.fecha_retiro} onInput=${(e) => setF({ ...f, fecha_retiro: e.target.value })} /></${Campo}>
        <${Campo} etiqueta="Motivo" requerido id="rt-m"><select id="rt-m" value=${f.motivo_retiro} onChange=${(e) => setF({ ...f, motivo_retiro: e.target.value })}><option value="">Escoja…</option>${Object.entries(MOTIVOS).map(([k, v]) => html`<option value=${k}>${v}</option>`)}</select></${Campo}>
        <${Campo} etiqueta="Nota (opcional)" id="rt-n" ancho><input id="rt-n" value=${f.nota} placeholder="Ej.: se le pagó la liquidación el 20 de octubre" onInput=${(e) => setF({ ...f, nota: e.target.value })} /></${Campo}>
      </div>
    </div>
  </${Modal}>`;
}

// "Eliminar": lo que la gente busca cuando alguien ya no debe salir en la lista. Primero pregunta por qué:
// si se fue, se marca retirado (la historia se conserva); si se cargó por error, se borra del todo (solo sin liquidaciones).
export function EliminarTrabajador({ trab, onCerrar, onListo, onBorrado }) {
  const [paso, setPaso] = useState('elegir');
  const [nLiq, setNLiq] = useState(null);
  useEffect(() => { api('/api/trabajadores/' + trab.id).then((d) => setNLiq(d.liquidaciones.length)).catch(() => setNLiq(0)); }, []);
  const retirado = !!trab.fecha_retiro;
  if (paso === 'retiro') return html`<${FormRetiro} trab=${trab} onCerrar=${onCerrar} onListo=${onListo} />`;
  const borrar = async () => {
    try { await api('/api/trabajadores/' + trab.id, { metodo: 'DELETE' }); avisar('Borrado', 'ok'); onBorrado(); } catch (err) { avisar(err.message, 'error'); }
  };
  if (paso === 'borrar') return html`<${Modal} titulo=${'Borrar a ' + trab.nombre} onCerrar=${onCerrar}
    pie=${html`<button class="btn" onClick=${() => setPaso('elegir')}>Volver</button><button class="btn peligro lleno" onClick=${borrar}>Borrar</button>`}>
    <div class="pila"><p>Solo para alguien que se cargó <b>por error</b>. Se borran su ficha, sus salarios, su nómina y sus días no pagados. No se puede deshacer (queda una copia en el registro de cambios).</p>
      <p class="muted">Si la persona trabajó aquí y ya se fue, no la borre: use <b>"Ya no trabaja en la empresa"</b> para que su historia se conserve.</p></div>
  </${Modal}>`;
  const conLiq = nLiq > 0;
  return html`<${Modal} titulo=${'Eliminar a ' + trab.nombre} sub="¿Por qué lo quiere quitar?" onCerrar=${onCerrar}
    pie=${html`<button class="btn" onClick=${onCerrar}>Cancelar</button>`}>
    <div class="pila">
      ${retirado && conLiq ? html`<${Aviso} tipo="info">Ya está retirado desde el ${fLarga(trab.fecha_retiro)}: no sale entre los activos, ni en "Liquidar a todos", ni en los pendientes. No se puede borrar porque tiene ${nLiq} ${nLiq === 1 ? 'liquidación hecha' : 'liquidaciones hechas'} en el programa (son el historial legal).</${Aviso}>`
      : html`<div class="opciones">
        ${!retirado && html`<button class="opcion" id="el-se-fue" onClick=${() => setPaso('retiro')}><b>Ya no trabaja en la empresa</b>
          <span>Renunció, lo despidieron o se terminó el contrato. Sale de la lista de activos y de las liquidaciones, pero su historia se guarda (la ley exige conservarla). Si vuelve, se puede volver a contratar.</span></button>`}
        <button class="opcion" id="el-error" disabled=${nLiq === null || conLiq} style=${conLiq ? 'opacity:.55;cursor:not-allowed' : ''} onClick=${() => setPaso('borrar')}><b>Se cargó por error</b>
          <span>${nLiq === null ? 'Revisando…' : conLiq ? `No se puede: tiene ${nLiq} ${nLiq === 1 ? 'liquidación hecha' : 'liquidaciones hechas'} en el programa (son el historial legal).` : 'Nunca trabajó aquí o quedó repetido. Se borra del todo. Lo que tenga en "Pagado antes del programa" no se borra.'}</span></button>
      </div>`}
    </div>
  </${Modal}>`;
}

// Alguien que se retiró vuelve a trabajar: contrato nuevo con la misma cédula (el anterior queda con su historia).
function FormReingreso({ trab, onCerrar }) {
  const [f, setF] = useState({ fecha_ingreso: '', salario: null, salario_minimo: 0 });
  const [minimo, setMinimo] = useState(null);
  useEffect(() => { api('/api/parametros').then((ps) => setMinimo(ps.find((p) => p.anio === Number(hoy().slice(0, 4)))?.smmlv ?? null)).catch(() => {}); }, []);
  const guardar = async () => {
    try {
      const r = await api(`/api/trabajadores/${trab.id}/reingreso`, { metodo: 'POST', cuerpo: f });
      avisar('Listo: quedó con un contrato nuevo', 'ok');
      ir('/trabajador/' + r.id);
    } catch (e) { avisar(e.message, 'error'); }
  };
  return html`<${Modal} titulo=${'Volver a contratar a ' + trab.nombre} sub=${`Se le abre un contrato nuevo con la misma cédula. El anterior (del ${fCorta(trab.fecha_ingreso)} al ${fCorta(trab.fecha_retiro)}) queda cerrado con todas sus liquidaciones. Lo nuevo se cuenta desde la nueva fecha de ingreso.`}
    onCerrar=${onCerrar} pie=${html`<button class="btn" onClick=${onCerrar}>Cancelar</button><button class="btn primario" disabled=${!f.fecha_ingreso || !f.salario} onClick=${guardar}>Crear el contrato nuevo</button>`}>
    <div class="campos">
      <${Campo} etiqueta="Fecha en que vuelve a entrar" requerido id="ri-f"><input id="ri-f" type="date" min=${trab.fecha_retiro} value=${f.fecha_ingreso} onInput=${(e) => setF({ ...f, fecha_ingreso: e.target.value })} /></${Campo}>
      <${Campo} etiqueta="Salario mensual" requerido id="ri-s"><${InputPesos} id="ri-s" valor=${f.salario} onCambio=${(v) => setF({ ...f, salario: v, salario_minimo: minimo && v === minimo ? 1 : 0 })} /></${Campo}>
      <div class="campo" style="align-self:end"><label class="check"><input type="checkbox" checked=${!!f.salario_minimo} onChange=${(e) => setF({ ...f, salario_minimo: e.target.checked ? 1 : 0, ...(e.target.checked && minimo ? { salario: minimo } : {}) })} /><span>Gana el salario mínimo</span></label></div>
    </div>
  </${Modal}>`;
}

export function FormRango({ trab, tipo, onCerrar, onListo }) {
  const vac = tipo === 'vacaciones';
  const [f, setF] = useState({ desde: '', hasta: '', dias_habiles: '', tipo: 'licencia_no_remunerada', nota: '' });
  const guardar = async () => {
    try { await api(`/api/trabajadores/${trab.id}/${vac ? 'vacaciones' : 'novedades'}`, { metodo: 'POST', cuerpo: f }); avisar('Guardado', 'ok'); onListo(); } catch (e) { avisar(e.message, 'error'); }
  };
  return html`<${Modal} titulo=${vac ? 'Registrar vacaciones que tomó' : 'Registrar días no pagados'}
    sub=${vac ? 'Para llevar la cuenta de cuántos días le quedan.' : 'Licencias no remuneradas o suspensiones disciplinarias. Esos días no cuentan para cesantías ni vacaciones. Las incapacidades, licencias de maternidad y faltas sueltas NO van aquí (las faltas se descuentan del sueldo por nómina).'}
    onCerrar=${onCerrar} pie=${html`<button class="btn" onClick=${onCerrar}>Cancelar</button><button class="btn primario" onClick=${guardar}>Guardar</button>`}>
    <div class="campos">
      ${!vac && html`<${Campo} etiqueta="Tipo" id="rg-t" ancho><select id="rg-t" value=${f.tipo} onChange=${(e) => setF({ ...f, tipo: e.target.value })}>
        <option value="licencia_no_remunerada">Licencia no remunerada</option><option value="suspension">Suspensión disciplinaria</option></select></${Campo}>`}
      <${Campo} etiqueta="Desde" requerido id="rg-d"><input id="rg-d" type="date" value=${f.desde} onInput=${(e) => setF({ ...f, desde: e.target.value })} /></${Campo}>
      <${Campo} etiqueta="Hasta" requerido id="rg-h"><input id="rg-h" type="date" value=${f.hasta} onInput=${(e) => setF({ ...f, hasta: e.target.value })} /></${Campo}>
      ${vac && html`<${Campo} etiqueta="Días hábiles disfrutados" requerido id="rg-dh" ayuda="Sin contar domingos ni festivos. Un periodo completo son 15."><input id="rg-dh" inputmode="decimal" value=${f.dias_habiles} onInput=${(e) => setF({ ...f, dias_habiles: e.target.value })} /></${Campo}>`}
      <${Campo} etiqueta="Nota (opcional)" id="rg-n" ancho><input id="rg-n" value=${f.nota} onInput=${(e) => setF({ ...f, nota: e.target.value })} /></${Campo}>
    </div>
  </${Modal}>`;
}

export function FichaTrabajador({ id }) {
  const { datos, error, cargando, recargar } = useDatos('/api/trabajadores/' + id);
  const [modal, setModal] = useState(null);
  const [anio, setAnio] = useState('');
  const bit = useDatos(modal === 'bitacora' ? `/api/bitacora?trabajador_id=${id}` : null, [modal]);
  if (cargando && !datos) return html`<${Cargando} />`;
  if (error) return html`<${Aviso} tipo="bad">${error}</${Aviso}>`;
  const { trabajador: t, estado: e, salarios, novedades, vacaciones, liquidaciones, periodos, nomina_meses } = datos;
  const retirado = !!t.fecha_retiro;
  const integral = t.tipo_salario === 'integral';
  const anios = [...new Set(liquidaciones.map((l) => l.fecha.slice(0, 4)))];
  const liqs = liquidaciones.filter((l) => !anio || l.fecha.startsWith(anio));
  const cerrar = () => setModal(null);
  const listo = () => { setModal(null); recargar(); };
  const deshacerRetiro = async () => {
    if (!(await confirmar({ titulo: 'Deshacer el retiro', texto: `${t.nombre} vuelve a quedar activo, como si no se hubiera ido. Queda anotado en el registro de cambios.`, boton: 'Deshacer' }))) return;
    try { await api(`/api/trabajadores/${t.id}/deshacer-retiro`, { metodo: 'POST' }); avisar('Vuelve a quedar activo', 'ok'); recargar(); } catch (err) { avisar(err.message, 'error'); }
  };
  const borrar = async (tipo, rid) => {
    if (!(await confirmar({ titulo: '¿Borrar este registro?', texto: 'Queda anotado en el registro de cambios.', boton: 'Borrar', peligro: true }))) return;
    try { await api(`/api/${tipo}/${rid}`, { metodo: 'DELETE' }); recargar(); } catch (err) { avisar(err.message, 'error'); }
  };
  const per = (k) => periodos.filter((p) => p.concepto === k).sort((a, b) => (a.hasta < b.hasta ? -1 : 1));
  // Vacaciones registradas a mano + las pagadas con comprobante de "vacaciones disfrutadas"
  const tomadas = [
    ...vacaciones.map((v) => ({ clave: 'v' + v.id, id: v.id, desde: v.desde, hasta: v.hasta, dias: v.dias_habiles })),
    ...periodos.filter((p) => p.concepto === 'vacaciones_disfrutadas').map((p) => ({ clave: 'l' + p.liquidacion_id, desde: p.desde, hasta: p.hasta, dias: p.dias, consecutivo: p.consecutivo, liquidacion_id: p.liquidacion_id })),
  ].sort((a, b) => (a.desde < b.desde ? 1 : -1));

  return html`<div class="pila">
    <div class="migas"><a href="#/trabajadores">Trabajadores</a> › ${t.nombre}</div>
    <div class="encabezado">
      <div>
        <h1>${t.nombre} ${retirado ? html`<span class="chip" style="vertical-align:middle">Retirado</span>` : html`<span class="chip ok" style="vertical-align:middle">Activo</span>`}</h1>
        <p class="sub">${t.tipo_documento} ${t.documento} · ${t.cargo || 'Sin cargo'}${t.sede ? ' · ' + t.sede : ''} · Ingresó el ${fLarga(t.fecha_ingreso)}${e ? ' · ' + tiempoServicio(t.fecha_ingreso, e.corte) : ''}</p>
        ${retirado && html`<p class="sub">Se retiró el ${fLarga(t.fecha_retiro)} — ${MOTIVOS[t.motivo_retiro] || t.motivo_retiro || ''}${datos.retiro_por_fuera ? html` · <span class="chip">se le liquidó por fuera del programa</span> <button class="btn link" onClick=${deshacerRetiro}>Deshacer el retiro</button>` : ''}</p>`}
        ${datos.otros_contratos?.length > 0 && html`<p class="sub" id="otros-contratos">Otros contratos con esta cédula: ${datos.otros_contratos.map((o, i) => html`${i ? ' · ' : ''}<a href=${'#/trabajador/' + o.id}>del ${fCorta(o.fecha_ingreso)} ${o.fecha_retiro ? 'al ' + fCorta(o.fecha_retiro) : '(activo)'}</a>`)}</p>`}
      </div>
      <div class="fila">
        <button class="btn" onClick=${() => setModal('editar')}><${Icono} n="lapiz" />Editar datos</button>
        <a class="btn" href=${'#/certificado/' + t.id}><${Icono} n="imprimir" />Certificado laboral</a>
        ${(!retirado || !liquidaciones.length) && html`<button class="btn peligro" onClick=${() => setModal('eliminar')}><${Icono} n="basura" />Eliminar</button>`}
        ${!retirado && html`<a class="btn primario" href=${`#/liquidar?t=${t.id}`}><${Icono} n="calculadora" />Liquidar</a>`}
        ${retirado && !datos.otros_contratos?.some((o) => !o.fecha_retiro) && html`<button class="btn primario" onClick=${() => setModal('reingreso')}><${Icono} n="mas" />Volver a contratar</button>`}
      </div>
    </div>

    ${datos.error_estado && html`<${Aviso} tipo="bad">${datos.error_estado}</${Aviso}>`}
    ${!salarios.length && html`<${Aviso} tipo="bad">No tiene salario registrado. Regístrelo abajo para poder liquidarle.</${Aviso}>`}

    ${datos.retiro_por_fuera ? html`<${Aviso} tipo="info"><b>Se retiró el ${fLarga(t.fecha_retiro)} y se le liquidó por fuera del programa.</b> Por eso aquí no se muestran días ni vacaciones pendientes. Si en realidad no se le pagó todo, use "Deshacer el retiro" (arriba) y hágale la liquidación definitiva en el programa.</${Aviso}>`
      : e && html`<div class="panel"><div class="panel-cab"><div><h2>Hasta dónde se le ha liquidado</h2><p class="small muted">Con corte al ${fLarga(e.corte)}.</p></div>
        <div class="leyenda"><span style="--c:#e4572e">Liquidado en el programa</span><span style="--c:#f6bf96">Liquidado antes (dato inicial)</span><span style="--c:#ece7e3">Sin liquidar</span></div></div>
      <div class="panel-cuerpo"><div class="estado-grid">
        <${TarjetaPeriodo} tipo="cesantias" titulo="Cesantías e intereses" hasta=${e.cesantias_hasta} origen=${e.cesantias_origen} diasPend=${e.cesantias_dias_pendientes} ingreso=${t.fecha_ingreso} corte=${e.corte} periodos=${per('cesantias')} noAplica=${integral} huecos=${e.cesantias_huecos} liquidar=${!retirado && `#/liquidar?t=${t.id}&tipo=cesantias`} />
        <${TarjetaPeriodo} tipo="prima" titulo="Prima de servicios" hasta=${e.prima_hasta} origen=${e.prima_origen} diasPend=${e.prima_dias_pendientes} ingreso=${t.fecha_ingreso} corte=${e.corte} periodos=${per('prima')} noAplica=${integral} huecos=${e.prima_huecos} liquidar=${!retirado && `#/liquidar?t=${t.id}&tipo=prima`} />
        <div class=${'estado' + (e.vacaciones.pendientes >= 30 ? ' alerta' : '')}>
          <div class="t">Vacaciones</div>
          <div class="v">${num(e.vacaciones.pendientes, 2)} días pendientes</div>
          <div class="d">
            ${e.vacaciones.saldo_fecha ? html`Saldo inicial ${num(e.vacaciones.saldo_inicial)} al ${fCorta(e.vacaciones.saldo_fecha)} · ` : ''}
            Ganados ${num(e.vacaciones.causados)} · Tomados ${num(e.vacaciones.disfrutados)}${e.vacaciones.compensados ? ` · Pagados en dinero ${num(e.vacaciones.compensados)}` : ''}
            ${e.vacaciones.pendientes >= 30 && html`<br /><b>Tiene más de 2 periodos acumulados.</b>`}
          </div>
          <div class="fila" style="margin-top:10px;gap:6px;flex-wrap:wrap">
            ${!retirado && html`<a class="btn chico primario" href=${`#/liquidar?t=${t.id}&tipo=disfrute`}>Liquidar vacaciones que va a tomar</a>`}
            <button class="btn chico" onClick=${() => setModal('vacaciones')} title="Las que ya tomó y se pagaron por fuera del programa"><${Icono} n="mas" />Registrar las ya tomadas</button>
          </div>
        </div>
      </div></div>
    </div>`}

    <div class="panel">
      <div class="panel-cab"><h2>Historial de liquidaciones</h2>
        ${anios.length > 1 && html`<div class="segmentado"><button class=${!anio ? 'activo' : ''} onClick=${() => setAnio('')}>Todas</button>${anios.map((a) => html`<button class=${anio === a ? 'activo' : ''} onClick=${() => setAnio(a)}>${a}</button>`)}</div>`}
      </div>
      ${liqs.length === 0 ? html`<div class="vacio"><b>Todavía no tiene liquidaciones en el programa</b>${!retirado && html`<a class="btn primario" style="margin-top:10px" href=${`#/liquidar?t=${t.id}`}>Hacer la primera</a>`}</div>` : html`<table class="tabla">
        <thead><tr><th>N.º</th><th>Fecha</th><th>Qué se liquidó</th><th>Periodo</th><th class="num">Al trabajador</th><th class="num">Al fondo</th><th></th></tr></thead>
        <tbody>${liqs.map((l) => html`<tr class=${'fila-click' + (l.estado === 'anulada' ? ' anulada' : '')} tabindex="0" key=${l.id} onClick=${() => ir('/liquidacion/' + l.id)} onKeyDown=${(ev) => ev.key === 'Enter' && ir('/liquidacion/' + l.id)}>
          <td>${l.consecutivo}</td><td class="nowrap">${fCorta(l.fecha)}</td><td>${etiquetaTipo(l.tipo, l.conceptos_lista)}</td>
          <td class="nowrap">${l.tipo === 'vacaciones' ? 'Corte ' + fCorta(l.hasta) : `${fCorta(l.desde)} → ${fCorta(l.hasta)}`}</td>
          <td class="num">${pesos(l.neto)}</td><td class="num">${l.a_fondo ? pesos(l.a_fondo) : '—'}</td>
          <td>${l.estado === 'anulada' ? html`<span class="chip bad">Anulada</span>` : ''}</td>
        </tr>`)}</tbody></table>`}
    </div>

    ${datos.historicas?.length > 0 && html`<div class="panel" id="pagado-antes">
      <div class="panel-cab"><div><h2>Pagado antes del programa</h2><p class="small muted">Lo que figura en los Excel de la empresa con su cédula, tal cual (no se recalcula).</p></div></div>
      <table class="tabla"><thead><tr><th>Qué</th><th>Periodo</th><th class="num">Días</th><th class="num">Base</th><th class="num">Valor</th><th class="num">Al trabajador</th></tr></thead>
        <tbody>${datos.historicas.map((h) => html`<tr key=${h.id}>
          <td>${{ prima: 'Prima', cesantias: 'Cesantías e intereses', vacaciones: 'Vacaciones', otro: 'Otro pago' }[h.concepto]}${h.observacion ? html`<div class="doc">${h.observacion}</div>` : ''}</td>
          <td class="nowrap">${h.desde ? fCorta(h.desde) : '¿?'} → ${fCorta(h.hasta)}</td>
          <td class="num">${h.dias ?? ''}</td><td class="num">${h.base != null ? pesos(h.base) : ''}</td>
          <td class="num">${pesos(h.valor)}${h.intereses ? html`<div class="doc">+ ${pesos(h.intereses)} intereses</div>` : ''}${h.fondo ? html`<div class="doc">al fondo ${h.fondo}</div>` : ''}</td>
          <td class="num">${pesos(h.concepto === 'cesantias' ? (h.intereses || 0) : h.neto != null ? h.neto : h.valor - (h.descuentos || 0))}</td>
        </tr>`)}</tbody></table>
    </div>`}

    <div class="dos-col">
      <div class="panel">
        <div class="panel-cab"><h2>Salario</h2><button class="btn chico" onClick=${() => setModal('salario')}><${Icono} n="mas" />Registrar cambio</button></div>
        <table class="tabla"><thead><tr><th>Desde</th><th class="num">Salario mensual</th><th>Nota</th><th></th></tr></thead>
          <tbody>${salarios.map((s, i) => html`<tr key=${s.id}><td>${fCorta(s.vigente_desde)}${i === 0 ? html` <span class="chip brand">Actual</span>` : ''}</td><td class="num">${pesos(s.salario)}</td><td class="small muted">${s.nota || ''}</td>
            <td>${salarios.length > 1 && html`<button class="btn link small" onClick=${() => borrar('salarios', s.id)}>Borrar</button>`}</td></tr>`)}</tbody></table>
        <div class="panel-cuerpo small muted">Tipo de salario: <b>${{ fijo: 'Fijo', variable: 'Variable', integral: 'Integral' }[t.tipo_salario]}</b>.${Number(t.salario_minimo) ? html` <b>Gana el mínimo</b>: cada año se toma el mínimo vigente.` : ''}
          ${nomina_meses?.n ? (nomina_meses.n === 1 ? ` Hay 1 mes de nómina cargado (${nomina_meses.desde})` : ` Hay ${nomina_meses.n} meses de nómina cargados (${nomina_meses.desde} a ${nomina_meses.hasta})`) + ' para promediar horas extra y comisiones.' : t.tipo_salario === 'variable' ? html` <b style="color:var(--warn)">No hay nómina cargada para promediar lo variable.</b> <a href="#/importar">Importarla</a>.` : ''}</div>
      </div>
      <div class="panel">
        <div class="panel-cab"><h2>Días no pagados</h2><button class="btn chico" onClick=${() => setModal('novedad')}><${Icono} n="mas" />Registrar</button></div>
        ${novedades.length === 0 ? html`<div class="panel-cuerpo small muted">Ninguno. Aquí van licencias no remuneradas y suspensiones: se descuentan de cesantías y vacaciones.</div>` : html`<table class="tabla"><thead><tr><th>Tipo</th><th>Desde</th><th>Hasta</th><th class="num">Días</th><th></th></tr></thead>
          <tbody>${novedades.map((n) => html`<tr key=${n.id}><td>${{ licencia_no_remunerada: 'Licencia no remunerada', suspension: 'Suspensión', ausencia: 'Ausencia (no rebaja prestaciones)' }[n.tipo]}${n.nota ? html`<div class="doc">${n.nota}</div>` : ''}</td><td class="nowrap">${fCorta(n.desde)}</td><td class="nowrap">${fCorta(n.hasta)}</td><td class="num">${diasAusencia(n.desde, n.hasta)}</td>
            <td><button class="btn link small" onClick=${() => borrar('novedades', n.id)}>Borrar</button></td></tr>`)}</tbody></table>`}
        ${tomadas.length > 0 && html`<div class="panel-cab" style="border-top:1px solid var(--line)"><h3>Vacaciones tomadas</h3></div>
          <table class="tabla"><thead><tr><th>Desde</th><th>Hasta</th><th class="num">Días hábiles</th><th></th></tr></thead>
          <tbody>${tomadas.map((v) => html`<tr key=${v.clave}><td class="nowrap">${fCorta(v.desde)}</td><td class="nowrap">${fCorta(v.hasta)}</td><td class="num">${num(v.dias)}</td>
            <td>${v.liquidacion_id ? html`<a class="small" href=${'#/liquidacion/' + v.liquidacion_id}>N.º ${v.consecutivo}</a>` : html`<button class="btn link small" onClick=${() => borrar('vacaciones', v.id)}>Borrar</button>`}</td></tr>`)}</tbody></table>`}
      </div>
    </div>

    <div class="fila entre"><button class="btn link" onClick=${() => setModal('bitacora')}>Ver todos los cambios registrados de este trabajador</button></div>

    ${modal === 'editar' && html`<${FormTrabajador} inicial=${t} onCerrar=${cerrar} onGuardado=${listo} />`}
    ${modal === 'salario' && html`<${FormSalario} trab=${t} onCerrar=${cerrar} onListo=${listo} />`}
    ${modal === 'reingreso' && html`<${FormReingreso} trab=${t} onCerrar=${cerrar} />`}
    ${modal === 'eliminar' && html`<${EliminarTrabajador} trab=${t} onCerrar=${cerrar} onListo=${listo} onBorrado=${() => ir('/trabajadores')} />`}
    ${modal === 'novedad' && html`<${FormRango} trab=${t} tipo="novedad" onCerrar=${cerrar} onListo=${listo} />`}
    ${modal === 'vacaciones' && html`<${FormRango} trab=${t} tipo="vacaciones" onCerrar=${cerrar} onListo=${listo} />`}
    ${modal === 'bitacora' && html`<${Modal} ancho titulo="Cambios registrados" sub=${t.nombre} onCerrar=${cerrar}>
      ${!bit.datos ? html`<${Cargando} />` : bit.datos.length === 0 ? html`<p class="muted">Sin registros.</p>` : html`<table class="tabla"><thead><tr><th>Fecha</th><th>Quién</th><th>Qué</th></tr></thead>
        <tbody>${bit.datos.map((b) => html`<tr key=${b.id}><td class="nowrap small">${b.fecha}</td><td class="small">${b.usuario || '—'}</td><td class="small">${b.accion}</td></tr>`)}</tbody></table>`}
    </${Modal}>`}
  </div>`;
}
