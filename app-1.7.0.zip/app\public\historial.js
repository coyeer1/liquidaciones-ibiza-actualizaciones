import { html, useState } from './vendor/preact-htm.js';
import { pesos, fCorta, hoy, ir, qs, TIPOS, etiquetaTipo, descargarExcel, millones } from './util.js';
import { Icono, Cargando, Aviso, useDatos } from './comp.js';

export function Historial({ query }) {
  const y = Number(hoy().slice(0, 4));
  const [modo, setModo] = useState(query.lote ? 'todo' : query.anio ? 'anio' : 'anio');
  const [anio, setAnio] = useState(Number(query.anio) || y);
  const [desde, setDesde] = useState(`${y}-01-01`);
  const [hasta, setHasta] = useState(hoy());
  const [campo, setCampo] = useState('fecha');
  const [tipo, setTipo] = useState('');
  const [sede, setSede] = useState('');
  const [q, setQ] = useState('');
  const [anuladas, setAnuladas] = useState(false);
  const lote = query.lote || '';
  const sedes = useDatos('/api/sedes');

  const rango = modo === 'anio' ? [`${anio}-01-01`, `${anio}-12-31`] : modo === 'rango' ? [desde, hasta] : ['', ''];
  const ruta = '/api/liquidaciones?' + qs({ desde: rango[0], hasta: rango[1], campo, tipo, sede, q, lote, estado: anuladas ? 'todas' : '' });
  const { datos, cargando, error } = useDatos(ruta);
  const filas = datos?.filas || [];
  const tot = datos?.totales;
  const anios = [];
  for (let a = y + 1; a >= y - 10; a--) anios.push(a);

  const descripcion = modo === 'anio' ? `año ${anio}` : modo === 'rango' ? `del ${fCorta(desde)} al ${fCorta(hasta)}` : 'todas las fechas';
  const excel = () => {
    const cab = ['N.º', 'Fecha', 'Estado', 'Documento', 'Trabajador', 'Sede', 'Cargo', 'Tipo', 'Desde', 'Hasta', 'Cesantías', 'Intereses', 'Prima', 'Vacaciones', 'Indemnización', 'Otros pagos', 'Descuentos', 'Al fondo', 'Al trabajador', 'Elaboró', 'Motivo de anulación'];
    const cuerpo = filas.map((f) => [f.consecutivo, f.fecha, f.estado === 'anulada' ? 'ANULADA' : 'Vigente', f.documento, f.nombre, f.sede || '', f.cargo || '', etiquetaTipo(f.tipo, f.conceptos_lista), f.desde || '', f.hasta, f.cesantias, f.intereses, f.prima, f.vacaciones, f.indemnizacion, f.otros, f.deducciones, f.a_fondo, f.neto, f.creado_por || '', f.anulada_motivo || '']);
    const total = ['', '', '', '', 'TOTAL (sin anuladas)', '', '', '', '', '', tot.cesantias, tot.intereses, tot.prima, tot.vacaciones, tot.indemnizacion, tot.otros, tot.deducciones, tot.a_fondo, tot.neto, '', ''];
    const titulo = [[`Historial de liquidaciones — ${descripcion}${campo === 'periodo' ? ' (por periodo liquidado)' : ''}`], [`Descargado el ${hoy()}`], []];
    const todas = [...titulo, cab, ...cuerpo, total];
    descargarExcel(`liquidaciones-${modo === 'anio' ? anio : hoy()}.xlsx`, [{
      nombre: 'Liquidaciones', filas: todas, filaEncabezado: 3, dinero: [10, 11, 12, 13, 14, 15, 16, 17, 18],
      anchos: [7, 11, 10, 13, 30, 16, 18, 24, 11, 11, 13, 12, 13, 13, 13, 12, 12, 13, 14, 14, 30],
      negrita: (r) => r === todas.length - 1, finFiltro: todas.length - 2,
    }]);
  };

  return html`<div class="pila">
    <div class="encabezado">
      <div><h1>Historial</h1><p class="sub">Todo lo liquidado queda aquí. Filtre por año o entre dos fechas.</p></div>
      <button class="btn" onClick=${excel} disabled=${!filas.length}><${Icono} n="excel" />Descargar en Excel</button>
    </div>
    ${lote && html`<${Aviso} tipo="info">Mostrando solo un grupo liquidado a la vez. <a href="#/historial">Ver todo el historial</a></${Aviso}>`}
    <div class="panel"><div class="panel-cuerpo pila">
      <div class="fila">
        <div class="segmentado" role="group" aria-label="Periodo">
          <button class=${modo === 'anio' ? 'activo' : ''} onClick=${() => setModo('anio')}>Por año</button>
          <button class=${modo === 'rango' ? 'activo' : ''} onClick=${() => setModo('rango')}>Entre fechas</button>
          <button class=${modo === 'todo' ? 'activo' : ''} onClick=${() => setModo('todo')}>Todo</button>
        </div>
        ${modo === 'anio' && html`<select style="width:auto" value=${anio} onChange=${(e) => setAnio(Number(e.target.value))} aria-label="Año">${anios.map((a) => html`<option value=${a}>${a}</option>`)}</select>`}
        ${modo === 'rango' && html`<label class="fila small" style="gap:6px">Del <input type="date" style="width:auto" value=${desde} onInput=${(e) => setDesde(e.target.value)} /></label>
          <label class="fila small" style="gap:6px">al <input type="date" style="width:auto" value=${hasta} onInput=${(e) => setHasta(e.target.value)} /></label>`}
        ${modo !== 'todo' && html`<select style="width:auto" value=${campo} onChange=${(e) => setCampo(e.target.value)} aria-label="Qué fecha mirar">
          <option value="fecha">según la fecha en que se hizo</option><option value="periodo">según el periodo que se pagó</option></select>`}
      </div>
      <div class="fila">
        <input type="search" style="max-width:300px" placeholder="Nombre, cédula o N.º…" value=${q} onInput=${(e) => setQ(e.target.value)} aria-label="Buscar" />
        <select style="width:auto" value=${tipo} onChange=${(e) => setTipo(e.target.value)} aria-label="Tipo"><option value="">Todos los tipos</option>${Object.entries(TIPOS).map(([k, v]) => html`<option value=${k}>${v}</option>`)}<option value="varios">Varias a la vez</option></select>
        ${sedes.datos?.length > 0 && html`<select style="width:auto" value=${sede} onChange=${(e) => setSede(e.target.value)} aria-label="Sede"><option value="">Todas las sedes</option>${sedes.datos.map((s) => html`<option>${s}</option>`)}</select>`}
        <label class="check small"><input type="checkbox" checked=${anuladas} onChange=${(e) => setAnuladas(e.target.checked)} />Mostrar anuladas</label>
      </div>
    </div></div>

    ${tot && filas.length > 0 && html`<div class="tarjetas">
      <div class="tarjeta"><div class="t">Liquidaciones</div><div class="v">${filas.filter((f) => f.estado === 'vigente').length}</div><div class="d">${descripcion}</div></div>
      <div class="tarjeta"><div class="t">Liquidado para los trabajadores</div><div class="v">${millones(tot.neto)}</div><div class="d">${pesos(tot.neto)}</div></div>
      <div class="tarjeta"><div class="t">Liquidado para los fondos</div><div class="v">${millones(tot.a_fondo)}</div><div class="d">${pesos(tot.a_fondo)}</div></div>
      <div class="tarjeta"><div class="t">Por concepto</div><div class="d" style="margin-top:6px;line-height:1.6">
        ${tot.cesantias ? html`Cesantías ${pesos(tot.cesantias)}<br />` : ''}${tot.intereses ? html`Intereses ${pesos(tot.intereses)}<br />` : ''}${tot.prima ? html`Prima ${pesos(tot.prima)}<br />` : ''}${tot.vacaciones ? html`Vacaciones ${pesos(tot.vacaciones)}<br />` : ''}${tot.indemnizacion ? html`Indemnizaciones ${pesos(tot.indemnizacion)}` : ''}
      </div></div>
    </div>`}

    <div class="panel">
      ${error ? html`<div class="panel-cuerpo"><${Aviso} tipo="bad">${error}</${Aviso}></div>` : cargando && !datos ? html`<${Cargando} />` : filas.length === 0 ? html`<div class="vacio"><b>No hay liquidaciones ${descripcion !== 'todas las fechas' ? 'en ' + descripcion : ''}</b>Pruebe con otro año u otras fechas.</div>` : html`<div class="tabla-scroll" style="max-height:none"><table class="tabla">
        <thead><tr><th>N.º</th><th>Fecha</th><th>Trabajador</th><th>Qué se liquidó</th><th>Periodo</th><th class="num">Al fondo</th><th class="num">Al trabajador</th></tr></thead>
        <tbody>${filas.map((f) => html`<tr key=${f.id} class=${'fila-click' + (f.estado === 'anulada' ? ' anulada' : '')} tabindex="0" onClick=${() => ir('/liquidacion/' + f.id)} onKeyDown=${(e) => e.key === 'Enter' && ir('/liquidacion/' + f.id)}>
          <td>${f.consecutivo}</td><td class="nowrap">${fCorta(f.fecha)}</td>
          <td><b>${f.nombre}</b><div class="doc">${f.documento}${f.sede ? ' · ' + f.sede : ''}</div></td>
          <td>${etiquetaTipo(f.tipo, f.conceptos_lista)} ${f.estado === 'anulada' && html`<span class="chip bad">Anulada</span>`}</td>
          <td class="nowrap">${f.tipo === 'vacaciones' ? 'Corte ' + fCorta(f.hasta) : `${fCorta(f.desde)} → ${fCorta(f.hasta)}`}</td>
          <td class="num">${f.a_fondo ? pesos(f.a_fondo) : '—'}</td><td class="num"><b>${pesos(f.neto)}</b></td>
        </tr>`)}</tbody></table></div>`}
    </div>
  </div>`;
}
