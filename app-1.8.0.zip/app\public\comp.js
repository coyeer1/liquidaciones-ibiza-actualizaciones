// Piezas de pantalla compartidas.
import { html, useState, useEffect, useRef } from './vendor/preact-htm.js';
import { api, pesos, leerPesos, fCorta } from './util.js';

// ---------- iconos (trazos simples, 24×24) ----------
const P = {
  inicio: 'M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z',
  personas: 'M16 19v-1a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v1M9.5 10a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7M21 19v-1a4 4 0 0 0-3-3.87M15.5 3.13a3.5 3.5 0 0 1 0 6.75',
  calculadora: 'M6 2h12a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2zM8 6h8M8 11h.01M12 11h.01M16 11h.01M8 15h.01M12 15h.01M16 15h.01M8 19h.01M12 19h4',
  grupo: 'M4 6h16M4 12h16M4 18h10',
  historial: 'M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5M12 7v5l3 3',
  importar: 'M12 3v12M7 10l5 5 5-5M5 21h14',
  ajustes: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z',
  lista: 'M9 6h11M9 12h11M9 18h11M4 6h.01M4 12h.01M4 18h.01',
  mas: 'M12 5v14M5 12h14',
  x: 'M18 6L6 18M6 6l12 12',
  alerta: 'M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0zM12 9v4M12 17h.01',
  info: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 16v-4M12 8h.01',
  ok: 'M20 6L9 17l-5-5',
  imprimir: 'M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2M6 14h12v8H6z',
  excel: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M8 13l4 5M12 13l-4 5',
  atras: 'M19 12H5M12 19l-7-7 7-7',
  lapiz: 'M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z',
  carpeta: 'M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z',
  descargar: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3',
  subir: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12',
  reloj: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 6v6l4 2',
  usuario: 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8',
  basura: 'M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6',
  escudo: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
  documento: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M16 13H8M16 17H8M10 9H8',
  buscar: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zM21 21l-4.35-4.35',
  escritorio: 'M2 3h20v14H2zM8 21h8M12 17v4',
};
export function Icono({ n, ...resto }) {
  return html`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" ...${resto}><path d=${P[n]} /></svg>`;
}

// ---------- avisos flotantes ----------
let oyenteToast = null;
export function avisar(texto, tipo = '') {
  oyenteToast?.({ id: Math.random(), texto, tipo });
}
export function Toasts() {
  const [lista, setLista] = useState([]);
  useEffect(() => {
    oyenteToast = (t) => {
      setLista((l) => [...l, t]);
      setTimeout(() => setLista((l) => l.filter((x) => x.id !== t.id)), t.tipo === 'error' ? 7000 : 3500);
    };
    return () => { oyenteToast = null; };
  }, []);
  return html`<div class="toasts" role="status" aria-live="polite">${lista.map((t) => html`<div class=${'toast ' + t.tipo} key=${t.id}>${t.texto}</div>`)}</div>`;
}

// ---------- ventana modal ----------
export function Modal({ titulo, sub, onCerrar, children, pie, ancho }) {
  const ref = useRef();
  useEffect(() => {
    const k = (e) => { if (e.key === 'Escape') onCerrar?.(); };
    document.addEventListener('keydown', k);
    const primero = ref.current?.querySelector('input:not([type=hidden]), select, textarea');
    primero?.focus();
    return () => document.removeEventListener('keydown', k);
  }, []);
  return html`<div class="velo" onMouseDown=${(e) => { if (e.target === e.currentTarget) onCerrar?.(); }}>
    <div class=${'modal' + (ancho ? ' ancho' : '')} role="dialog" aria-modal="true" aria-label=${titulo} ref=${ref}>
      <div class="modal-cab">
        <div><h2>${titulo}</h2>${sub && html`<p class="muted small" style="margin-top:4px">${sub}</p>`}</div>
        ${onCerrar && html`<button class="cerrar" onClick=${onCerrar} title="Cerrar" aria-label="Cerrar"><${Icono} n="x" /></button>`}
      </div>
      <div class="modal-cuerpo">${children}</div>
      ${pie && html`<div class="modal-pie">${pie}</div>`}
    </div>
  </div>`;
}

// Diálogo de confirmación que devuelve una promesa.
let oyenteConfirmar = null;
export function confirmar(op) {
  return new Promise((ok) => oyenteConfirmar?.({ ...op, ok }));
}
export function Confirmaciones() {
  const [c, setC] = useState(null);
  const [motivo, setMotivo] = useState('');
  useEffect(() => { oyenteConfirmar = (x) => { setMotivo(''); setC(x); }; return () => { oyenteConfirmar = null; }; }, []);
  if (!c) return null;
  const cerrar = (v) => { c.ok(v); setC(null); };
  const listo = !c.pedirMotivo || motivo.trim().length >= 5;
  return html`<${Modal} titulo=${c.titulo} onCerrar=${() => cerrar(false)} pie=${html`
      <button class="btn" onClick=${() => cerrar(false)}>${c.cancelar || 'Cancelar'}</button>
      <button class=${'btn ' + (c.peligro ? 'peligro lleno' : 'primario')} disabled=${!listo} onClick=${() => cerrar(c.pedirMotivo ? motivo.trim() : true)}>${c.boton || 'Aceptar'}</button>`}>
    <div class="pila">
      ${typeof c.texto === 'string' ? html`<p>${c.texto}</p>` : c.texto}
      ${c.pedirMotivo && html`<div class="campo"><label for="motivo">${c.pedirMotivo}</label>
        <textarea id="motivo" value=${motivo} onInput=${(e) => setMotivo(e.target.value)} placeholder="Ej.: se digitó mal la fecha de retiro"></textarea>
        <div class="ayuda">Queda guardado en el registro de cambios.</div></div>`}
    </div>
  </${Modal}>`;
}

// ---------- campos ----------
export function Campo({ etiqueta, ayuda, requerido, id, ancho, children }) {
  return html`<div class=${'campo' + (ancho ? ' ancho' : '')}>
    ${etiqueta && html`<label for=${id}>${etiqueta}${requerido && html` <span class="req">*</span>`}</label>`}
    ${children}
    ${ayuda && html`<div class="ayuda">${ayuda}</div>`}
  </div>`;
}

export function InputPesos({ valor, onCambio, id, placeholder, ...resto }) {
  const [txt, setTxt] = useState(valor == null || valor === '' ? '' : pesos(valor));
  const enfocado = useRef(false);
  useEffect(() => { if (!enfocado.current) setTxt(valor == null || valor === '' ? '' : pesos(valor)); }, [valor]);
  return html`<input id=${id} inputmode="numeric" placeholder=${placeholder || '$0'} value=${txt} ...${resto}
    onFocus=${() => { enfocado.current = true; }}
    onInput=${(e) => { setTxt(e.target.value); onCambio(leerPesos(e.target.value)); }}
    onBlur=${() => { enfocado.current = false; const n = leerPesos(txt); setTxt(n == null ? '' : pesos(n)); }} />`;
}

export function Aviso({ tipo = '', children }) {
  const ic = tipo === 'info' ? 'info' : tipo === 'ok' ? 'ok' : 'alerta';
  return html`<div class=${'aviso ' + tipo}><${Icono} n=${ic} /><div>${children}</div></div>`;
}

export function Cargando({ texto = 'Cargando…' }) {
  return html`<div class="cargando">${texto}</div>`;
}

// Hook para cargar datos del servidor
export function useDatos(ruta, deps = []) {
  const [estado, setEstado] = useState({ datos: null, error: null, cargando: true });
  const recargar = () => {
    if (!ruta) { setEstado({ datos: null, error: null, cargando: false }); return; }
    setEstado((e) => ({ ...e, cargando: true }));
    api(ruta).then((d) => setEstado({ datos: d, error: null, cargando: false })).catch((e) => setEstado({ datos: null, error: e.message, cargando: false }));
  };
  useEffect(recargar, [ruta, ...deps]);
  return { ...estado, recargar };
}

// ---------- buscador de trabajador ----------
export function BuscadorTrabajador({ onElegir, soloActivos = true, autoFocus }) {
  const [q, setQ] = useState('');
  const [res, setRes] = useState([]);
  const [abierto, setAbierto] = useState(false);
  const [sel, setSel] = useState(0);
  useEffect(() => {
    let vivo = true;
    const t = setTimeout(() => {
      api('/api/trabajadores?' + new URLSearchParams({ q, estado: soloActivos ? 'activos' : '' })).then((r) => { if (vivo) { setRes(r.slice(0, 30)); setSel(0); } }).catch(() => {});
    }, 150);
    return () => { vivo = false; clearTimeout(t); };
  }, [q]);
  const elegir = (t) => { setAbierto(false); setQ(''); onElegir(t); };
  return html`<div class="buscador">
    <input type="search" autoFocus=${autoFocus} placeholder="Escriba el nombre o la cédula…" value=${q} aria-label="Buscar trabajador"
      onFocus=${() => setAbierto(true)} onBlur=${() => setTimeout(() => setAbierto(false), 150)}
      onInput=${(e) => { setQ(e.target.value); setAbierto(true); }}
      onKeyDown=${(e) => {
        if (e.key === 'ArrowDown') { e.preventDefault(); setSel((s) => Math.min(s + 1, res.length - 1)); }
        if (e.key === 'ArrowUp') { e.preventDefault(); setSel((s) => Math.max(s - 1, 0)); }
        if (e.key === 'Enter' && res[sel]) { e.preventDefault(); elegir(res[sel]); }
      }} />
    ${abierto && html`<div class="resultados">
      ${res.length === 0 ? html`<div class="vacio small">${q ? 'Nadie con ese nombre o cédula.' : 'Todavía no hay trabajadores.'}</div>` :
        res.map((t, i) => html`<button key=${t.id} class=${i === sel ? 'sel' : ''} onMouseDown=${(e) => { e.preventDefault(); elegir(t); }}>
          <span><b>${t.nombre}</b><br /><span class="small muted">${t.tipo_documento} ${t.documento}${t.cargo ? ' · ' + t.cargo : ''}</span></span>
          <span class="small muted nowrap">${t.sede || ''}${t.fecha_retiro ? html`<br /><span class="chip">Retirado ${fCorta(t.fecha_retiro)}</span>` : ''}</span>
        </button>`)}
    </div>`}
  </div>`;
}
