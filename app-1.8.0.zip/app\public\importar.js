import { html, useState } from './vendor/preact-htm.js';
import { api, leerExcel, leerFecha, leerPeriodo, leerPesos, normalizar, descargarExcel, hoy, pesos, fCorta } from './util.js';
import { Icono, Aviso, avisar, confirmar } from './comp.js';

const TRAB = [
  { k: 'documento', t: 'Documento', req: true, ej: '1088123456', alias: ['documento', 'cedula', 'numero de documento', 'no documento', 'n documento', 'nro documento', 'identificacion', 'numero identificacion', 'documento de identidad', 'cc', 'id', 'num doc', 'codigocli', 'codigo empleado', 'cod empleado', 'cedula empleado'] },
  { k: 'tipo_documento', t: 'Tipo de documento', ej: 'CC', alias: ['tipo de documento', 'tipo documento', 'tipo doc', 'tipo identificacion'] },
  { k: 'nombres', t: 'Nombres', req: true, ej: 'Ana María', alias: ['nombres', 'nombre', 'primer nombre', 'nombre completo', 'nombres y apellidos', 'apellidos y nombres', 'empleado', 'trabajador', 'nombrecli', 'nombre empleado'] },
  { k: 'apellidos', t: 'Apellidos', ej: 'Gómez Ríos', alias: ['apellidos', 'apellido', 'primer apellido'] },
  { k: 'cargo', t: 'Cargo', ej: 'Asesora comercial', alias: ['cargo', 'puesto', 'oficio'] },
  { k: 'sede', t: 'Sede', ej: 'Pereira', alias: ['sede', 'sucursal', 'punto de venta', 'tienda', 'almacen', 'centro de costo', 'centro de costos'] },
  { k: 'fecha_ingreso', t: 'Fecha de ingreso', req: true, fecha: true, ej: '15/03/2021', alias: ['fecha de ingreso', 'fecha ingreso', 'ingreso', 'fecha inicio', 'fecha de inicio', 'fecha vinculacion', 'fecha de vinculacion', 'fecha contrato', 'fecha inicio contrato'] },
  { k: 'salario', t: 'Salario mensual', req: true, dinero: true, ej: 1750905, alias: ['salario', 'sueldo', 'salario basico', 'sueldo basico', 'basico', 'salario mensual', 'asignacion basica', 'salario base', 'salbasico'] },
  { k: 'salario_desde', t: 'Salario desde (fecha del último aumento)', fecha: true, ej: '01/01/2026', alias: ['salario desde', 'fecha ultimo aumento', 'fecha del ultimo aumento', 'fecha salario', 'salario vigente desde'] },
  { k: 'salario_minimo', t: 'Gana el mínimo (si o no)', ej: 'no', alias: ['gana el minimo', 'salario minimo', 'gana minimo'] },
  { k: 'tipo_salario', t: 'Tipo de salario (fijo, variable o integral)', ej: 'fijo', alias: ['tipo de salario', 'tipo salario'] },
  { k: 'auxilio_transporte', t: 'Auxilio de transporte (si o no)', ej: 'si', alias: ['auxilio de transporte', 'aux transporte', 'auxilio transporte'] },
  { k: 'fondo_cesantias', t: 'Fondo de cesantías', ej: 'Porvenir', alias: ['fondo de cesantias', 'fondo cesantias', 'cesantias fondo'] },
  { k: 'telefono', t: 'Teléfono', ej: '3001234567', alias: ['telefono', 'celular', 'tel', 'movil'] },
  { k: 'correo', t: 'Correo', ej: '', alias: ['correo', 'email', 'correo electronico', 'e mail'] },
  { k: 'cesantias_hasta_inicial', t: 'Cesantías liquidadas hasta', fecha: true, ej: '31/12/2025', alias: ['cesantias liquidadas hasta', 'cesantias pagadas hasta', 'cesantias hasta'] },
  { k: 'prima_hasta_inicial', t: 'Prima liquidada hasta', fecha: true, ej: '30/06/2026', alias: ['prima liquidada hasta', 'prima pagada hasta', 'prima hasta'] },
  { k: 'vac_saldo_dias', t: 'Días de vacaciones pendientes', ej: 7.5, alias: ['dias de vacaciones pendientes', 'vacaciones pendientes', 'dias vacaciones pendientes', 'saldo vacaciones', 'saldo de vacaciones'] },
  { k: 'vac_saldo_fecha', t: 'Vacaciones pendientes con corte a', fecha: true, ej: '30/09/2026', alias: ['vacaciones pendientes con corte a', 'vacaciones con corte a', 'fecha saldo vacaciones', 'vacaciones pendientes al'] },
];
const NOM = [
  { k: 'documento', t: 'Documento', req: true, ej: '1088123456', alias: TRAB[0].alias },
  { k: 'periodo', t: 'Mes (AAAA-MM)', req: true, periodo: true, ej: '2026-03', alias: ['mes aaaa mm', 'mes', 'periodo', 'periodo de pago', 'mes de nomina', 'fecha'] },
  { k: 'salario_basico', t: 'Salario básico', dinero: true, ej: 1750905, alias: ['salmes', 'salario basico', 'basico', 'sueldo', 'salario'] },
  { k: 'extras_recargos', t: 'Horas extra, dominicales y festivos', dinero: true, ej: 180000, alias: ['horas extra dominicales y festivos', 'horas extra y recargos', 'horas extras y recargos', 'horas extra', 'horas extras', 'extras', 'dominicales y festivos', 'dominicales'],
    // Programas que traen cada clase de hora extra en su columna: se suman
    sumar: ['valhed', 'valhedd', 'valhen', 'valhend', 'valhd', 'valhrd'] },
  { k: 'recargo_nocturno', t: 'Recargo nocturno', dinero: true, ej: 95000, alias: ['recargo nocturno', 'recargos nocturnos', 'nocturno', 'recargo nocturno ordinario', 'valhro'] },
  { k: 'comisiones', t: 'Comisiones', dinero: true, ej: 350000, alias: ['comisiones', 'comision'] },
  { k: 'otros_salariales', t: 'Otros pagos salariales', dinero: true, ej: 0, alias: ['otros pagos salariales', 'otros salariales', 'bonificaciones salariales', 'otros devengos'] },
  { k: 'auxilio_transporte', t: 'Auxilio de transporte', dinero: true, ej: 249095, alias: ['auxilio de transporte', 'aux transporte', 'auxilio transporte', 'auxtra'] },
  { k: 'dias', t: 'Días trabajados', ej: 30, alias: ['dias trabajados', 'diastra', 'dias'] },
];

function adivinar(campos, encabezados) {
  const norm = encabezados.map(normalizar);
  const map = {};
  const usados = new Set();
  for (const c of campos) {
    let i = norm.findIndex((h, j) => !usados.has(j) && c.alias.includes(h));
    if (i < 0) i = norm.findIndex((h, j) => !usados.has(j) && h && c.alias.some((a) => a.length > 3 && h.includes(a)));
    if (i >= 0) { map[c.k] = i; usados.add(i); continue; }
    const suma = columnasSuma(c, encabezados);
    if (suma.length) { map[c.k] = suma.length > 1 ? suma : suma[0]; for (const j of suma) usados.add(j); }
  }
  return map;
}

function columnasSuma(c, encabezados) {
  if (!c.sumar) return [];
  const norm = encabezados.map(normalizar);
  return norm.map((h, j) => (c.sumar.includes(h) ? j : -1)).filter((j) => j >= 0);
}

function convertir(campos, map, filas, filaInicial) {
  return filas.map((f, n) => {
    const o = { __fila: filaInicial + n };
    for (const c of campos) {
      if (map[c.k] == null) continue;
      if (Array.isArray(map[c.k])) { o[c.k] = map[c.k].reduce((a, j) => a + (leerPesos(f[j]) || 0), 0); continue; }
      let v = f[map[c.k]];
      if (c.fecha) v = leerFecha(v);
      else if (c.periodo) {
        // Si trae el día (ej. "31-Oct-26"), es una quincena o planilla: se guarda aparte y se suma con las otras del mes
        const dia = leerFecha(v);
        o.corte = /^\d{4}-\d{2}-\d{2}$/.test(dia) ? dia : '';
        v = leerPeriodo(v);
      }
      else if (c.dinero) v = leerPesos(v);
      else v = typeof v === 'number' ? String(v) : String(v ?? '').trim();
      o[c.k] = v;
    }
    if (o.tipo_salario) { const t = normalizar(o.tipo_salario); o.tipo_salario = t.includes('integral') ? 'integral' : t.includes('variable') ? 'variable' : 'fijo'; }
    // En blanco = que el programa lo decida (lo marca si el salario es el mínimo de este año)
    if (o.salario_minimo !== undefined) { const v = normalizar(o.salario_minimo); if (v) o.salario_minimo = ['si', 's', '1', 'x', 'true'].includes(v) ? 1 : 0; else delete o.salario_minimo; }
    if (o.auxilio_transporte !== undefined && typeof o.auxilio_transporte === 'string') o.auxilio_transporte = ['no', 'n', '0', 'false', 'no aplica'].includes(normalizar(o.auxilio_transporte)) ? 'no' : 'auto';
    if (o.tipo_documento) o.tipo_documento = normalizar(o.tipo_documento).toUpperCase().replace(/\s/g, '').slice(0, 5) || 'CC';
    if (o.vac_saldo_dias !== undefined) o.vac_saldo_dias = String(o.vac_saldo_dias).replace(',', '.');
    return o;
  });
}

function plantilla(cual) {
  const campos = cual === 'trabajadores' ? TRAB : NOM;
  const instr = cual === 'trabajadores'
    ? [['Cómo llenar la plantilla de trabajadores'], [], ['• Una fila por trabajador. Las columnas con * son obligatorias.'], ['• Las fechas pueden ir como 15/03/2021 o 2021-03-15.'], ['• Si el trabajador ya existe (mismo documento), se actualizan sus datos; si el salario cambió, se registra el aumento.'], ['• "Salario desde": la fecha del último aumento. Si no se pone, se supone que gana lo mismo desde que entró (y las liquidaciones de años anteriores saldrían con el sueldo de hoy).'], ['• "Gana el mínimo": si dice sí, cada año se toma el salario mínimo de ese año. Si el salario es igual al mínimo de este año, se marca solo.'],
      ['• "Cesantías liquidadas hasta" y "Prima liquidada hasta": hasta qué fecha ya se le pagó ANTES de usar el programa. Así no se le vuelve a liquidar.'], ['• "Días de vacaciones pendientes": los días hábiles que le quedan, contados a la fecha de la columna siguiente.'], ['• Se puede subir el mismo archivo varias veces: no duplica a nadie.']]
    : [['Cómo llenar la plantilla de nómina mensual'], [], ['• Una fila por trabajador y por mes. Sirve para promediar horas extra, recargos y comisiones.'], ['• El recargo nocturno va en su propia columna: cuenta para vacaciones; las horas extra y los dominicales no.'], ['• El mes va como 2026-03 (año-mes).'], ['• Si el programa de nómina saca una planilla por quincena, súbalas todas tal cual: las quincenas de un mismo mes se suman.'], ['• El trabajador tiene que existir antes (se busca por documento).'], ['• Si se sube otra vez el mismo mes (o la misma quincena), se reemplaza: no se duplica.']];
  descargarExcel(`plantilla-${cual}.xlsx`, [
    { nombre: cual === 'trabajadores' ? 'Trabajadores' : 'Nómina', filas: [campos.map((c) => c.t + (c.req ? ' *' : '')), campos.map((c) => c.ej)], anchos: campos.map((c) => Math.max(14, c.t.length + 2)), filtro: false },
    { nombre: 'Instrucciones', filas: instr, anchos: [110], filtro: false },
  ]);
}

const PARTICULAS = new Set(['de', 'del', 'la', 'las', 'los', 'san', 'y', 'da', 'van']);
const titulo = (s) => String(s || '').trim().toLocaleLowerCase('es').replace(/(^|[\s-])(\p{L})/gu, (m, a, b) => a + b.toLocaleUpperCase('es'));
// Los programas de nómina sacan "APELLIDOS NOMBRES" en una sola columna: "VILLA ZAPATA STEFANIA".
function partirNombre(completo) {
  const u = [];
  let pend = [];
  for (const w of titulo(completo).split(/\s+/).filter(Boolean)) {
    if (PARTICULAS.has(w.toLowerCase())) { pend.push(w.toLowerCase()); continue; }
    u.push([...pend, w].join(' '));
    pend = [];
  }
  if (pend.length) u.push(pend.join(' '));
  if (u.length < 2) return { nombres: u.join(' '), apellidos: '' };
  const n = u.length === 2 ? 1 : 2;
  return { apellidos: u.slice(0, n).join(' '), nombres: u.slice(n).join(' ') };
}

const docDe = (v) => String(v ?? '').replace(/[\s.]/g, '');
function contarDocumentos(hoja, map) {
  return new Set(hoja.filas.map((f) => docDe(f[map.documento])).filter(Boolean)).size;
}

// El archivo trae a los trabajadores pero no todo lo obligatorio (casi siempre falta la fecha de
// ingreso, como en la nómina de una quincena): se arma la plantilla con lo que sí trae para que
// solo llenen lo que falta.
function listaParaCompletar(hoja, map, archivo) {
  const porDoc = new Map();
  for (const o of convertir(TRAB, map, hoja.filas, hoja.filaInicial)) {
    const doc = docDe(o.documento);
    if (doc) porDoc.set(doc, { ...o, documento: doc }); // si se repite (varias quincenas), queda la última
  }
  const separar = map.apellidos == null;
  const celda = (c, o, n) => {
    if (c.k === 'nombres') return n.nombres;
    if (c.k === 'apellidos') return n.apellidos;
    if (c.k === 'salario_minimo') return o.salario_minimo == null ? '' : o.salario_minimo ? 'sí' : 'no';
    if (c.k === 'auxilio_transporte') return o.auxilio_transporte === 'no' ? 'no' : '';
    return o[c.k] ?? '';
  };
  const filas = [...porDoc.values()].map((o) => {
    const n = separar ? partirNombre(o.nombres) : { nombres: titulo(o.nombres), apellidos: titulo(o.apellidos) };
    return TRAB.map((c) => celda(c, o, n));
  });
  const llenar = ['fecha_ingreso', 'salario_desde', 'cesantias_hasta_inicial', 'prima_hasta_inicial', 'vac_saldo_dias', 'vac_saldo_fecha'];
  const amarillas = TRAB.map((c, i) => (map[c.k] == null && (c.req || llenar.includes(c.k)) ? i : -1)).filter((i) => i >= 0);
  const y = Number(hoy().slice(0, 4));
  const fmt = (f) => f.split('-').reverse().join('/');
  const prima = hoy().slice(5, 7) > '06' ? `${y}-06-30` : `${y - 1}-12-30`;
  const instr = [
    [`Lista para completar (sale de: ${archivo})`], [],
    [`• Ya vienen la cédula, el nombre y el salario de los ${filas.length} trabajadores. Llene las columnas amarillas.`],
    ['• Fecha de ingreso (obligatoria): el día en que empezó el contrato actual, como 15/03/2021.'],
    [`• Cesantías liquidadas hasta: si las del año pasado ya se consignaron al fondo, ponga ${fmt(`${y - 1}-12-30`)} (cada mes cuenta 30 días; 31/12/${y - 1} también sirve, es lo mismo). En blanco = nunca se le han liquidado.`],
    [`• Prima liquidada hasta: si ya se pagó la última prima, ponga ${fmt(prima)}. En blanco = nunca se le ha pagado.`],
    ['• Días de vacaciones pendientes y la fecha de ese saldo: si no se saben, en blanco; el programa cuenta desde el ingreso (sin descontar las que ya tomó).'],
    [`• Salario desde: la fecha del último aumento (casi siempre 01/01/${y}). Los que ganan el mínimo no la necesitan.`],
    ...(separar ? [['• El archivo traía apellidos y nombres juntos: se separaron tomando los dos primeros como apellidos. Revise los que no sean así.']] : []),
    ['• Después súbala en Importar → Trabajadores. Se puede subir varias veces: no duplica a nadie.'],
  ];
  descargarExcel('trabajadores-para-completar.xlsx', [
    { nombre: 'Trabajadores', filas: [TRAB.map((c) => c.t + (c.req ? ' *' : '')), ...filas], anchos: TRAB.map((c) => Math.max(14, c.t.length + 2)), dinero: [TRAB.findIndex((c) => c.k === 'salario')], resaltar: amarillas },
    { nombre: 'Instrucciones', filas: instr, anchos: [120], filtro: false },
  ]);
}

// Orden de la revisión: primero lo que no se importa, luego lo que pide ojo, luego lo que cambia y al final lo que queda igual.
const peso = (r) => (r.accion === 'error' ? 0 : r.aviso ? 1 : r.accion === 'igual' ? 3 : 2);

function Importador({ cual }) {
  const campos = cual === 'trabajadores' ? TRAB : NOM;
  const [archivo, setArchivo] = useState(null);
  const [hoja, setHoja] = useState(null);
  const [map, setMap] = useState({});
  const [revision, setRevision] = useState(null);
  const [ocupado, setOcupado] = useState(false);
  const [hecho, setHecho] = useState(null);
  const [fuera, setFuera] = useState([]); // activos del programa que no vienen en el archivo

  const leer = async (f) => {
    setRevision(null); setHecho(null); setFuera([]);
    if (!f) return;
    try {
      const h = await leerExcel(f);
      if (!h.filas.length) throw new Error('El archivo no trae filas con datos.');
      setArchivo(f.name); setHoja(h); setMap(adivinar(campos, h.encabezados));
    } catch (e) { avisar('No se pudo leer el archivo: ' + e.message, 'error'); }
  };
  const faltan = campos.filter((c) => c.req && map[c.k] == null);
  const revisar = async (guardar) => {
    setOcupado(true);
    try {
      const filas = convertir(campos, map, hoja.filas, hoja.filaInicial);
      const r = await api('/api/importar/' + cual, { metodo: 'POST', cuerpo: { filas, guardar } });
      if (guardar) { setHecho(r); setRevision(null); setHoja(null); setFuera([]); avisar('Importación terminada', 'ok'); }
      else {
        setRevision(r);
        if (cual === 'trabajadores') {
          const enArchivo = new Set(filas.map((x) => String(x.documento || '').replace(/[s.]/g, '')));
          const activos = await api('/api/trabajadores?estado=activos').catch(() => []);
          setFuera(activos.filter((t) => !enArchivo.has(String(t.documento))));
        }
      }
    } catch (e) { avisar(e.message, 'error'); }
    setOcupado(false);
  };
  const cuenta = (k) => (revision || []).filter((r) => r.accion === k).length;
  const buenos = revision ? revision.length - cuenta('error') : 0;

  return html`<div class="panel">
    <div class="panel-cab"><div><h2>${cual === 'trabajadores' ? 'Trabajadores' : 'Nómina mensual (opcional)'}</h2>
      <p class="small muted">${cual === 'trabajadores' ? 'Los datos de cada trabajador y hasta dónde ya se le liquidó.' : 'Horas extra, recargos y comisiones de cada mes, para promediarlos en la liquidación. Si su programa la saca por quincenas, suba cada quincena tal cual: se suman.'}</p></div>
      <div class="acciones"><button class="btn chico" onClick=${() => plantilla(cual)}><${Icono} n="descargar" />Descargar plantilla</button></div></div>
    <div class="panel-cuerpo pila">
      <label class="btn primario" style="width:fit-content"><${Icono} n="subir" />${archivo ? 'Escoger otro archivo' : 'Escoger el archivo de Excel'}
        <input type="file" class="sr" accept=".xlsx,.xls,.csv" onChange=${(e) => { leer(e.target.files[0]); e.target.value = ''; }} /></label>
      ${hoja && html`<div class="pila">
        <p><b>${archivo}</b> · ${hoja.filas.length} filas. Revise que cada dato quedó en la columna correcta:</p>
        <div class="campos">${campos.map((c) => { const suma = columnasSuma(c, hoja.encabezados); return html`<div class="campo" key=${c.k}><label>${c.t}${c.req && html` <span class="req">*</span>`}</label>
          <select value=${Array.isArray(map[c.k]) ? 'suma' : map[c.k] ?? ''} onChange=${(e) => { const v = e.target.value; setMap({ ...map, [c.k]: v === '' ? undefined : v === 'suma' ? suma : Number(v) }); setRevision(null); }}>
            <option value="">— no viene —</option>
            ${suma.length > 1 && html`<option value="suma">${suma.map((j) => hoja.encabezados[j]).join(' + ')} (se suman)</option>`}
            ${hoja.encabezados.map((h, i) => html`<option value=${i}>${h || '(columna ' + (i + 1) + ')'}</option>`)}</select></div>`; })}</div>
        ${faltan.length > 0 && (cual === 'trabajadores' && map.documento != null && map.nombres != null
          ? html`<${Aviso} tipo="info"><b>Este archivo no trae ${faltan.map((c) => c.t.toLowerCase()).join(' ni ')}.</b> Sin la fecha en que entró cada trabajador no se puede liquidar.
              Descargue la lista con los ${contarDocumentos(hoja, map)} trabajadores (cédula, nombre y salario ya puestos), llene en Excel las columnas amarillas y súbala aquí.
              Si el archivo sí trae ese dato con otro nombre, escójalo arriba.
              <div style="margin-top:10px"><button class="btn primario" onClick=${() => listaParaCompletar(hoja, map, archivo)}><${Icono} n="descargar" />Descargar la lista para completar</button></div></${Aviso}>`
          : html`<${Aviso}>Falta escoger: ${faltan.map((c) => c.t).join(', ')}.</${Aviso}>`)}
        <div><button class="btn primario" disabled=${faltan.length > 0 || ocupado} onClick=${() => revisar(false)}>${ocupado ? 'Revisando…' : 'Revisar antes de importar'}</button></div>
      </div>`}
      ${revision && html`<div class="pila">
        <div class="tarjetas">
          ${cual === 'trabajadores' ? html`<div class="tarjeta bien"><div class="t">Nuevos</div><div class="v">${cuenta('nuevo')}</div></div><div class="tarjeta"><div class="t">Se actualizan</div><div class="v">${cuenta('actualizar')}</div></div><div class="tarjeta"><div class="t">Sin cambios</div><div class="v">${cuenta('igual')}</div></div>`
            : html`<div class="tarjeta bien"><div class="t">Filas correctas</div><div class="v">${cuenta('ok')}</div></div>`}
          <div class=${'tarjeta' + (cuenta('error') ? ' mal' : '')}><div class="t">Con problemas (no se importan)</div><div class="v">${cuenta('error')}</div></div>
        </div>
        <div class="tabla-scroll" style="max-height:360px"><table class="tabla"><thead><tr><th>Fila</th><th>Documento</th><th>Nombre</th><th>Resultado</th></tr></thead>
          <tbody>${[...revision].sort((a, b) => peso(a) - peso(b)).slice(0, 500).map((r, i) => html`<tr key=${i}><td>${r.fila}</td><td>${r.documento}</td><td>${r.nombre}</td>
            <td>${r.accion === 'error' ? html`<span class="chip bad">No se importa</span> <span class="small">${r.detalle}</span>` : html`<span class=${'chip ' + (r.accion === 'nuevo' || r.accion === 'ok' ? 'ok' : r.accion === 'igual' ? '' : 'brand')}>${r.accion === 'nuevo' ? 'Nuevo' : r.accion === 'ok' ? 'Bien' : r.accion === 'igual' ? 'Igual' : 'Actualiza'}</span> <span class="small muted">${r.detalle}</span>${r.aviso ? html`<div class="small" style="color:var(--warn);margin-top:3px">${r.aviso}</div>` : ''}`}</td></tr>`)}</tbody></table></div>
        ${fuera.length > 0 && html`<${Aviso} tipo="info"><b>${fuera.length} ${fuera.length === 1 ? 'trabajador activo del programa no viene' : 'trabajadores activos del programa no vienen'} en este archivo.</b> No se borran ni se tocan. Si alguno ya no trabaja en la empresa, hágale la liquidación definitiva.
          <div class="small" style="margin-top:6px">${fuera.slice(0, 15).map((t) => t.nombre || (t.nombres + ' ' + (t.apellidos || ''))).join(' · ')}${fuera.length > 15 ? ` y ${fuera.length - 15} más` : ''}</div></${Aviso}>`}
        <div class="fila"><button class="btn primario grande" disabled=${!buenos || ocupado} onClick=${async () => { if (await confirmar({ titulo: `Importar ${buenos} filas`, texto: cuenta('error') ? `Las ${cuenta('error')} filas con problemas se saltan. Puede corregirlas en el Excel y volver a subirlo: no duplica a nadie.` : 'Todo se ve bien.', boton: 'Importar' })) revisar(true); }}>Importar ${buenos} filas</button></div>
      </div>`}
      ${hecho && html`<${Aviso} tipo="ok">Listo: ${cual === 'trabajadores'
        ? `${hecho.filter((r) => r.accion === 'nuevo').length} nuevos, ${hecho.filter((r) => r.accion === 'actualizar').length} actualizados, ${hecho.filter((r) => r.accion === 'igual').length} sin cambios`
        : `${hecho.filter((r) => r.accion !== 'error').length} filas importadas`}${hecho.some((r) => r.accion === 'error') ? `, ${hecho.filter((r) => r.accion === 'error').length} con problemas (no se importaron)` : ''}. ${cual === 'trabajadores' && html`<a href="#/trabajadores">Ver los trabajadores</a>`}</${Aviso}>`}
    </div>
  </div>`;
}

// ---------------------------------------------------------------- liquidaciones de antes del programa
// Los Excel de la empresa con primas y cesantías ya pagadas: se guardan como historia (no se recalculan).
const ALIAS_VALOR = {
  prima: ['prima', 'valor prima', 'prima de servicios', 'valor a pagar'],
  cesantias: ['valor a pagar cesantias', 'cesantias', 'valor cesantias', 'cesantias consignadas'],
  vacaciones: ['vacaciones', 'valor vacaciones', 'valor a pagar'],
  otro: ['valor', 'valor a pagar', 'total'],
};
function camposHist(concepto) {
  return [
    { k: 'documento', t: 'Documento', req: true, alias: TRAB[0].alias.concat(['no documento']) },
    { k: 'nombre', t: 'Nombre', alias: ['nombre', 'nombres', 'nombre completo', 'empleado', 'trabajador', 'nombres y apellidos', 'apellidos y nombres'] },
    { k: 'desde', t: 'Desde (inicio del periodo)', fecha: true, alias: ['fecha inicial', 'desde', 'fecha inicio', 'fecha de inicio', 'fecha ingreso', 'fecha de ingreso', 'inicio'] },
    { k: 'hasta', t: 'Hasta (fin del periodo)', req: true, fecha: true, alias: ['fecha final', 'hasta', 'fecha liquidacion prima', 'fecha de liquidacion', 'fecha liquidacion', 'fecha corte', 'fecha de corte', 'fecha fin', 'corte'] },
    { k: 'dias', t: 'Días', alias: ['dias', 'total dias laborados', 'dias laborados', 'dias trabajados', 'dias liquidados'] },
    { k: 'salario', t: 'Salario', dinero: true, alias: ['salario', 'salario basico', 'sueldo', 'basico', 'sueldo basico'] },
    { k: 'auxilio', t: 'Auxilio de transporte', dinero: true, alias: ['auxilo transporte', 'auxilio transporte', 'aux de transporte', 'auxilio de transporte', 'aux transporte'] },
    { k: 'base', t: 'Base', dinero: true, alias: ['base', 'total base liquidacion', 'base liquidacion', 'base de liquidacion'] },
    { k: 'valor', t: concepto === 'cesantias' ? 'Cesantías' : concepto === 'prima' ? 'Prima' : 'Valor', req: true, dinero: true, alias: ALIAS_VALOR[concepto] },
    ...(concepto === 'cesantias' ? [{ k: 'intereses', t: 'Intereses sobre cesantías', dinero: true, alias: ['intereses cesantias', 'intereses', 'int', 'intereses a las cesantias', 'intereses sobre cesantias', 'intereses de cesantias'] }] : []),
    { k: 'descuentos', t: 'Descuentos', dinero: true, alias: ['descuento prestamos', 'descuentos', 'descuento', 'prestamos'] },
    { k: 'neto', t: 'Valor pagado al trabajador', dinero: true, alias: ['valor a pagar', 'neto', 'neto a pagar', 'total a pagar'] },
    ...(concepto === 'cesantias' ? [{ k: 'fondo', t: 'Fondo de cesantías', alias: ['entidad cesantias', 'fondo', 'fondo de cesantias', 'fondo cesantias'] }] : []),
    { k: 'observacion', t: 'Observación', alias: ['observacion', 'observaciones', 'nota', 'notas'] },
  ];
}
const QUE_HIST = { prima: 'Prima', cesantias: 'Cesantías e intereses', vacaciones: 'Vacaciones', otro: 'Otro pago' };
function adivinarConcepto(texto) {
  const t = normalizar(texto);
  if (t.includes('cesant')) return 'cesantias';
  if (t.includes('prima')) return 'prima';
  if (t.includes('vacac')) return 'vacaciones';
  return '';
}

// Lee todas las hojas de un libro (los Excel viejos traen varias: una por periodo).
async function leerLibro(archivo) {
  const X = window.XLSX;
  const wb = X.read(await archivo.arrayBuffer(), { type: 'array', cellDates: false, raw: true });
  return wb.SheetNames.map((nombre) => {
    const filas = X.utils.sheet_to_json(wb.Sheets[nombre], { header: 1, raw: true, defval: '' });
    // El encabezado es la primera fila con al menos 3 títulos (arriba suelen venir el nombre de la empresa y el título)
    let fe = filas.findIndex((f) => f.filter((c) => typeof c === 'string' && c.trim()).length >= 3);
    if (fe < 0) fe = 0;
    const titulo = filas.slice(0, fe).map((f) => f.filter(Boolean).join(' ')).join(' ');
    return { nombre, titulo, encabezados: (filas[fe] || []).map((c) => String(c).trim()), filas: filas.slice(fe + 1).filter((f) => f.some((c) => String(c).trim() !== '')), filaInicial: fe + 2 };
  }).filter((h) => h.filas.length);
}

function ImportadorHistoricas() {
  const [archivo, setArchivo] = useState(null);
  const [hojas, setHojas] = useState([]);
  const [ih, setIh] = useState(0);
  const [concepto, setConcepto] = useState('');
  const [map, setMap] = useState({});
  const [revision, setRevision] = useState(null);
  const [ocupado, setOcupado] = useState(false);
  const [hecho, setHecho] = useState(null);
  const hoja = hojas[ih];
  const campos = concepto ? camposHist(concepto) : [];
  const elegirHoja = (i, hs = hojas) => {
    const h = hs[i];
    const c = adivinarConcepto(h.nombre + ' ' + h.titulo) || concepto || '';
    setIh(i); setConcepto(c); setMap(c ? adivinar(camposHist(c), h.encabezados) : {}); setRevision(null); setHecho(null);
  };
  const leer = async (f) => {
    setRevision(null); setHecho(null);
    if (!f) return;
    try {
      const hs = await leerLibro(f);
      if (!hs.length) throw new Error('El archivo no trae filas con datos.');
      setArchivo(f.name); setHojas(hs); elegirHoja(0, hs);
    } catch (e) { avisar('No se pudo leer el archivo: ' + e.message, 'error'); }
  };
  const cambiarConcepto = (c) => { setConcepto(c); setMap(c ? adivinar(camposHist(c), hoja.encabezados) : {}); setRevision(null); };
  const faltan = campos.filter((c) => c.req && map[c.k] == null);
  const revisar = async (guardar) => {
    setOcupado(true);
    try {
      const filas = convertir(campos, map, hoja.filas, hoja.filaInicial).map((o, n) => {
        // Si una fecha no se entendió, se manda el texto original para avisarlo
        for (const k of ['desde', 'hasta']) {
          if (map[k] != null && !/^\d{4}-\d{2}-\d{2}$/.test(o[k] || '')) { const crudo = hoja.filas[n][map[k]]; o[k] = ''; if (crudo !== '' && crudo != null) o[k + '_txt'] = String(crudo); }
        }
        return o;
      });
      const r = await api('/api/importar/historicas', { metodo: 'POST', cuerpo: { filas, concepto, fuente: `${archivo} › ${hoja.nombre}`, guardar } });
      if (guardar) { setHecho(r); setRevision(null); avisar('Importación terminada', 'ok'); } else setRevision(r);
    } catch (e) { avisar(e.message, 'error'); }
    setOcupado(false);
  };
  const cuenta = (k) => (revision || []).filter((r) => r.accion === k).length;
  const aGuardar = cuenta('nuevo') + cuenta('actualizar');
  const total = (rs) => rs.filter((r) => ['nuevo', 'actualizar', 'igual'].includes(r.accion)).reduce((s, r) => s + (r.valor || 0) + (r.intereses || 0), 0);
  const orden = (r) => (r.accion === 'error' ? 0 : r.ajuste ? 1 : r.accion === 'repetida' ? 2 : r.en_programa ? 3 : 4);
  const ETIQ = { nuevo: 'Nueva', actualizar: 'Cambia', igual: 'Ya estaba', repetida: 'Repetida' };
  const guardarTodo = async () => {
    const ok = await confirmar({
      titulo: `Guardar ${aGuardar} pagos de antes del programa`,
      texto: cuenta('error') ? `Las ${cuenta('error')} filas con problemas se saltan. Puede corregirlas en el Excel y volver a subirlo: no duplica nada.` : 'Se guardan tal como vienen en el Excel.',
      boton: 'Guardar',
    });
    if (ok) revisar(true);
  };

  return html`<div class="panel" id="importar-historicas">
    <div class="panel-cab"><div><h2>Liquidaciones de antes del programa</h2>
      <p class="small muted">Los Excel con primas y cesantías que ya se pagaron. Se guardan tal cual, como historia (no se recalculan), y salen en la ficha de cada trabajador y en el Historial.</p></div></div>
    <div class="panel-cuerpo pila">
      <label class="btn primario" style="width:fit-content"><${Icono} n="subir" />${archivo ? 'Escoger otro archivo' : 'Escoger el archivo de Excel'}
        <input type="file" class="sr" accept=".xlsx,.xls,.csv" onChange=${(e) => { leer(e.target.files[0]); e.target.value = ''; }} /></label>
      ${hoja && html`<div class="pila">
        <div class="campos">
          ${hojas.length > 1 && html`<div class="campo"><label for="hist-hoja">Hoja del archivo (tiene ${hojas.length})</label>
            <select id="hist-hoja" value=${ih} onChange=${(e) => elegirHoja(Number(e.target.value))}>${hojas.map((h, i) => html`<option value=${i}>${h.nombre} · ${h.filas.length} filas</option>`)}</select></div>`}
          <div class="campo"><label for="hist-que">Qué se pagó en esta hoja <span class="req">*</span></label>
            <select id="hist-que" value=${concepto} onChange=${(e) => cambiarConcepto(e.target.value)}><option value="">Escoja…</option>${Object.entries(QUE_HIST).map(([k, v]) => html`<option value=${k}>${v}</option>`)}</select></div>
        </div>
        ${hoja.titulo && html`<p class="small muted">Título de la hoja: ${hoja.titulo.slice(0, 160)}</p>`}
        ${concepto && html`<p><b>${archivo}</b> › ${hoja.nombre} · ${hoja.filas.length} filas. Revise que cada dato quedó en la columna correcta:</p>
          <div class="campos">${campos.map((c) => html`<div class="campo" key=${c.k}><label>${c.t}${c.req && html` <span class="req">*</span>`}</label>
            <select value=${map[c.k] ?? ''} onChange=${(e) => { const v = e.target.value; setMap({ ...map, [c.k]: v === '' ? undefined : Number(v) }); setRevision(null); }}>
              <option value="">— no viene —</option>${hoja.encabezados.map((h, i) => html`<option value=${i}>${h || `(columna ${i + 1})`}</option>`)}</select></div>`)}</div>
          ${faltan.length > 0 && html`<${Aviso}>Falta escoger: ${faltan.map((c) => c.t).join(', ')}.</${Aviso}>`}
          <div><button class="btn primario" disabled=${faltan.length > 0 || ocupado} onClick=${() => revisar(false)}>${ocupado ? 'Revisando…' : 'Revisar antes de importar'}</button></div>`}
      </div>`}
      ${revision && html`<div class="pila">
        <div class="tarjetas">
          <div class="tarjeta bien"><div class="t">Nuevas</div><div class="v">${cuenta('nuevo')}</div></div>
          <div class="tarjeta"><div class="t">Ya estaban</div><div class="v">${cuenta('igual') + cuenta('actualizar')}</div><div class="d">${cuenta('actualizar') ? cuenta('actualizar') + ' cambian' : 'sin cambios'}</div></div>
          <div class="tarjeta"><div class="t">Repetidas en el archivo</div><div class="v">${cuenta('repetida')}</div><div class="d">se guardan una vez</div></div>
          <div class=${'tarjeta' + (cuenta('error') ? ' mal' : '')}><div class="t">Con problemas (no se importan)</div><div class="v">${cuenta('error')}</div></div>
          <div class="tarjeta"><div class="t">Totales o notas</div><div class="v">${cuenta('resumen')}</div><div class="d">se saltan</div></div>
        </div>
        <p class="small muted">Total de la hoja: <b>${pesos(total(revision))}</b>. ${revision.filter((r) => r.en_programa && ['nuevo', 'actualizar', 'igual'].includes(r.accion)).length} son de personas que ya están en el programa; las demás se guardan igual y aparecen en su ficha cuando se carguen.</p>
        <div class="tabla-scroll" style="max-height:360px"><table class="tabla"><thead><tr><th>Fila</th><th>Documento</th><th>Nombre</th><th>Periodo</th><th class="num">Valor</th><th>Resultado</th></tr></thead>
          <tbody>${revision.filter((r) => r.accion !== 'resumen').sort((a, b) => orden(a) - orden(b)).slice(0, 500).map((r, i) => html`<tr key=${i}><td>${r.fila}</td><td>${r.documento}</td>
            <td>${r.nombre}${!r.en_programa && r.accion !== 'error' ? html`<div class="doc">no está en el programa</div>` : ''}</td>
            <td class="nowrap">${r.hasta ? `${r.desde ? fCorta(r.desde) : '¿?'} → ${fCorta(r.hasta)}` : ''}</td>
            <td class="num">${r.valor != null ? pesos(r.valor) : ''}${r.intereses ? html`<div class="doc">+ ${pesos(r.intereses)} intereses</div>` : ''}</td>
            <td>${r.accion === 'error' ? html`<span class="chip bad">No se importa</span> <span class="small">${r.detalle}</span>`
              : html`<span class=${'chip ' + (r.accion === 'nuevo' ? 'ok' : r.accion === 'actualizar' ? 'brand' : '')}>${ETIQ[r.accion]}</span> <span class="small muted">${r.detalle}</span>${r.ajuste ? html`<div class="small" style="color:var(--warn);margin-top:3px">${r.ajuste}</div>` : ''}`}</td></tr>`)}</tbody></table></div>
        <div class="fila"><button class="btn primario grande" disabled=${!aGuardar || ocupado} onClick=${guardarTodo}>${aGuardar ? `Guardar ${aGuardar} pagos` : 'No hay nada nuevo para guardar'}</button></div>
      </div>`}
      ${hecho && html`<${Aviso} tipo="ok">Listo: ${hecho.filter((r) => r.accion === 'nuevo').length} nuevos y ${hecho.filter((r) => r.accion === 'actualizar').length} actualizados${hecho.some((r) => r.accion === 'error') ? `; ${hecho.filter((r) => r.accion === 'error').length} con problemas no se importaron` : ''}. Si el archivo tiene más hojas, escoja la siguiente arriba. <a href="#/historial?antes=1">Verlos en el Historial</a></${Aviso}>`}
    </div>
  </div>`;
}

export function Importar() {
  return html`<div class="pila">
    <div class="encabezado"><div><h1>Importar de Excel</h1><p class="sub">Suba un archivo de Excel. Primero se revisa y se muestra qué va a pasar; nada se guarda hasta que lo confirme.</p></div></div>
    <${Aviso} tipo="info">Si el archivo viene de otro programa de nómina, súbalo tal cual: el programa reconoce las columnas por su nombre y usted solo confirma.</${Aviso}>
    <${Importador} cual="trabajadores" />
    <${Importador} cual="nomina" />
    <${ImportadorHistoricas} />
  </div>`;
}
