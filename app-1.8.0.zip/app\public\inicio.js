import { html, useState } from './vendor/preact-htm.js';
import { api, pesos, millones, fLarga, fCorta, saludo, hoy, ir } from './util.js';
import { Icono, Cargando, useDatos, avisar, Campo, Aviso } from './comp.js';
import { BotonRestaurar } from './ajustes.js';

// Lo que publica ibizamotos.co (política de privacidad). Solo se propone si la empresa está vacía; quien firma no se sabe.
const IBIZA = { razon_social: 'Ibiza Motos S.A.S.', nit: '901.197.563-9', ciudad: 'Pereira', direccion: 'Cra 7 #25-41 Parque Lago Uribe', telefono: '305 288 4546', cargo_representante: 'Representante legal' };

export function FormEmpresa({ inicial, onGuardado, boton = 'Guardar' }) {
  const propuesto = !inicial?.razon_social;
  const [e, setE] = useState(propuesto ? { ...IBIZA, ...Object.fromEntries(Object.entries(inicial || {}).filter(([, v]) => v)) } : inicial);
  const [guardando, setGuardando] = useState(false);
  const c = (k) => ({ id: 'emp-' + k, value: e[k] || '', onInput: (ev) => setE({ ...e, [k]: ev.target.value }) });
  const guardar = async (ev) => {
    ev.preventDefault();
    setGuardando(true);
    try { await api('/api/empresa', { metodo: 'PUT', cuerpo: e }); avisar('Datos de la empresa guardados', 'ok'); onGuardado?.(); } catch (err) { avisar(err.message, 'error'); }
    setGuardando(false);
  };
  return html`<form onSubmit=${guardar} class="pila">
    ${propuesto && html`<p class="small muted">Ya están puestos los datos de Ibiza Motos que salen en su página web. Revíselos, escriba quién firma y guarde.</p>`}
    <div class="campos">
      <${Campo} etiqueta="Nombre o razón social" requerido id="emp-razon_social"><input ...${c('razon_social')} placeholder="Ej.: Ibiza Motos S.A.S." /></${Campo}>
      <${Campo} etiqueta="NIT" id="emp-nit"><input ...${c('nit')} placeholder="900.000.000-0" /></${Campo}>
      <${Campo} etiqueta="Ciudad" id="emp-ciudad"><input ...${c('ciudad')} /></${Campo}>
      <${Campo} etiqueta="Dirección" id="emp-direccion"><input ...${c('direccion')} /></${Campo}>
      <${Campo} etiqueta="Teléfono" id="emp-telefono"><input ...${c('telefono')} /></${Campo}>
      <${Campo} etiqueta="Quién firma por la empresa" id="emp-representante" ayuda="Sale en la firma de los comprobantes."><input ...${c('representante')} /></${Campo}>
      <${Campo} etiqueta="Cargo de quien firma" id="emp-cargo_representante"><input ...${c('cargo_representante')} placeholder="Representante legal" /></${Campo}>
    </div>
    <div><button class="btn primario" disabled=${guardando || !e.razon_social}>${boton}</button></div>
  </form>`;
}

function Bienvenida({ empresa, info, onListo }) {
  const sinEmpresa = !empresa?.razon_social;
  const sinTrab = !info?.conteos.trabajadores;
  return html`<div class="panel">
    <div class="panel-cab"><div><h2>Para empezar</h2><p class="muted small">Dos pasos y queda listo. Se hacen una sola vez.</p></div></div>
    <div class="panel-cuerpo pila">
      ${sinTrab && html`<div class="aviso info" id="traer-copia"><div class="pila" style="--g:8px">
        <div><b>¿Ya usaba el programa en otro computador?</b> Traiga todo de una vez (empresa, trabajadores y liquidaciones) con el archivo de copia que descargó allá en <b>Ajustes y copias → Descargar una copia ahora</b>. Así no tiene que hacer los pasos de abajo.</div>
        <${BotonRestaurar} texto="Traer todo desde una copia" primario />
      </div></div>`}
      <div>
        <h3>${sinEmpresa ? '1.' : html`<span class="chip ok">Listo</span>`} Datos de la empresa</h3>
        <p class="muted small" style="margin:4px 0 12px">Salen en el encabezado de cada comprobante.</p>
        ${sinEmpresa && html`<${FormEmpresa} inicial=${empresa} onGuardado=${onListo} boton="Guardar y seguir" />`}
      </div>
      <div style="border-top:1px solid var(--line);padding-top:14px">
        <h3>2. Los trabajadores</h3>
        <p class="muted small" style="margin:4px 0 12px">Si los tiene en Excel, súbalos todos de una vez. Si son pocos, agréguelos uno por uno.</p>
        <div class="fila">
          <a class="btn primario" href="#/importar"><${Icono} n="importar" />Subir desde Excel</a>
          <a class="btn" href="#/trabajadores?nuevo=1"><${Icono} n="mas" />Agregar uno por uno</a>
        </div>
        ${!sinTrab && html`<p class="small" style="margin-top:8px"><span class="chip ok">Listo</span> Ya hay ${info.conteos.trabajadores} trabajadores.</p>`}
      </div>
    </div>
  </div>`;
}

function GrupoPendiente({ g }) {
  const [ver, setVer] = useState(false);
  const n = g.trabajadores.length;
  let accion = null;
  const anio = Number(hoy().slice(0, 4));
  if (g.clave.startsWith('ces_')) accion = html`<a class="btn primario chico" href=${`#/todos?tipo=cesantias&anio=${g.clave.slice(4)}`}>Liquidar a todos</a>`;
  else if (g.clave.startsWith('pri_')) {
    const [, y, s] = g.clave.split('_');
    accion = html`<a class="btn primario chico" href=${`#/todos?tipo=prima&anio=${y}&semestre=${s || 2}`}>Liquidar a todos</a>`;
  }
  return html`<div class="pendiente">
    <div class=${'icono' + (g.vencido ? ' mal' : '')}><${Icono} n=${g.vencido ? 'alerta' : 'reloj'} /></div>
    <div class="cuerpo">
      <div class="fila entre">
        <div><b>${g.titulo}</b> <span class="chip">${n} ${n === 1 ? 'persona' : 'personas'}</span>
          ${g.vence && html` <span class=${'chip ' + (g.vencido ? 'bad' : 'warn')}>${g.vencido ? 'Venció el ' : 'Vence el '}${fCorta(g.vence)}</span>`}</div>
        <div class="fila">${accion}<button class="btn chico" onClick=${() => setVer(!ver)}>${ver ? 'Ocultar' : 'Ver quiénes'}</button></div>
      </div>
      <p class="small muted" style="margin-top:4px">${g.explica}</p>
      ${ver && html`<div class="nombres">${g.trabajadores.map((t, i) => html`${i ? ' · ' : ''}<a href=${'#/trabajador/' + t.id}>${t.nombre}</a>${t.dias ? ` (${String(t.dias).replace('.', ',')} días)` : ''}${t.huecos ? ` (${t.huecos.map((h) => `${h.que} del ${fCorta(h.desde)} al ${fCorta(h.hasta)}`).join('; ')})` : ''}${t.nota ? ` (${t.nota})` : ''}`)}</div>`}
    </div>
  </div>`;
}

export function Inicio({ usuario }) {
  const emp = useDatos('/api/empresa');
  const inf = useDatos('/api/info');
  const pen = useDatos('/api/pendientes');
  const anio = hoy().slice(0, 4);
  const hist = useDatos(`/api/liquidaciones?desde=${anio}-01-01&hasta=${anio}-12-31`);
  const act = useDatos('/api/actualizacion');
  if (emp.cargando && !emp.datos) return html`<${Cargando} />`;
  const empresa = emp.datos;
  const info = inf.datos;
  const listo = empresa?.razon_social && info?.conteos.trabajadores > 0;
  const recargar = () => { emp.recargar(); inf.recargar(); pen.recargar(); };
  const grupos = pen.datos?.grupos || [];
  const prox = pen.datos?.proximos?.[0];

  return html`<div class="pila">
    <div class="encabezado">
      <div><h1>${saludo()}${usuario ? ', ' + usuario.split(' ')[0] : ''}</h1><p class="sub">${fLarga(hoy())}${empresa?.razon_social ? ' · ' + empresa.razon_social : ''}</p></div>
      ${listo && html`<div class="fila"><a class="btn primario grande" href="#/liquidar"><${Icono} n="calculadora" />Liquidar a un trabajador</a></div>`}
    </div>

    ${!listo && html`<${Bienvenida} empresa=${empresa} info=${info} onListo=${recargar} />`}

    ${listo && html`<div class="tarjetas">
      <a class="tarjeta" href="#/trabajadores" style="text-decoration:none;color:inherit"><div class="t">Trabajadores activos</div><div class="v">${info.conteos.activos}</div><div class="d">${info.conteos.trabajadores - info.conteos.activos} retirados</div></a>
      <a class="tarjeta" href=${`#/historial?anio=${anio}`} style="text-decoration:none;color:inherit"><div class="t">Liquidado en ${anio}</div><div class="v">${hist.datos ? millones(hist.datos.totales.neto + hist.datos.totales.a_fondo) : '…'}</div><div class="d">${hist.datos ? hist.datos.filas.filter((f) => f.estado === 'vigente').length + ' liquidaciones' : ''}</div></a>
      ${prox && html`<div class=${'tarjeta' + (prox.faltan <= 15 ? ' alerta' : '')}><div class="t">Próxima fecha legal</div><div class="v" style="font-size:18px">${fCorta(prox.fecha)}</div><div class="d">${prox.texto} · ${prox.faltan === 0 ? 'es hoy' : `faltan ${prox.faltan} días`}</div>${prox.nota && html`<div class="d" style="color:var(--warn)">${prox.nota}</div>`}</div>`}
    </div>`}

    ${act.datos?.hay && act.datos.instalada && html`<${Aviso} tipo="info"><b>Hay una versión nueva del programa (${act.datos.nueva}).</b> Trae mejoras y no toca los datos. <a href="#/ajustes">Ver y actualizar</a></${Aviso}>`}
    ${(pen.datos?.generales || []).map((a) => html`<${Aviso} tipo=${a.vencido ? 'bad' : 'info'} key=${a.titulo}><b>${a.titulo}.</b> ${a.explica} <a href="#/ajustes">Ir a Ajustes</a></${Aviso}>`)}

    ${listo && html`<div class="panel">
      <div class="panel-cab"><div><h2>Lo que está pendiente</h2><p class="muted small">Revisado contra las fechas que pone la ley.</p></div></div>
      ${pen.cargando && !pen.datos ? html`<${Cargando} />` :
        grupos.length === 0 ? html`<div class="vacio"><b>Todo al día</b>No hay cesantías, primas ni vacaciones atrasadas.</div>` :
        grupos.map((g) => html`<${GrupoPendiente} g=${g} key=${g.clave} />`)}
    </div>`}

    ${listo && html`<div class="tarjetas">
      <a class="tarjeta" href="#/todos" style="text-decoration:none;color:inherit"><div class="fila"><${Icono} n="grupo" style="width:20px;color:var(--brand)" /><b>Liquidar a todos</b></div><div class="d">Cesantías de fin de año o prima del semestre para toda la nómina.</div></a>
      <a class="tarjeta" href="#/historial" style="text-decoration:none;color:inherit"><div class="fila"><${Icono} n="historial" style="width:20px;color:var(--brand)" /><b>Buscar en el historial</b></div><div class="d">Por año, por fechas, por trabajador o por sede. Se descarga en Excel.</div></a>
      <a class="tarjeta" href="#/trabajadores" style="text-decoration:none;color:inherit"><div class="fila"><${Icono} n="personas" style="width:20px;color:var(--brand)" /><b>Hasta dónde se le liquidó a cada uno</b></div><div class="d">En la ficha de cada trabajador sale todo su historial.</div></a>
    </div>`}
  </div>`;
}
