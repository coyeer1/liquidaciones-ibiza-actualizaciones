import { html, render, useState, useEffect } from './vendor/preact-htm.js';
import { api, rutaActual, usuarioActual, fijarUsuario } from './util.js';
import { Icono, Toasts, Confirmaciones, Modal, avisar } from './comp.js';
import { Inicio } from './inicio.js';
import { ListaTrabajadores, FichaTrabajador } from './trabajadores.js';
import { Liquidar, LiquidarTodos } from './liquidar.js';
import { Comprobante, ComprobantesLote, Certificado } from './comprobante.js';
import { Historial } from './historial.js';
import { Importar } from './importar.js';
import { Ajustes, Bitacora } from './ajustes.js';

const MENU = [
  ['/inicio', 'inicio', 'Inicio'],
  ['/trabajadores', 'personas', 'Trabajadores'],
  ['/liquidar', 'calculadora', 'Liquidar a uno'],
  ['/todos', 'grupo', 'Liquidar a todos'],
  ['/historial', 'historial', 'Historial'],
  null,
  ['/importar', 'importar', 'Importar de Excel'],
  ['/ajustes', 'ajustes', 'Ajustes y copias'],
];

function QuienUsa({ onListo, puedeCerrar, onCerrar }) {
  const [lista, setLista] = useState(null);
  const [nuevo, setNuevo] = useState('');
  useEffect(() => { api('/api/usuarios').then(setLista).catch(() => setLista([])); }, []);
  const entrar = (n) => { fijarUsuario(n); onListo(n); };
  const crear = async (e) => {
    e.preventDefault();
    const n = nuevo.trim();
    if (!n) return;
    try { await api('/api/usuarios', { metodo: 'POST', cuerpo: { nombre: n } }); entrar(n); } catch (err) { avisar(err.message, 'error'); }
  };
  return html`<${Modal} titulo="¿Quién está usando el programa?" sub="Queda anotado en cada liquidación y en el registro de cambios." onCerrar=${puedeCerrar ? onCerrar : null}>
    <div class="pila">
      ${lista && lista.length > 0 && html`<div class="opciones">${lista.map((u) => html`<button class="opcion" key=${u.id} onClick=${() => entrar(u.nombre)}><b>${u.nombre}</b><span>Entrar</span></button>`)}</div>`}
      <form onSubmit=${crear} class="campo">
        <label for="nuevo-usuario">${lista && lista.length ? 'O escriba otro nombre' : 'Escriba su nombre'}</label>
        <div class="fila" style="flex-wrap:nowrap">
          <input id="nuevo-usuario" value=${nuevo} onInput=${(e) => setNuevo(e.target.value)} placeholder="Ej.: Tatiana Gómez" />
          <button class="btn primario" disabled=${!nuevo.trim()}>Entrar</button>
        </div>
      </form>
    </div>
  </${Modal}>`;
}

function App() {
  const [ruta, setRuta] = useState(rutaActual());
  const [usuario, setUsuario] = useState(usuarioActual());
  const [cambiarUsuario, setCambiarUsuario] = useState(false);

  useEffect(() => {
    const f = () => { setRuta(rutaActual()); window.scrollTo(0, 0); };
    addEventListener('hashchange', f);
    return () => removeEventListener('hashchange', f);
  }, []);

  // Le avisa al programa que la ventana sigue abierta (si se cierra, se apaga solo).
  useEffect(() => {
    const s = () => api('/api/senal', { metodo: 'POST' }).catch(() => {});
    s();
    const t = setInterval(s, 20000);
    const adios = () => navigator.sendBeacon?.('/api/adios');
    addEventListener('pagehide', adios);
    return () => { clearInterval(t); removeEventListener('pagehide', adios); };
  }, []);

  const [p0, p1] = ruta.partes;
  let pagina;
  switch (p0) {
    case 'trabajadores': pagina = html`<${ListaTrabajadores} query=${ruta.query} />`; break;
    case 'trabajador': pagina = html`<${FichaTrabajador} id=${Number(p1)} key=${p1} />`; break;
    case 'liquidar': pagina = html`<${Liquidar} query=${ruta.query} key=${JSON.stringify(ruta.query)} />`; break;
    case 'todos': pagina = html`<${LiquidarTodos} query=${ruta.query} />`; break;
    case 'liquidacion': pagina = html`<${Comprobante} id=${Number(p1)} key=${p1} />`; break;
    case 'certificado': pagina = html`<${Certificado} id=${Number(p1)} key=${p1} />`; break;
    case 'lote': pagina = html`<${ComprobantesLote} lote=${decodeURIComponent(p1 || '')} />`; break;
    case 'historial': pagina = html`<${Historial} query=${ruta.query} />`; break;
    case 'importar': pagina = html`<${Importar} />`; break;
    case 'ajustes': pagina = html`<${Ajustes} />`; break;
    case 'bitacora': pagina = html`<${Bitacora} />`; break;
    default: pagina = html`<${Inicio} usuario=${usuario} />`;
  }
  const activo = '/' + (p0 === 'trabajador' ? 'trabajadores' : p0 === 'liquidacion' || p0 === 'lote' ? 'historial' : p0 === 'bitacora' ? 'ajustes' : p0 || 'inicio');

  return html`<div class="marco">
    <nav class="lateral" aria-label="Menú principal">
      <div class="marca"><img src="marca/ibiza-sin-lema.png" alt="Ibiza Motos" /><div><b>Liquidaciones</b><small>Prestaciones sociales</small></div></div>
      ${MENU.map((m) => (m ? html`<a class=${'nav-item' + (activo === m[0] ? ' activo' : '')} href=${'#' + m[0]} aria-current=${activo === m[0] ? 'page' : null}><${Icono} n=${m[1]} />${m[2]}</a>` : html`<div class="nav-sep" />`))}
      <div class="pie">
        ${usuario ? html`Usando: <b style="color:#fff">${usuario}</b><br /><button onClick=${() => setCambiarUsuario(true)}>Cambiar de persona</button>` : null}
      </div>
    </nav>
    <main class="contenido">${pagina}</main>
    ${(!usuario || cambiarUsuario) && html`<${QuienUsa} puedeCerrar=${!!usuario} onCerrar=${() => setCambiarUsuario(false)} onListo=${(n) => { setUsuario(n); setCambiarUsuario(false); }} />`}
    <${Confirmaciones} />
    <${Toasts} />
  </div>`;
}

render(html`<${App} />`, document.getElementById('app'));
