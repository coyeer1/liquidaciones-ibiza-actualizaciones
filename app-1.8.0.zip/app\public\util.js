// Utilidades del lado de la pantalla: llamadas al servidor, formatos y fechas.

export const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
const MES_CORTO = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];

export const TIPOS = {
  cesantias: 'Cesantías e intereses',
  prima: 'Prima de servicios',
  disfrute: 'Vacaciones disfrutadas',
  vacaciones: 'Vacaciones en dinero',
  definitiva: 'Liquidación definitiva',
};
// Un comprobante con varias cosas (tipo "varios"): se nombra por sus partes, siempre en el mismo orden.
const ORDEN_PARTES = ['cesantias', 'prima', 'disfrute', 'vacaciones'];
const PARTE_DE_CONCEPTO = { cesantias: 'cesantias', intereses: 'cesantias', prima: 'prima', vacaciones_disfrutadas: 'disfrute', vacaciones: 'vacaciones' };
export function etiquetaPartes(partes) {
  return ORDEN_PARTES.filter((k) => (partes || []).some((p) => (p.tipo || p) === k)).map((k) => TIPOS[k]).join(' + ') || 'Varias a la vez';
}
// Para listas (historial, ficha): `lista` = conceptos del comprobante separados por coma
export function etiquetaTipo(tipo, lista) {
  if (tipo !== 'varios') return TIPOS[tipo] || tipo;
  return etiquetaPartes(String(lista || '').split(',').map((c) => PARTE_DE_CONCEPTO[c]).filter(Boolean));
}
export const CONCEPTOS = {
  cesantias: 'Cesantías',
  intereses: 'Intereses sobre cesantías',
  prima: 'Prima de servicios',
  vacaciones: 'Vacaciones compensadas',
  vacaciones_disfrutadas: 'Vacaciones disfrutadas',
  indemnizacion: 'Indemnización sin justa causa',
  salario: 'Salario pendiente',
  auxilio_salario: 'Auxilio de transporte pendiente',
  otro_devengo: 'Otro pago',
  deduccion: 'Descuento',
};
export const MOTIVOS = {
  renuncia: 'Renuncia voluntaria',
  sin_justa_causa: 'Despido sin justa causa',
  justa_causa: 'Despido con justa causa',
  despido_indirecto: 'Renuncia por culpa del empleador (despido indirecto)',
  periodo_prueba: 'Terminación en periodo de prueba',
  mutuo_acuerdo: 'Mutuo acuerdo',
  pension: 'Reconocimiento de pensión',
  fallecimiento: 'Fallecimiento del trabajador',
  otro: 'Otro motivo',
};

// ---------- usuario actual (quién está usando el programa) ----------
export function usuarioActual() {
  try { return localStorage.getItem('liq_usuario') || ''; } catch { return ''; }
}
export function fijarUsuario(n) {
  try { localStorage.setItem('liq_usuario', n || ''); } catch {}
}

// ---------- servidor ----------
export async function api(ruta, { metodo = 'GET', cuerpo, crudo } = {}) {
  const headers = { 'X-Liq': '1', 'X-Usuario': encodeURIComponent(usuarioActual()) };
  let body;
  if (crudo) { body = crudo; headers['Content-Type'] = 'application/octet-stream'; }
  else if (cuerpo !== undefined) { body = JSON.stringify(cuerpo); headers['Content-Type'] = 'application/json'; }
  let r;
  try {
    r = await fetch(ruta, { method: metodo, headers, body });
  } catch {
    throw new Error('El programa no responde. Ciérrelo y vuelva a abrirlo.');
  }
  let datos = null;
  try { datos = await r.json(); } catch {}
  if (!r.ok) throw new Error(datos?.error || 'Algo salió mal (' + r.status + ').');
  return datos;
}
export const qs = (o) => new URLSearchParams(Object.entries(o).filter(([, v]) => v !== '' && v != null && v !== false)).toString();

// ---------- formatos ----------
export function pesos(n) {
  if (n == null || n === '' || isNaN(n)) return '—';
  const v = Math.round(Number(n));
  const s = String(Math.abs(v)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return (v < 0 ? '-$' : '$') + s;
}
export function millones(n) {
  const v = Number(n) || 0;
  if (Math.abs(v) >= 1e6) return '$' + (v / 1e6).toLocaleString('es-CO', { maximumFractionDigits: 1 }) + ' millones';
  return pesos(v);
}
export function num(n, dec = 2) {
  if (n == null || isNaN(n)) return '—';
  return Number(n).toLocaleString('es-CO', { maximumFractionDigits: dec });
}
export function fCorta(f) {
  if (!f) return '—';
  const [y, m, d] = f.slice(0, 10).split('-').map(Number);
  return `${d} ${MES_CORTO[m - 1]} ${y}`;
}
export function fLarga(f) {
  if (!f) return '';
  const [y, m, d] = f.slice(0, 10).split('-').map(Number);
  return `${d} de ${MESES[m - 1]} de ${y}`;
}
export function hoy() {
  const t = new Date();
  return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`;
}
export function sumarDias(f, n) {
  const [y, m, d] = f.split('-').map(Number);
  const t = new Date(Date.UTC(y, m - 1, d) + n * 86400000);
  return t.toISOString().slice(0, 10);
}
export function dias360(desde, hasta) {
  if (!desde || !hasta || hasta < desde) return 0;
  const fin = (y, m) => new Date(Date.UTC(y, m, 0)).getUTCDate();
  let [y1, m1, d1] = desde.split('-').map(Number);
  let [y2, m2, d2] = hasta.split('-').map(Number);
  if (d1 === 31) d1 = 30;
  if (d2 === 31 || (m2 === 2 && d2 === fin(y2, 2))) d2 = 30;
  return (y2 - y1) * 360 + (m2 - m1) * 30 + (d2 - d1) + 1;
}
// Cómo mostrar hasta dónde se le ha liquidado algo a alguien (lista de trabajadores y ficha).
// Si nunca se le ha liquidado pero entró después del último corte, no es que falte: todavía no le toca.
export function estadoPeriodo(tipo, hasta, ingreso, fechaHoy = hoy()) {
  if (hasta && ingreso && hasta >= ingreso) return { txt: fCorta(finLaboral(hasta)), pendiente: false, nunca: false };
  const y = Number(fechaHoy.slice(0, 4));
  let ultimo, proximo;
  if (tipo === 'cesantias') { ultimo = `${y - 1}-12-31`; proximo = `30 dic ${y}`; }
  else if (fechaHoy > `${y}-06-30`) { ultimo = `${y}-06-30`; proximo = `30 dic ${y}`; }
  else { ultimo = `${y - 1}-12-31`; proximo = `30 jun ${y}`; }
  if (ingreso && ingreso > ultimo) return { txt: 'Todavía no le toca', sub: `Entró después del último corte. El primero es el ${proximo}.`, pendiente: false, nunca: true };
  return { txt: 'Nunca', sub: 'Nunca se le ha liquidado y ya le tocaba.', pendiente: true, nunca: true };
}
// Para mostrar "liquidada hasta": el fin de año se escribe 30 de diciembre, como en las planillas de Ibiza (igual que fechas.js).
export function finLaboral(f) {
  return f && /^\d{4}-12-31$/.test(f) ? f.slice(0, 5) + '12-30' : f;
}
// Días de una licencia o suspensión en meses de 30 (igual que fechas.js del servidor):
// mes completo = 30 (también febrero); pedazo de mes = días que pasaron, sin el 31.
export function diasAusencia(desde, hasta) {
  if (!desde || !hasta || hasta < desde) return 0;
  const fin = (y, m) => new Date(Date.UTC(y, m, 0)).getUTCDate();
  let total = 0;
  let [y, m, d] = desde.split('-').map(Number);
  const [y2, m2, d2] = hasta.split('-').map(Number);
  for (let guard = 0; (y < y2 || (y === y2 && m <= m2)) && guard < 2400; guard++) {
    const ultimo = fin(y, m);
    const db = y === y2 && m === m2 ? d2 : ultimo;
    total += d === 1 && db === ultimo ? 30 : Math.max(0, Math.min(db, 30) - d + 1);
    d = 1; m++; if (m > 12) { m = 1; y++; }
  }
  return total;
}
// "3 años, 2 meses y 5 días"
export function tiempoServicio(desde, hasta) {
  const d = dias360(desde, hasta);
  const a = Math.floor(d / 360);
  const m = Math.floor((d % 360) / 30);
  const r = d % 30;
  const partes = [];
  if (a) partes.push(a + (a === 1 ? ' año' : ' años'));
  if (m) partes.push(m + (m === 1 ? ' mes' : ' meses'));
  if (r || !partes.length) partes.push(r + (r === 1 ? ' día' : ' días'));
  return partes.length > 1 ? partes.slice(0, -1).join(', ') + ' y ' + partes[partes.length - 1] : partes[0];
}
export function saludo() {
  const h = new Date().getHours();
  return h < 12 ? 'Buenos días' : h < 19 ? 'Buenas tardes' : 'Buenas noches';
}

// Convierte lo que escriben ("$ 1.750.905", "1750905,00") en número entero de pesos.
export function leerPesos(v) {
  if (v == null) return null;
  if (typeof v === 'number') return Math.round(v);
  let s = String(v).trim().replace(/[$\s]/g, '');
  if (!s) return null;
  s = s.replace(/[.,](\d{1,2})$/, (m, dec) => 'D' + dec); // decimales al final
  s = s.replace(/[.,]/g, '').replace('D', '.');
  const n = Number(s);
  return Number.isFinite(n) ? Math.round(n) : null;
}

// ---------- navegación ----------
export function ir(ruta) {
  location.hash = ruta;
}
export function rutaActual() {
  const h = location.hash.replace(/^#/, '') || '/inicio';
  const [path, query = ''] = h.split('?');
  return { path, partes: path.split('/').filter(Boolean), query: Object.fromEntries(new URLSearchParams(query)) };
}

// ---------- Excel ----------
export function descargarExcel(nombre, hojas) {
  const X = window.XLSX;
  const wb = X.utils.book_new();
  for (const h of hojas) {
    const ws = X.utils.aoa_to_sheet(h.filas);
    const ancho = h.anchos || h.filas[0].map(() => 16);
    ws['!cols'] = ancho.map((w) => ({ wch: w }));
    const fe = h.filaEncabezado ?? 0;
    const rango = X.utils.decode_range(ws['!ref']);
    for (let c = rango.s.c; c <= rango.e.c; c++) {
      const celda = ws[X.utils.encode_cell({ r: fe, c })];
      if (celda) celda.s = { font: { bold: true, color: { rgb: 'FFFFFF' } }, fill: { fgColor: { rgb: 'C8461B' } }, alignment: { vertical: 'center', wrapText: true } };
    }
    for (let r = fe + 1; r <= rango.e.r; r++) {
      // Columnas por llenar: amarillas, aunque estén vacías
      for (const c of h.resaltar || []) {
        const dir = X.utils.encode_cell({ r, c });
        ws[dir] = { ...(ws[dir] || { t: 's', v: '' }), s: { fill: { fgColor: { rgb: 'FFF2B3' } } } };
      }
      for (let c = rango.s.c; c <= rango.e.c; c++) {
        const celda = ws[X.utils.encode_cell({ r, c })];
        if (!celda) continue;
        if (h.dinero?.includes(c) && typeof celda.v === 'number') celda.z = '"$"#,##0';
        if (h.negrita?.(r)) celda.s = { ...(celda.s || {}), font: { bold: true } };
      }
    }
    if (h.filtro !== false && h.filas.length > fe + 1) ws['!autofilter'] = { ref: X.utils.encode_range({ r: fe, c: rango.s.c }, { r: h.finFiltro ?? rango.e.r, c: rango.e.c }) };
    X.utils.book_append_sheet(wb, ws, h.nombre.slice(0, 31));
  }
  X.writeFile(wb, nombre);
}

// Lee un Excel/CSV y devuelve { encabezados, filas[] (arrays), fechasPorColumna }
export async function leerExcel(archivo) {
  const X = window.XLSX;
  const buf = await archivo.arrayBuffer();
  const wb = X.read(buf, { type: 'array', cellDates: false, raw: true }); // raw: los CSV no se interpretan (15/03 no es marzo 15 al estilo gringo)
  const hoja = wb.Sheets[wb.SheetNames[0]];
  const filas = X.utils.sheet_to_json(hoja, { header: 1, raw: true, defval: '' });
  // El encabezado es la primera fila con al menos 2 celdas de texto
  let fe = filas.findIndex((f) => f.filter((c) => typeof c === 'string' && c.trim()).length >= 2);
  if (fe < 0) fe = 0;
  return { encabezados: (filas[fe] || []).map((c) => String(c).trim()), filas: filas.slice(fe + 1).filter((f) => f.some((c) => String(c).trim() !== '')), filaInicial: fe + 2 };
}

const MES_TXT = { ene: 1, feb: 2, mar: 3, abr: 4, may: 5, jun: 6, jul: 7, ago: 8, sep: 9, set: 9, oct: 10, nov: 11, dic: 12, jan: 1, apr: 4, aug: 8, dec: 12 };
// Excel trae fechas como número de serie, texto dd/mm/aaaa, aaaa-mm-dd o "15-ene-2020".
export function leerFecha(v) {
  if (v == null || v === '') return '';
  if (typeof v === 'number') {
    // Se redondea al día: según la zona horaria con que se guardó, el número trae horas (ej. 43646,79 = 30 jun 7 p. m. = 1 jul)
    const p = window.XLSX.SSF.parse_date_code(Math.round(v));
    if (!p) return '';
    return `${p.y}-${String(p.m).padStart(2, '0')}-${String(p.d).padStart(2, '0')}`;
  }
  const s = String(v).trim().toLowerCase();
  let m = s.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
  if (m) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
  m = s.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})$/);
  if (m) {
    const y = m[3].length === 2 ? (Number(m[3]) > 50 ? '19' : '20') + m[3] : m[3];
    return `${y}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  }
  m = s.match(/^(\d{1,2})[-/ ]([a-zñ]{3})[a-z]*[-/ ](?:de )?(\d{2,4})$/);
  if (m && MES_TXT[m[2]]) {
    const y = m[3].length === 2 ? '20' + m[3] : m[3];
    return `${y}-${String(MES_TXT[m[2]]).padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  }
  return s;
}
// Mes de nómina: "2026-03", "03/2026", "marzo 2026", o una fecha
export function leerPeriodo(v) {
  if (typeof v === 'number') return leerFecha(v).slice(0, 7);
  const s = String(v || '').trim().toLowerCase();
  let m = s.match(/^(\d{4})[-/.](\d{1,2})$/);
  if (m) return `${m[1]}-${m[2].padStart(2, '0')}`;
  m = s.match(/^(\d{1,2})[-/.](\d{4})$/);
  if (m) return `${m[2]}-${m[1].padStart(2, '0')}`;
  m = s.match(/^([a-zñ]{3})[a-z]*\.?[ -/](?:de )?(\d{4})$/);
  if (m && MES_TXT[m[1]]) return `${m[2]}-${String(MES_TXT[m[1]]).padStart(2, '0')}`;
  return leerFecha(v).slice(0, 7);
}

export function normalizar(s) {
  return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();
}
