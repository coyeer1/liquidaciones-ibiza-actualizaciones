import { html, useState, useEffect } from './vendor/preact-htm.js';
import { api, pesos, num, fCorta, fLarga, tiempoServicio, ir, TIPOS, etiquetaPartes, CONCEPTOS, MOTIVOS } from './util.js';
import { Icono, Aviso, Cargando, useDatos, avisar, confirmar } from './comp.js';

// El 30 y el 31 de diciembre cierran igual el año (cada mes cuenta 30 días).
const finDic = (f) => f?.slice(5) === '12-30' || f?.slice(5) === '12-31';
const NOMBRE_PARTE = { cesantias: 'cesantías e intereses', prima: 'prima de servicios', disfrute: 'vacaciones disfrutadas', vacaciones: 'vacaciones compensadas en dinero' };
function titulo(d) {
  if (d.tipo === 'varios') {
    const n = (d.partes || []).map((p) => NOMBRE_PARTE[p.tipo]);
    return 'Liquidación de ' + (n.length > 1 ? n.slice(0, -1).join(', ') + ' y ' + n[n.length - 1] : n[0] || 'varios conceptos');
  }
  if (d.tipo === 'cesantias') {
    const anual = d.desde?.slice(5) === '01-01' && finDic(d.hasta) && d.desde.slice(0, 4) === d.hasta.slice(0, 4);
    return 'Liquidación de cesantías e intereses' + (anual ? ' — año ' + d.hasta.slice(0, 4) : '');
  }
  if (d.tipo === 'prima') {
    const s1 = d.hasta.slice(5) === '06-30';
    const s2 = finDic(d.hasta);
    return 'Liquidación de prima de servicios' + (s1 ? ' — primer semestre ' + d.hasta.slice(0, 4) : s2 ? ' — segundo semestre ' + d.hasta.slice(0, 4) : '');
  }
  if (d.tipo === 'vacaciones') return 'Compensación de vacaciones en dinero';
  if (d.tipo === 'disfrute') return 'Liquidación de vacaciones disfrutadas';
  return 'Liquidación definitiva de prestaciones sociales';
}

const TEXTO_LEGAL = {
  // Varias cosas juntas: la nota legal de cada una, en el mismo orden
  varios: (d) => (d.partes || []).map((p) => TEXTO_LEGAL[p.tipo](d)).join(' '),
  cesantias: (d) => d.opciones?.destino_cesantias === 'trabajador'
    ? `Las cesantías se pagan directamente al trabajador por este motivo: ${d.opciones.motivo_pago_directo || '—'}. El trabajador se compromete a darles ese uso y a entregar el soporte (Art. 256 CST).`
    : d.totales.a_fondo > 0
    ? `Las cesantías liquidadas se consignan en el fondo de cesantías${d.trabajador.fondo_cesantias ? ' ' + d.trabajador.fondo_cesantias : ''} a más tardar el 14 de febrero del año siguiente (Art. 99 de la Ley 50 de 1990). Los intereses sobre cesantías se pagan directamente al trabajador a más tardar el 31 de enero (Ley 52 de 1975).`
    : 'Las cesantías e intereses aquí liquidados se pagan directamente al trabajador.',
  prima: () => 'Prima de servicios equivalente a treinta (30) días de salario por año, pagadera la mitad a más tardar el 30 de junio y la otra mitad a más tardar el 20 de diciembre (Art. 306 CST).',
  vacaciones: () => 'Compensación en dinero de vacaciones causadas y no disfrutadas, acordada por escrito y a solicitud del trabajador (Art. 189 CST).',
  disfrute: () => 'Vacaciones remuneradas de quince (15) días hábiles por cada año de servicio, pagadas con el salario ordinario que el trabajador devenga al empezar a disfrutarlas (Art. 186 y 192 CST). Los domingos y festivos que caen dentro de las vacaciones no se cuentan aquí: se pagan como descanso con el salario de la nómina.',
  definitiva: (d) => d.opciones?.motivo_retiro === 'fallecimiento'
    ? 'Liquidación de las prestaciones sociales causadas a favor del trabajador fallecido, que se pagan a sus beneficiarios una vez publicados los avisos que ordena la ley y transcurrido el término de 30 días (Arts. 212 y 258 CST).'
    : 'Con su firma, el trabajador declara que recibió el valor neto aquí indicado por concepto de la liquidación de su contrato de trabajo a término indefinido, según los conceptos y periodos detallados en este documento.',
};

// "Base: salario $X + aux. transporte $Y." y, solo si no es lo normal, cómo se sacó.
function textoBase(b) {
  let s = 'Base: salario ' + pesos(b.salario) + (b.variable ? ' + variable ' + pesos(b.variable) : '') + (b.aux ? ' + aux. transporte ' + pesos(b.aux) : '') + '.';
  if (b.metodo && !/^Salario (vigente al|mínimo de|integral vigente)/.test(b.metodo)) s += ' ' + b.metodo + '.';
  if (b.metodoVariable) s += ' ' + b.metodoVariable + '.';
  if (b.regla) s += ' ' + b.regla + '.';
  return s;
}

export function Hoja({ l }) {
  const d = l.datos;
  const t = d.trabajador;
  const e = d.empresa || {};
  const def = d.tipo === 'definitiva';
  const fallecido = def && d.opciones?.motivo_retiro === 'fallecimiento';
  const devengos = d.conceptos.filter((c) => c.concepto !== 'deduccion' && c.concepto !== 'informativo');
  const notas = d.conceptos.filter((c) => c.concepto === 'informativo');
  const deducciones = d.conceptos.filter((c) => c.concepto === 'deduccion');
  return html`<div class="hoja">
    ${l.estado === 'anulada' && html`<div class="sello-anulada">ANULADA</div>`}
    <div class="h-cab">
      <div class="h-emp">${/ibiza/i.test(e.razon_social || '') && html`<img class="h-logo" src="marca/ibiza-logo.png" alt="" />`}<b>${e.razon_social || 'Empresa'}</b>${e.nit ? 'NIT ' + e.nit : ''}${e.direccion ? html`<br />${e.direccion}` : ''}${e.ciudad ? ' · ' + e.ciudad : ''}${e.telefono ? html`<br />Tel. ${e.telefono}` : ''}</div>
      <div class="h-num"><div>Comprobante</div><div class="n">N.º ${String(d.consecutivo).padStart(5, '0')}</div><div>Fecha: ${fLarga(d.fecha)}</div></div>
    </div>
    <h2 class="h-titulo">${titulo(d).toUpperCase()}</h2>
    <div class="h-datos">
      <div><small>Trabajador</small>${t.nombre}</div>
      <div><small>Documento</small>${t.tipo_documento} ${t.documento}</div>
      <div><small>Cargo</small>${t.cargo || '—'}</div>
      <div><small>Sede</small>${t.sede || '—'}</div>
      <div><small>Fecha de ingreso</small>${fLarga(t.fecha_ingreso)}</div>
      <div><small>Tipo de contrato</small>Término indefinido</div>
      <div><small>Salario básico mensual</small>${pesos(t.salario_actual)}</div>
      <div><small>Tipo de salario</small>${{ fijo: 'Fijo', variable: 'Variable', integral: 'Integral' }[t.tipo_salario]}</div>
      <div><small>Fondo de cesantías</small>${t.fondo_cesantias || '—'}</div>
      ${def && html`<div><small>Fecha de retiro</small>${fLarga(d.hasta)}</div>
        <div><small>Motivo del retiro</small>${MOTIVOS[d.opciones.motivo_retiro] || '—'}</div>
        <div><small>Tiempo de servicio</small>${tiempoServicio(t.fecha_ingreso, d.hasta)}</div>`}
    </div>
    <table>
      <thead><tr><th>Concepto</th><th>Periodo</th><th style="text-align:right">Días</th><th style="text-align:right">Base</th><th style="text-align:right">Valor</th></tr></thead>
      <tbody>
        ${devengos.map((c, i) => html`<tr key=${i}>
          <td><b>${c.concepto === 'otro_devengo' ? c.detalle : CONCEPTOS[c.concepto]}</b>
            ${c.formula && html`<div class="f">${c.formula}${c.norma ? ' · ' + c.norma : ''}${c.dias_descontados ? ` · ${c.dias_descontados} días no remunerados descontados` : ''}</div>`}
            ${c.base_detalle && c.concepto !== 'intereses' && html`<div class="f">${textoBase(c.base_detalle)}</div>`}
            ${c.destino === 'fondo' && html`<div class="f"><b>Se consigna en el fondo de cesantías.</b></div>`}
            ${c.concepto === 'vacaciones_disfrutadas' && c.detalle && html`<div class="f"><b>${c.detalle}.</b></div>`}
          </td>
          <td class="nowrap">${c.desde && c.concepto !== 'vacaciones' ? `${fCorta(c.desde)} a ${fCorta(c.hasta)}` : c.concepto === 'vacaciones' ? 'Corte ' + fCorta(c.hasta) : ''}</td>
          <td style="text-align:right">${c.dias != null ? num(c.dias) : ''}</td>
          <td style="text-align:right" class="nowrap">${c.base != null ? pesos(c.base) : ''}</td>
          <td style="text-align:right" class="nowrap">${pesos(c.valor)}</td>
        </tr>`)}
        ${notas.map((c, i) => html`<tr key=${'n' + i}><td colspan="4"><b>${c.titulo}</b><div class="f">${c.detalle}</div></td><td style="text-align:right">$0</td></tr>`)}
        <tr class="tot"><td colspan="4">Total liquidado</td><td style="text-align:right">${pesos(d.totales.devengado)}</td></tr>
        ${d.totales.a_fondo > 0 && html`<tr><td colspan="4">Menos: valor que se consigna en el fondo de cesantías${t.fondo_cesantias ? ' (' + t.fondo_cesantias + ')' : ''}</td><td style="text-align:right">-${pesos(d.totales.a_fondo)}</td></tr>`}
        ${deducciones.map((c, i) => html`<tr key=${'d' + i}><td colspan="4">Descuento: ${c.detalle}</td><td style="text-align:right">-${pesos(c.valor)}</td></tr>`)}
        <tr class="tot neto"><td colspan="4">NETO A PAGAR AL TRABAJADOR</td><td style="text-align:right" class="nowrap">${pesos(d.totales.neto)}</td></tr>
      </tbody>
    </table>
    <div class="letras">Son: ${d.neto_letras}</div>
    ${def && !fallecido && html`<div class="constancias">
      <div>${d.opciones.constancia_seguridad_social ? '☑' : '☐'} Se entrega constancia de pago de aportes a seguridad social y parafiscales de los últimos tres meses (Art. 29, Ley 789 de 2002).</div>
      <div>${d.opciones.examen_egreso ? '☑' : '☐'} Se entrega orden para el examen médico de egreso (Resolución 1843 de 2025).</div>
      <div>${d.opciones.certificado_laboral ? '☑' : '☐'} Se entrega certificado laboral (Art. 57, num. 7 CST).</div>
    </div>`}
    <div class="cierre">
      <div class="ref-firma">Comprobante N.º ${String(d.consecutivo).padStart(5, '0')} · ${t.nombre} · ${t.tipo_documento} ${t.documento} · Neto a pagar ${pesos(d.totales.neto)}</div>
      <p class="h-legal">${TEXTO_LEGAL[d.tipo](d)}</p>
      <div class="firmas">
        <div><b>${e.representante || ' '}</b><br />${e.cargo_representante || 'Por la empresa'}<br />${e.razon_social || ''}</div>
        ${fallecido ? html`<div>Beneficiario: ____________________________<br />Documento: _____________ Parentesco: ___________<br />Recibí</div>` : html`<div><b>${t.nombre}</b><br />${t.tipo_documento} ${t.documento}<br />Recibí</div>`}
        <div class="huella">Huella</div>
      </div>
      <div class="obs-trabajador">Observaciones del ${fallecido ? 'beneficiario' : 'trabajador'}: ________________________________________________________________________________</div>
    </div>
    <div class="h-pie">
      <span>Elaborada por ${d.creado_por || '—'} el ${d.creado_en}${l.estado === 'anulada' ? ` · ANULADA el ${l.anulada_en} por ${l.anulada_por || '—'}: ${l.anulada_motivo}` : ''}</span>
      <span>Código de control ${l.huella.slice(0, 16).toUpperCase()}</span>
    </div>
  </div>`;
}

export function Comprobante({ id }) {
  const { datos: l, error, cargando, recargar } = useDatos('/api/liquidaciones/' + id);
  if (cargando && !l) return html`<${Cargando} />`;
  if (error) return html`<${Aviso} tipo="bad">${error}</${Aviso}>`;
  const anular = async () => {
    const motivo = await confirmar({
      titulo: `Anular la liquidación N.º ${l.consecutivo}`,
      texto: html`<div class="pila"><p>No se borra: queda en el historial marcada como <b>ANULADA</b>, con el motivo y quién lo hizo. Los periodos que cubría vuelven a quedar pendientes.</p>
        ${l.tipo === 'definitiva' && html`<${Aviso}>El trabajador vuelve a quedar <b>activo</b>.</${Aviso}>`}</div>`,
      pedirMotivo: '¿Por qué se anula?',
      boton: 'Anular',
      peligro: true,
    });
    if (!motivo) return;
    try { await api(`/api/liquidaciones/${l.id}/anular`, { metodo: 'POST', cuerpo: { motivo } }); avisar('Liquidación anulada'); recargar(); } catch (e) { avisar(e.message, 'error'); }
  };
  const d = l.datos;
  return html`<div class="pila">
    <div class="no-imprimir pila">
      <div class="migas"><a href="#/historial">Historial</a> › <a href=${'#/trabajador/' + l.trabajador_id}>${d.trabajador.nombre}</a> › N.º ${l.consecutivo}</div>
      <div class="encabezado">
        <div><h1>Liquidación N.º ${l.consecutivo} ${l.estado === 'anulada' && html`<span class="chip bad" style="vertical-align:middle">Anulada</span>`}</h1>
          <p class="sub">${l.tipo === 'varios' ? etiquetaPartes(d.partes) : TIPOS[l.tipo]} · ${d.trabajador.nombre} · ${fLarga(l.fecha)}</p></div>
        <div class="fila">
          <button class="btn" onClick=${() => history.back()}><${Icono} n="atras" />Volver</button>
          ${l.estado === 'vigente' && html`<button class="btn peligro" onClick=${anular}>Anular</button>`}
          <button class="btn primario" onClick=${() => window.print()}><${Icono} n="imprimir" />Imprimir o guardar PDF</button>
        </div>
      </div>
      ${!l.integra && html`<${Aviso} tipo="bad"><b>Ojo: este registro fue modificado por fuera del programa.</b> El código de control no coincide con el contenido guardado.</${Aviso}>`}
      ${l.estado === 'anulada' && html`<${Aviso} tipo="bad">Anulada el ${l.anulada_en} por ${l.anulada_por || '—'}. Motivo: ${l.anulada_motivo}</${Aviso}>`}
      ${d.avisos?.length > 0 && html`<details class="plegable"><summary>Notas del cálculo (${d.avisos.length}) — no salen impresas</summary>${d.avisos.map((a) => html`<${Aviso}>${a}</${Aviso}>`)}</details>`}
    </div>
    <${Hoja} l=${l} />
  </div>`;
}

export function ComprobantesLote({ lote }) {
  const [hojas, setHojas] = useState(null);
  useEffect(() => {
    (async () => {
      try {
        const h = await api('/api/liquidaciones?' + new URLSearchParams({ lote, estado: 'todas' }));
        const ids = h.filas.map((f) => f.id).reverse();
        const out = [];
        for (const id of ids) out.push(await api('/api/liquidaciones/' + id));
        setHojas(out);
      } catch (e) { avisar(e.message, 'error'); setHojas([]); }
    })();
  }, [lote]);
  if (!hojas) return html`<${Cargando} texto="Preparando los comprobantes…" />`;
  return html`<div class="pila">
    <div class="no-imprimir encabezado">
      <div><h1>${hojas.length} comprobantes</h1><p class="sub">Uno por hoja. Para guardarlos en PDF, escoja "Guardar como PDF" en la impresora.</p></div>
      <div class="fila"><button class="btn" onClick=${() => history.back()}><${Icono} n="atras" />Volver</button><button class="btn primario" onClick=${() => window.print()}><${Icono} n="imprimir" />Imprimir todos</button></div>
    </div>
    ${hojas.map((l) => html`<${Hoja} l=${l} key=${l.id} />`)}
  </div>`;
}

// ---------------------------------------------------------------- certificado laboral (Art. 57 num. 7 CST)
export function Certificado({ id }) {
  const { datos: c, error, cargando } = useDatos(`/api/trabajadores/${id}/certificado`);
  const [conSalario, setConSalario] = useState(true);
  const [dirigido, setDirigido] = useState('');
  if (cargando && !c) return html`<${Cargando} />`;
  if (error) return html`<${Aviso} tipo="bad">${error}</${Aviso}>`;
  const t = c.trabajador;
  const e = c.empresa || {};
  const retirado = !!t.fecha_retiro;
  return html`<div class="pila">
    <div class="no-imprimir pila">
      <div class="migas"><a href="#/trabajadores">Trabajadores</a> › <a href=${'#/trabajador/' + t.id}>${t.nombre}</a> › Certificado laboral</div>
      <div class="encabezado">
        <div><h1>Certificado laboral</h1><p class="sub">Lo pide la ley al terminar el contrato (Art. 57 num. 7 CST) y lo puede pedir el trabajador en cualquier momento.</p></div>
        <div class="fila">
          <button class="btn" onClick=${() => history.back()}><${Icono} n="atras" />Volver</button>
          <button class="btn primario" onClick=${() => window.print()}><${Icono} n="imprimir" />Imprimir o guardar PDF</button>
        </div>
      </div>
      <div class="panel"><div class="panel-cuerpo fila" style="gap:18px;align-items:end">
        <label class="check"><input type="checkbox" checked=${conSalario} onChange=${(ev) => setConSalario(ev.target.checked)} /><span>Incluir el salario</span></label>
        <div class="campo" style="min-width:280px"><label for="cert-a">Dirigido a (opcional)</label><input id="cert-a" value=${dirigido} placeholder="A quien interese" onInput=${(ev) => setDirigido(ev.target.value)} /></div>
        ${!e.representante && html`<span class="small" style="color:var(--warn)">Falta quién firma por la empresa: póngalo en Ajustes → Datos de la empresa.</span>`}
      </div></div>
    </div>
    <div class="hoja certificado">
      <div class="h-cab">
        <div class="h-emp">${/ibiza/i.test(e.razon_social || '') && html`<img class="h-logo" src="marca/ibiza-logo.png" alt="" />`}<b>${e.razon_social || 'Empresa'}</b>${e.nit ? 'NIT ' + e.nit : ''}${e.direccion ? html`<br />${e.direccion}` : ''}${e.ciudad ? ' · ' + e.ciudad : ''}${e.telefono ? html`<br />Tel. ${e.telefono}` : ''}</div>
        <div class="h-num"><div>${e.ciudad ? e.ciudad + ', ' : ''}${c.hoy_largo}</div></div>
      </div>
      <h2 class="h-titulo">CERTIFICACIÓN LABORAL</h2>
      <p class="cert-a"><b>${(dirigido || 'A quien interese').toUpperCase()}</b></p>
      <p class="cert-txt">${e.razon_social || 'La empresa'}${e.nit ? `, identificada con NIT ${e.nit},` : ''} certifica que <b>${t.nombre.toUpperCase()}</b>, identificado(a) con ${{ CC: 'cédula de ciudadanía', CE: 'cédula de extranjería', PPT: 'permiso por protección temporal', PA: 'pasaporte', TI: 'tarjeta de identidad' }[t.tipo_documento] || t.tipo_documento} N.º <b>${t.documento}</b>, ${retirado ? html`laboró en esta empresa desde el <b>${c.ingreso_largo}</b> hasta el <b>${c.retiro_largo}</b>` : html`labora en esta empresa desde el <b>${c.ingreso_largo}</b> y continúa vinculado(a) a la fecha`},
        con contrato de trabajo a término indefinido${t.cargo ? html`, desempeñando el cargo de <b>${t.cargo}</b>` : ''}${conSalario ? html`, ${retirado ? 'con un último salario básico mensual de' : 'con un salario básico mensual de'} <b>${pesos(c.salario)}</b> (${c.salario_letras.toLowerCase().replace(' m/cte', '')} moneda corriente)` : ''}.</p>
      <p class="cert-txt">Tiempo de servicio: ${tiempoServicio(t.fecha_ingreso, t.fecha_retiro || c.hoy)}.</p>
      <p class="cert-txt">Se expide a solicitud del interesado${e.ciudad ? ` en ${e.ciudad}` : ''}, el ${c.hoy_largo}.</p>
      <div class="firmas cert-firma"><div><b>${e.representante || ' '}</b><br />${e.cargo_representante || 'Por la empresa'}<br />${e.razon_social || ''}</div></div>
    </div>
  </div>`;
}
