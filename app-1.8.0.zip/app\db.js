// Base de datos: UN solo archivo SQLite en la carpeta "datos" del programa.
// Se usa journal_mode=DELETE (no WAL) para que, con el programa cerrado, todo quede dentro de
// liquidaciones.db y se pueda llevar a otro computador copiando y pegando.
'use strict';
const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');

const RAIZ = path.resolve(__dirname, '..');
const DATOS = process.env.LIQ_DATOS ? path.resolve(process.env.LIQ_DATOS) : path.join(RAIZ, 'datos');
const ARCHIVO = path.join(DATOS, 'liquidaciones.db');
const RESPALDOS = path.join(DATOS, 'respaldos');

// Salario mínimo y auxilio de transporte por año (decretos del Gobierno). Editables en Ajustes.
const PARAMETROS_INICIALES = [
  [2015, 644350, 74000], [2016, 689455, 77700], [2017, 737717, 83140], [2018, 781242, 88211],
  [2019, 828116, 97032], [2020, 877803, 102854], [2021, 908526, 106454], [2022, 1000000, 117172],
  [2023, 1160000, 140606], [2024, 1300000, 162000], [2025, 1423500, 200000],
  [2026, 1750905, 249095], // Decretos 1469 y 1470 de 2025
];

// corte = fecha de la planilla cuando la nómina viene por quincenas (o semanas); '' si viene un solo
// total del mes. Un mes puede tener varias filas: se suman al promediar.
const NOMINA = `
  id INTEGER PRIMARY KEY, trabajador_id INTEGER NOT NULL REFERENCES trabajadores(id),
  periodo TEXT NOT NULL, corte TEXT NOT NULL DEFAULT '', salario_basico INTEGER, extras_recargos INTEGER DEFAULT 0,
  comisiones INTEGER DEFAULT 0, otros_salariales INTEGER DEFAULT 0, auxilio_transporte INTEGER DEFAULT 0, recargo_nocturno INTEGER DEFAULT 0,
  dias INTEGER, fuente TEXT, creado TEXT NOT NULL,
  UNIQUE (trabajador_id, periodo, corte)`;

// La misma cédula puede volver con otro contrato (reingreso): solo puede haber UNA activa a la vez
// (índice parcial trabajadores_doc_vigente). reingreso_de = id del contrato anterior.
const TRABAJADORES = `
  id INTEGER PRIMARY KEY,
  tipo_documento TEXT NOT NULL DEFAULT 'CC', documento TEXT NOT NULL,
  nombres TEXT NOT NULL, apellidos TEXT NOT NULL DEFAULT '',
  cargo TEXT, sede TEXT, telefono TEXT, correo TEXT,
  fecha_ingreso TEXT NOT NULL, fecha_retiro TEXT, motivo_retiro TEXT,
  tipo_salario TEXT NOT NULL DEFAULT 'fijo' CHECK (tipo_salario IN ('fijo','variable','integral')),
  salario_minimo INTEGER NOT NULL DEFAULT 0,
  auxilio_transporte TEXT NOT NULL DEFAULT 'auto' CHECK (auxilio_transporte IN ('auto','no')),
  fondo_cesantias TEXT,
  cesantias_hasta_inicial TEXT, prima_hasta_inicial TEXT, vac_saldo_fecha TEXT, vac_saldo_dias REAL,
  notas TEXT, creado TEXT NOT NULL, actualizado TEXT NOT NULL, reingreso_de INTEGER`;

const ESQUEMA = `
CREATE TABLE IF NOT EXISTS meta (clave TEXT PRIMARY KEY, valor TEXT);
CREATE TABLE IF NOT EXISTS empresa (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  razon_social TEXT, nit TEXT, direccion TEXT, ciudad TEXT, telefono TEXT,
  representante TEXT, cargo_representante TEXT
);
CREATE TABLE IF NOT EXISTS parametros (
  anio INTEGER PRIMARY KEY, smmlv INTEGER NOT NULL, auxilio_transporte INTEGER NOT NULL, nota TEXT
);
CREATE TABLE IF NOT EXISTS usuarios (
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL UNIQUE, activo INTEGER NOT NULL DEFAULT 1, creado TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS trabajadores (${TRABAJADORES});
CREATE UNIQUE INDEX IF NOT EXISTS trabajadores_doc_vigente ON trabajadores(documento) WHERE fecha_retiro IS NULL;
CREATE INDEX IF NOT EXISTS trabajadores_doc ON trabajadores(documento);
CREATE TABLE IF NOT EXISTS salarios (
  id INTEGER PRIMARY KEY, trabajador_id INTEGER NOT NULL REFERENCES trabajadores(id),
  vigente_desde TEXT NOT NULL, salario INTEGER NOT NULL, nota TEXT, creado TEXT NOT NULL,
  UNIQUE (trabajador_id, vigente_desde)
);
CREATE TABLE IF NOT EXISTS novedades (
  id INTEGER PRIMARY KEY, trabajador_id INTEGER NOT NULL REFERENCES trabajadores(id),
  tipo TEXT NOT NULL, desde TEXT NOT NULL, hasta TEXT NOT NULL, nota TEXT, creado TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS vacaciones (
  id INTEGER PRIMARY KEY, trabajador_id INTEGER NOT NULL REFERENCES trabajadores(id),
  desde TEXT NOT NULL, hasta TEXT NOT NULL, dias_habiles REAL NOT NULL, nota TEXT, creado TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS nomina (${NOMINA});
CREATE TABLE IF NOT EXISTS liquidaciones (
  id INTEGER PRIMARY KEY, consecutivo INTEGER NOT NULL UNIQUE,
  trabajador_id INTEGER NOT NULL REFERENCES trabajadores(id),
  tipo TEXT NOT NULL, fecha TEXT NOT NULL, desde TEXT, hasta TEXT NOT NULL,
  devengado INTEGER NOT NULL, deducciones INTEGER NOT NULL, a_fondo INTEGER NOT NULL, neto INTEGER NOT NULL,
  estado TEXT NOT NULL DEFAULT 'vigente' CHECK (estado IN ('vigente','anulada')),
  anulada_motivo TEXT, anulada_por TEXT, anulada_en TEXT,
  datos TEXT NOT NULL, huella TEXT NOT NULL, lote TEXT,
  creado_por TEXT, creado_en TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS conceptos (
  id INTEGER PRIMARY KEY, liquidacion_id INTEGER NOT NULL REFERENCES liquidaciones(id),
  trabajador_id INTEGER NOT NULL REFERENCES trabajadores(id),
  concepto TEXT NOT NULL, detalle TEXT, desde TEXT, hasta TEXT, dias REAL, base INTEGER, valor INTEGER NOT NULL, destino TEXT
);
-- Lo que se pagó ANTES de usar el programa, tal como venía en los Excel de la empresa. Es historia: no se recalcula
-- ni cambia los cálculos. Va por cédula (no por trabajador) para guardar también a quienes ya no trabajan allí;
-- en la ficha de cada trabajador aparecen los de su cédula.
CREATE TABLE IF NOT EXISTS historicas (
  id INTEGER PRIMARY KEY, documento TEXT NOT NULL, nombre TEXT,
  concepto TEXT NOT NULL CHECK (concepto IN ('prima','cesantias','vacaciones','otro')),
  desde TEXT, hasta TEXT NOT NULL, dias REAL, salario INTEGER, auxilio INTEGER, base INTEGER,
  valor INTEGER NOT NULL, intereses INTEGER, descuentos INTEGER, neto INTEGER, fondo TEXT, observacion TEXT,
  fuente TEXT, creado TEXT NOT NULL, creado_por TEXT,
  UNIQUE (documento, concepto, hasta)
);
CREATE INDEX IF NOT EXISTS historicas_doc ON historicas(documento);
CREATE TABLE IF NOT EXISTS bitacora (
  id INTEGER PRIMARY KEY, fecha TEXT NOT NULL, usuario TEXT, accion TEXT NOT NULL,
  entidad TEXT, entidad_id INTEGER, detalle TEXT
);
CREATE INDEX IF NOT EXISTS ix_liq_trab ON liquidaciones(trabajador_id);
CREATE INDEX IF NOT EXISTS ix_liq_fecha ON liquidaciones(fecha);
CREATE INDEX IF NOT EXISTS ix_con_trab ON conceptos(trabajador_id, concepto);
CREATE INDEX IF NOT EXISTS ix_nom_trab ON nomina(trabajador_id, periodo);
-- Las liquidaciones son un registro legal: no se borran ni se modifica su contenido; solo se anulan.
CREATE TRIGGER IF NOT EXISTS liq_no_borrar BEFORE DELETE ON liquidaciones
BEGIN SELECT RAISE(ABORT, 'Las liquidaciones no se borran; se anulan.'); END;
CREATE TRIGGER IF NOT EXISTS liq_no_editar BEFORE UPDATE OF datos, huella, devengado, neto, consecutivo, trabajador_id, fecha, hasta ON liquidaciones
BEGIN SELECT RAISE(ABORT, 'El contenido de una liquidación no se puede cambiar.'); END;
CREATE TRIGGER IF NOT EXISTS con_no_borrar BEFORE DELETE ON conceptos
BEGIN SELECT RAISE(ABORT, 'Los conceptos de una liquidación no se borran.'); END;
`;

let db = null;

function ahora() {
  const t = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${t.getFullYear()}-${p(t.getMonth() + 1)}-${p(t.getDate())} ${p(t.getHours())}:${p(t.getMinutes())}:${p(t.getSeconds())}`;
}

function abrir() {
  fs.mkdirSync(DATOS, { recursive: true });
  fs.mkdirSync(RESPALDOS, { recursive: true });
  db = new DatabaseSync(ARCHIVO);
  db.exec('PRAGMA journal_mode = DELETE; PRAGMA synchronous = FULL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
  migrar();
  db.exec(ESQUEMA);
  const ins = db.prepare('INSERT OR IGNORE INTO parametros (anio, smmlv, auxilio_transporte) VALUES (?, ?, ?)');
  for (const p of PARAMETROS_INICIALES) ins.run(...p);
  db.prepare("INSERT OR IGNORE INTO meta (clave, valor) VALUES ('creada', ?)").run(ahora());
  db.prepare("INSERT OR IGNORE INTO meta (clave, valor) VALUES ('version_esquema', '1')").run();
  return db;
}

// Bases creadas con versiones anteriores: se les agregan las columnas nuevas sin tocar los datos.
function migrar() {
  const tablas = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map((x) => x.name);
  const agregar = (tabla, columna, definicion) => {
    if (!tablas.includes(tabla)) return;
    const cols = db.prepare(`PRAGMA table_info(${tabla})`).all().map((c) => c.name);
    if (!cols.includes(columna)) db.exec(`ALTER TABLE ${tabla} ADD COLUMN ${columna} ${definicion}`);
  };
  agregar('trabajadores', 'salario_minimo', 'INTEGER NOT NULL DEFAULT 0');
  agregar('nomina', 'recargo_nocturno', 'INTEGER DEFAULT 0');
  // v1.3: la nómina deja de ser una fila por mes (cada quincena es su propia fila). SQLite no deja
  // cambiar un UNIQUE, así que se rehace la tabla con los mismos datos.
  // v1.6.3: la cédula deja de ser única para siempre (reingreso). SQLite no deja quitar un UNIQUE: se rehace la tabla.
  if (tablas.includes('trabajadores') && db.prepare('PRAGMA index_list(trabajadores)').all().some((i) => i.unique && i.origin === 'u')) {
    const cols = db.prepare('PRAGMA table_info(trabajadores)').all().map((c) => c.name).join(', ');
    db.exec('PRAGMA foreign_keys = OFF');
    try {
      tx(() => {
        db.exec(`CREATE TABLE trabajadores_v163 (${TRABAJADORES})`);
        db.exec(`INSERT INTO trabajadores_v163 (${cols}) SELECT ${cols} FROM trabajadores`);
        db.exec('DROP TABLE trabajadores');
        db.exec('ALTER TABLE trabajadores_v163 RENAME TO trabajadores');
        if (db.prepare('PRAGMA foreign_key_check').all().length) throw new Error('Las referencias a los trabajadores no cuadran después de la migración.');
      });
    } finally {
      db.exec('PRAGMA foreign_keys = ON');
    }
  }
  if (tablas.includes('nomina') && !db.prepare('PRAGMA table_info(nomina)').all().some((c) => c.name === 'corte')) {
    const cols = 'id, trabajador_id, periodo, salario_basico, extras_recargos, comisiones, otros_salariales, auxilio_transporte, recargo_nocturno, dias, fuente, creado';
    tx(() => {
      db.exec(`CREATE TABLE nomina_v13 (${NOMINA})`);
      db.exec(`INSERT INTO nomina_v13 (${cols}) SELECT ${cols} FROM nomina`);
      db.exec('DROP TABLE nomina');
      db.exec('ALTER TABLE nomina_v13 RENAME TO nomina');
    });
  }
}

function cerrar() {
  if (db) { try { db.close(); } catch {} db = null; }
}

const all = (sql, ...p) => db.prepare(sql).all(...p);
const get = (sql, ...p) => db.prepare(sql).get(...p);
const run = (sql, ...p) => db.prepare(sql).run(...p);

function tx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const r = fn();
    db.exec('COMMIT');
    return r;
  } catch (e) {
    try { db.exec('ROLLBACK'); } catch {}
    throw e;
  }
}

function bitacora(usuario, accion, entidad, entidadId, detalle) {
  run('INSERT INTO bitacora (fecha, usuario, accion, entidad, entidad_id, detalle) VALUES (?, ?, ?, ?, ?, ?)',
    ahora(), usuario || null, accion, entidad || null, entidadId ?? null, detalle == null ? null : JSON.stringify(detalle));
}

// Copia completa y consistente del archivo (sirve aunque el programa esté abierto).
function respaldarEn(destino) {
  if (fs.existsSync(destino)) fs.unlinkSync(destino);
  db.exec(`VACUUM INTO '${destino.replace(/'/g, "''")}'`);
  return destino;
}

function respaldoDiario() {
  const hoy = ahora().slice(0, 10);
  const destino = path.join(RESPALDOS, `liquidaciones-${hoy}.db`);
  if (!fs.existsSync(destino)) respaldarEn(destino);
  // Se guardan los últimos 30
  const viejos = fs.readdirSync(RESPALDOS).filter((f) => /^liquidaciones-\d{4}-\d{2}-\d{2}\.db$/.test(f)).sort();
  while (viejos.length > 30) fs.unlinkSync(path.join(RESPALDOS, viejos.shift()));
  return destino;
}

// ¿Este archivo es una base de este programa?
function esBaseValida(archivo) {
  let otra;
  try {
    otra = new DatabaseSync(archivo, { readOnly: true });
    const t = otra.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map((x) => x.name);
    return ['trabajadores', 'liquidaciones', 'conceptos', 'parametros'].every((n) => t.includes(n));
  } catch {
    return false;
  } finally {
    try { otra && otra.close(); } catch {}
  }
}

function reemplazarCon(archivo) {
  cerrar();
  fs.copyFileSync(archivo, ARCHIVO);
  for (const extra of ['-journal', '-wal', '-shm']) {
    try { fs.unlinkSync(ARCHIVO + extra); } catch {}
  }
  abrir();
}

module.exports = {
  RAIZ, DATOS, ARCHIVO, RESPALDOS, abrir, cerrar, all, get, run, tx, bitacora, ahora,
  respaldarEn, respaldoDiario, esBaseValida, reemplazarCon,
  get conexion() { return db; },
};
